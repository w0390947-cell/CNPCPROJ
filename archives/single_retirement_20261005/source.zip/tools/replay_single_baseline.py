"""Verify and replay the frozen pre-unification source in an isolated process."""

import argparse
import hashlib
import json
import os
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path, PurePosixPath


def main() -> None:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive", type=Path, default=root / "archives/single_execution_20261005")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    archive = args.archive.resolve()
    manifest = json.loads((archive / "manifest.json").read_text(encoding="utf-8"))
    source = archive / "source.zip"
    if hashlib.sha256(source.read_bytes()).hexdigest() != manifest["archive_sha256"]:
        raise ValueError("historical archive digest differs")
    args.output.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="cnpc-single-baseline-") as temporary:
        workspace = Path(temporary).resolve()
        with zipfile.ZipFile(source) as bundle:
            if set(bundle.namelist()) != set(manifest["files"]):
                raise ValueError("historical archive membership differs")
            for name, digest in manifest["files"].items():
                relative = PurePosixPath(name)
                if relative.is_absolute() or ".." in relative.parts or "\\" in name or ":" in name:
                    raise ValueError("unsafe archive member")
                target = (workspace / Path(*relative.parts)).resolve()
                if not target.is_relative_to(workspace):
                    raise ValueError("archive target escaped the isolated workspace")
                content = bundle.read(name)
                if hashlib.sha256(content).hexdigest() != digest:
                    raise ValueError("historical source digest differs: " + name)
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(content)
        environment = {
            **os.environ,
            "PYTHONPATH": str(workspace / "src"),
            "PYTHONDONTWRITEBYTECODE": "1",
        }
        command = [
            sys.executable,
            "-B",
            "-m",
            "pytest",
            "-p",
            "no:cacheprovider",
            "--import-mode=importlib",
            "tests/unit/control/test_device_tube.py",
            "tests/unit/power_flow/test_ac_envelope.py",
            "tests/workflows/test_conditional_guarantee.py",
            "-q",
        ]
        completed = subprocess.run(
            command,
            cwd=workspace,
            env=environment,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            check=False,
        )
        (args.output / "pytest.txt").write_text(
            completed.stdout + completed.stderr, encoding="utf-8"
        )
        report = {
            "archive_sha256": manifest["archive_sha256"],
            "source_files_verified": len(manifest["files"]),
            "python": sys.version,
            "command": command,
            "exit_code": completed.returncode,
            "scope": "historical device, AC and conditional supervisor regressions; no new guarantees assigned",
        }
        (args.output / "report.json").write_text(
            json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
        )
        print(completed.stdout, end="")
        # TemporaryDirectory owns exactly this verified, newly created directory.
        if not workspace.is_relative_to(Path(tempfile.gettempdir()).resolve()):
            raise RuntimeError("temporary cleanup target is outside the temporary root")
    raise SystemExit(completed.returncode)


if __name__ == "__main__":
    main()
