# 集群控制算法的唯一实现与入口迁移

2026-10-05：在网络候选反馈基础上，默认装配增加
[储能实际有功可达性](Storage_Reachability.md)，算法身份为 `cluster-rolling-v3`。
后续窗口使用已完成检查点的实际 P/E；启动假设和名义执行边界随证据说明。
显式未启用本策略的旧调用继续按下述 v1/v2 语义执行，不补造动态证书。

2026-10-05：正式默认装配启用 [网络候选反馈](Network_Candidate_Feedback.md)，
算法身份为 `cluster-rolling-v2`。未显式启用候选策略的调用保留 v1，旧结果不补证。
共同服务和滚动入口保持唯一；候选约束 ADMM 后仍严格落实，不引入另一套执行流程。

2026-09-30。算法标识：`cluster-rolling-v1`；算法身份字段自结果模式 `1.13.0` 引入。
后续模式版本以运行结果的 `metadata.schema_version` 为准，算法身份单独记录。

## 权威调用链

网页、作业进程、CLI 和批量研究均调用 `service.run_simulation`，集群场景由
`service._run_cluster` 装配 `bootstrap/adapters/cluster_execution.run_cluster_execution`。
它使用 `RollingClusterEngine` 与 `workflows/cluster_execution` 完成状态反馈、滚动协调、
区域落实、可行性恢复和采用判定。入口只负责请求、进度及结果归档。

只有一套权威实现不意味着算法必须放进一个文件。协调优化、设备状态转移、潮流校核和
跨层工作流仍按职责分开；集中式优化保留为经济/网络对照，单组件研究保留为诊断工具，
这些结果不能替代集群滚动执行证据。

| 入口 | 当前行为 |
|---|---|
| 网页集群/通信故障、Web worker | 调用共同的仿真服务 |
| `oilfield-opt cluster` | 调用共同服务，归档完整结果 |
| `oilfield-opt cluster-batch --input requests.json` | 逐项调用同一归档适配器；失败保留并继续后续研究 |
| `oilfield-opt hierarchical` | 命令别名，明确提示语义和输出迁移；可附加一次完整滚动通信故障研究 |
| `oilfield-opt run` | 保留对照图表，集群执行通过共同服务完成，证据写入 `cluster_rolling/` |
| `oilfield-opt run --legacy-milp` | 仅近似模型静态对照，明确标为 `reference_only`，不提供滚动执行证书 |
| `tools/verify_cluster_audit.py` 的 `hierarchy` 模式 | 名称为历史兼容；实际调用当前滚动服务 |

## 已退役内容

删除 `hierarchical.py`、`run_hierarchical_control` 和 `HierarchicalResult`。
原独立流程用一次协调参考落实日前及一次日内计划，再重放设备执行；它没有现行滚动
流程的连续会话、状态反馈及采用判定，因此不保留为第二种正式算法，也不静默映射其
Python 返回类型。调用者应迁移至 `service.run_simulation(SimulationRequest(...))`，
读取 `SimulationResult.cluster_execution`。

同时删除 `ExecutionEngines.minute` 中“没有滚动会话时独立重放日内计划”的备用分支。
没有滚动会话时只能得到 `not_computed`。共享的 `hierarchy_types.py` 仍容纳 ADMM、
设备等既有类型，`hierarchy_reporting.py` 仅保留设备证据导出；文件名不代表另一套算法。

旧 PNG、CSV 和摘要结构没有伪装为新结果；旧归档保留历史身份。工作区变更前源文件
已保存至 `artifacts/cluster-authority-20260930/workspace-before.zip` 并附 SHA-256 清单。
该快照包括未提交修改；不能只依赖 Git 提交重现此前工作区。

## 请求、归档与状态

```powershell
oilfield-opt cluster --steps 8 --output artifacts/cluster-run-001
oilfield-opt cluster --input request.json --output artifacts/cluster-run-002
oilfield-opt cluster-batch --input requests.json --output artifacts/cluster-batch-001
```

`request.json` 是与网页一致的 `SimulationRequest`；例如：

```json
{"name":"集群研究","scenario_type":"cluster_coordination","steps":8,"storage_enabled":true,"solver":{"formulation":"misocp","time_limit_seconds":60},"admm_max_iterations":220}
```

批量文件是该请求对象的非空数组。指定 `--input` 时完整采用文件中的参数，命令行的
`--steps` 和 `--time-limit` 不覆盖它。Python 研究可显式传入 `input_case`；该输入会
归档为 `input_case.json`。自备算例沿用服务既有的持续性场景语义，不冒称已提供新的
分钟预测或现场量测。不同输入、事件、求解器策略的结果不要求相同；相同请求共享规则。

每次运行必须使用新目录。输出 `request.json`、`result.json`、`cluster_execution.json`；
异常写入 `failure.json` 后传播。批量运行的 `batch.json` 记录每项状态。未通过的完整
结果先归档，再由 CLI 返回非零；批量任一项非 `passed` 或异常即返回非零。

`cluster_execution.algorithm_version` 标明生成证据的算法版本；旧记录缺少此字段时为
`null`，不自动补证。它不同于结果结构的 `version`，也不是唯一源码指纹。严谨的复现
仍须保存源文件/安装包哈希、输入、配置及求解环境。`passed` 还须根据实际采用记录、
阶段检查和覆盖范围解读，不能由算法版本标识直接推出。

## 约束与证明的边界

固定并联补偿、区域可行性反馈、连续有功容量联合过渡、最终计划逐时段功率因数门禁
均沿用现行实现。本次统一不降低容差、不增加绕过失败的分支，也不改变这些证明的
假设范围。容量连续保证仍是既定模型下的条件保证；计划功率因数门禁仍针对最终采用
计划逐时段，不自动扩展为连续时间功率因数证明。失败停止仍然是合法结果，统一入口
不证明任意输入必然可行、递归可行或全局最优。

## 回归迁移对应

| 旧测试目的 | 当前覆盖 |
|---|---|
| 设备风/光/储/无功身份、群控通道及 CSV | `tests/test_cluster_rolling.py` 从真实滚动会话取证；持续性输入没有概率观测时，检查无效标志及空观测，不能把回退概率当成实测值 |
| ADMM 收敛、故障恢复、防过时消息 | `tests/test_cluster_rolling.py`、`tests/integration/dispatch/test_cluster_repairs.py` |
| 网络落实、保护下限、AC 一致性 | `tests/test_planning_security.py`、`tests/integration/dispatch/test_coordination_recovery.py`、`test_fixed_shunt_coordination.py` |
| 旧 15.6 MW 反例所揭示的联合容量问题 | `tests/unit/control/test_cluster_transition.py`、`tests/workflows/test_cluster_transition.py`、`tests/integration/control/test_cluster_transition.py`；现行算法应提前拒绝无证据过渡，不能继续要求旧越限轨迹出现 |
| 最终计划集群功率因数及有界恢复 | `tests/integration/dispatch/test_cluster_power_factor.py`、`tests/workflows/test_cluster_power_factor.py` |
| 停用储能、失败前缀及反馈连续性 | `tests/integration/service/test_cluster_execution.py`、`test_reserve_feedback.py` |
| 入口一致、失败归档、批量继续、历史身份 | `tests/integration/service/test_cluster_authority.py` |

旧图表文件名/像素大小断言随旧报告格式退役，不能作为算法有效性证据继续沿用。
