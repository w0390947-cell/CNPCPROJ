# 储能有功候选采用与回退

模型标识：`storage-tracking-v1`。适用于分钟离线设备仿真。
储能注入以放电为正，PCC 有功以受电为正，功率单位 MW，能量单位 MWh。

## 候选与采用条件

固定周期初实际功率、能量 `p0,E0`。计划响应、物理能量限幅产生基准 `p_base`；
基准和所有候选使用同一负荷、网络、其他设备 P 及当前全部设备 Q。

```text
e_base = P_PCC(base) - P_ref
p_req = p_base + clip(e_base, -R, R)
l = max(p_phys_min, p0 - R)
h = min(p_phys_max, p0 + R)
p_cand = clip(p_req, l, h)                   # l <= h
e_cand = P_PCC(cand) - P_ref
```

`R` 是整个执行周期相对 `p0` 的唯一普通爬坡额度。候选是单周期响应，不再次
施加一阶滞后。基准 AC 有效且满足完整约束、没有群控限发/恢复/网络闭锁/硬保护
时才试算候选。候选须满足：

1. 输入有效、潮流收敛，储能有功、无功权限和 PCS 视在容量满足；
2. 电压、支路容量、PCC 受电上下界及功率因数均合格；
3. `abs(e_base) - abs(e_cand) > 1e-9 MW`。

通过则 `p_corr=p_cand`，否则 `p_corr=p_base`。`1e-9 MW` 是严格改进的数值
比较容差，随证据记录，不能替代工程跟踪限值。PCC 下界还叠加当前群控安全下界，
上界不超过微网受电上界。完整 AC 违反项必须为空，单独的 `recovery_safe` 不够。

## 保持、物理限幅与硬保护

不安全或未知基准下跳过普通反馈，保留原失败状态；“保持”不意味着此基准安全。
当物理范围与爬坡范围无交集，仍取物理范围内最接近 `p0` 的端点，并记录
`physical_override`，不以跟踪误差变差为由拒绝强制物理限幅。
群控和硬保护仍使用已有权限及闭锁规则；后续硬保护可替换普通阶段选定值，
独立记录 `hard_override` 并接受最终网络校核。

能量只根据选定功率从 `E0` 计算：

```text
p >= 0: E_next = E0 - p * dt_hours / eta_discharge
p < 0:  E_next = E0 + (-p) * eta_charge * dt_hours
```

拒绝候选时恢复的是基准响应对应的能量，非机械恢复为 `E0`。后续硬保护替换
动作也从同一 `E0` 重算。候选试算不更新有效量测、网络闭锁、控制器状态或能量。
储能阶段选定后更新 PCC 偏差，再由既有风光分配规则尝试接续；其本身仍有独立准入。

## 记录与兼容

`network_context.storage_tracking_version` 标明新运行版本。
`minute_network.jsonl` 中 `storage_tracking_candidate` 是 `is_actual=false` 的
试算，完整保存输入及 AC 拒绝原因；`storage_tracking_response` 保存选定状态。
周期末 `storage_tracking` 保存基准、候选（未试算为 null）、投影提案、选定功率、
容差、状态、未服务请求及最终 PCC 误差。无效 AC 的误差为 null，不能用零冒充。

状态为 `adopted`、`network_rejected`、`not_improved`、`baseline_unsafe`、`blocked`、
`unchanged`、`physical_override`。其中 `baseline_unsafe` 包含有效但越限与输入未知，
原 AC 记录保留二者区别。既有 `storage-dynamics-v1` 的 `ordinary_mw` 表示普通
阶段选定功率，`ordinary_unserved_mw=requested_mw-ordinary_mw`；`actual_mw` 仍是
后续保护处理后的最终功率。被拒绝的投影不会记为普通阶段已采用。
历史缺失采用记录时保持缺失，不据此认定历史运行采用了本机制。

## 验证算例

三母线、10 MVA 基准，两支路均为 `r=0.001 pu,x=0.002 pu`。储能所在支路
负荷 0.4 MW、限额 0.6 MVA；另一支路负荷和光伏均为 1 MW。基准储能 0 MW，
PCC 约 0.400016 MW，目标 0.800032 MW，基准支路负载率约 0.666693。
投影允许约 -0.400016 MW 充电，候选 PCC 约 0.800080 MW，误差显著减小，
但储能支路负载率约 1.333467，故拒绝并保留基准。只将支路容量改为 2 MVA
时，该候选安全并被采用。该对照调用实际 AC 求解和完整分钟执行器。

测试入口：`tests/unit/control/test_storage_tracking.py`、
`tests/integration/control/test_storage_tracking.py`；相关保护、单次能量和总爬坡
回归位于 `tests/integration/control/test_device_dynamics.py`。
