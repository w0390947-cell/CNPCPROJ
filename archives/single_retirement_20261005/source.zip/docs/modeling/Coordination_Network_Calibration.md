# 协调层网络校准 v1

模型标识：`coordination-network-calibration-v1`。
责任：优化调度维护负责人；网络补偿语义沿用 `network_model.ShuntCompensator`。

## 无功收支与符号

对每区域、每计划时段，协调模型采用：

```text
P_PCC + P_renewable + P_discharge - P_charge = P_load + P_series_loss
Q_PCC + Q_controllable = Q_load + Q_series_loss - Q_fixed_shunt_reference
Q_fixed_shunt_reference(t) = Σ_b Q_nominal(b, resolved_mode) × |V_reference(b,t)|²
```

PCC 正值表示受电/吸收无功；设备正 Q 表示注入。
电容的 `Q_nominal` 为正，电抗器为负；单位 MW、Mvar，电压为 pu。
串联损耗与固定补偿分别存储，补偿可能超过串联无功损耗，净网络无功需求可为负。
固定补偿不属于 SVG、风光或储能的可控无功容量。

电网台账负责解析当前运行方式的投退和档位。同一母线的固定元件先合计
额定无功；同母线电容、电抗器因共享同一电压，其代数合计仍满足上述关系。
区域 MISOCP 与独立 AC 保留原恒导纳方程，未改变校核容差或准入规则。

## 契约与适用条件

`dispatch.contracts.CoordinationNetworkCalibration` 保存不可变元组：逐时段
`p_loss_mw`、`q_loss_mvar` 和逐母线 `FixedShuntReference`。
后者保存母线 ID、已解析额定注入及其参考实际注入序列，保留正负号。
模型版本与此契约绑定；ADR 0039 将其纳入恢复记录，允许显式提供同一 v1
版本以支持 JSON 往返，未知版本拒绝。不改写历史结果。

`build_coordination_calibration` 从既有参考解字段复制数据，检查维数、有限值、
母线映射、补偿方向和非负串联损耗。该函数本身不求解或签发 AC 证书；
正式服务及旧分层入口从各自已有的参考求解结果生成数据，原准入检查继续负责
相应求解有效性。不得把任意构造的校准值当作已验证的参考解。

协调消费者按当前网络解析结果，逐母线验证额定补偿与参考一致。投入、退出、
档位、方向或母线变化造成不一致时拒绝旧校准。额定值的比较容差仅为
`rel_tol=1e-12, abs_tol=1e-12 Mvar` 的数值同一性判断，不是运行越限容差。
相同母线的净补偿不变时，元件组合变化在本聚合方程中等价。

无有效补偿的区域仍接受旧 `p_loss_mw/q_loss_mvar` 字典及原无校准损耗裕度。
**存在非零已解析固定补偿时，必须提供新契约且包含匹配的补偿证据。**
缺失数据明确抛出 `ValueError`，不默认补偿为零，也不隐式假定 V=1 pu。
旧字典的无补偿调用继续兼容；带补偿的旧调用需要迁移到新构造 API。

## 滚动窗口与近似边界

序列轴是原输入计划时段的时间顺序。装配边界以原计划时段索引截取/保持
串联损耗和补偿参考；常规滚动及分钟短窗口使用相同索引，允许重复索引。
窗口数据是新不可变对象；模型复用时重新设置补偿项。

协调层将参考电压产生的注入作为外生常数，仍是凸协调问题。参考电压不等于
重新优化后的实际电压。后续 ADR 0039 已在主日前/滚动路径接入区域失败后的
有界校准刷新，见 [跨层参考恢复](Coordination_Feasibility_Recovery.md)。
这不保证任意新工况下的目标都可落实，也不证明整条动态轨迹安全。
区域完整模型和独立 AC 仍为采用条件。

## 验证

- `tests/unit/dispatch/test_network_calibration.py`：带电压变化的电容/电抗器
  手算、母线顺序、输入不可变性、缺失/非有限/错维数据、投退和档位不一致、窗口选择。
- `tests/integration/dispatch/test_fixed_shunt_coordination.py`：真实三区域
  ADMM/MISOCP/AC 电容、电抗器、退出对照；主/旧入口数据传递；模型复用和
  常规/分钟滚动窗口校准对齐。网络试验关闭可调资源，防止其他无功掩盖缺项。
- 既有协调能力、模型复用、P/Q 跟踪、网络/MISOCP 和架构检查继续执行。

原审计报告和原始反例证据保留，修复后的验证单独记录。
