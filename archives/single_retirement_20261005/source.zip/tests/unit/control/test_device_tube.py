"""Path capabilities, one shared response budget and zero-order-hold SOC."""

import pytest

from oilfield_energy.modules.control.api import (
    certify_device_transition,
    execute_tube_command,
    point_box,
)
from oilfield_energy.modules.control.contracts import (
    TubeCommand,
    TubeDeviceModel,
    TubeResource,
    TubeState,
)
from oilfield_energy.kernel.intervals import Interval as I


def model():
    return TubeDeviceModel(
        resources=(
            TubeResource(
                resource_id="w",
                bus="b",
                kind="wind",
                p=I(low=0, high=3),
                q=I(low=-1, high=1),
                s_mva=4,
                q_over_p=0.3,
                alpha_p=0.5,
                ramp_p_mw=1,
            ),
            TubeResource(
                resource_id="s",
                bus="b",
                kind="storage",
                p=I(low=-1, high=1),
                q=I(low=-1, high=1),
                s_mva=2,
                alpha_p=1,
                ramp_p_mw=0.9,
            ),
        ),
        alpha_q=0.4,
        aggregate_q_ramp_mvar=0.9,
        step_minutes=1,
        energy_mwh=I(low=0.2, high=2),
        eta_charge=0.9,
        eta_discharge=0.8,
        context_id="fixed",
    )


def test_capability_box_rejects_p_drop_before_q_can_recover():
    state = TubeState(p_mw=(2, 0), q_mvar=(0.57, 0), energy_mwh=1)
    command = TubeCommand(p_mw=(1.6, 0), q_mvar=(0.4, 0))
    with pytest.raises(ValueError, match="path capability"):
        certify_device_transition(model(), point_box(state), command)
    assert state.q_mvar[0] == 0.57


def test_opposing_q_moves_cannot_cancel_the_cycle_budget():
    state = TubeState(p_mw=(3, 0), q_mvar=(0.8, -0.8), energy_mwh=1)
    command = TubeCommand(p_mw=(3, 0), q_mvar=(-0.8, 0.8))
    with pytest.raises(ValueError, match="aggregate response"):
        certify_device_transition(model(), point_box(state), command)


def test_storage_energy_and_response_have_an_independent_integral_check():
    state = TubeState(p_mw=(2, 0), q_mvar=(0, 0), energy_mwh=1)
    command = TubeCommand(p_mw=(2.2, 0.4), q_mvar=(0.1, 0))
    step = certify_device_transition(model(), point_box(state), command)
    actual = execute_tube_command(model(), state, command)
    assert actual.energy_mwh == pytest.approx(1 - 0.4 / 0.8 / 60)
    assert actual.p_mw == pytest.approx((2.1, 0.4))
    assert actual.q_mvar == pytest.approx((0.04, 0))
    assert step.path.energy_mwh.contains(actual.energy_mwh)
    with pytest.raises(ValueError, match="energy envelope"):
        execute_tube_command(
            model(), state.model_copy(update={"energy_mwh": 0.2}), command
        )


def test_finite_settling_uses_the_same_monotone_map_in_execution_and_enclosure():
    from oilfield_energy.modules.control.contracts import TubeBox

    m = model().model_copy(update={"version": "unified-device-v1", "settling_resolution": .0001})
    box = TubeBox(p_mw=(I(low=.00019, high=.00021), I(low=0, high=0)),
        q_mvar=(I(low=0, high=0), I(low=0, high=0)), energy_mwh=I(low=1, high=1))
    command = TubeCommand(p_mw=(0, 0), q_mvar=(0, 0))
    proof = certify_device_transition(m, box, command)
    assert proof.endpoint.p_mw[0].low == 0
    assert proof.endpoint.p_mw[0].high >= .000105
    for p in [.00019, .0002, .00021]:
        actual = execute_tube_command(m, TubeState(p_mw=(p, 0), q_mvar=(0, 0), energy_mwh=1), command)
        assert proof.endpoint.p_mw[0].contains(actual.p_mw[0])
        assert actual.p_mw[0] == (0 if p <= .0002 else p/2)


def test_matched_pq_curtailment_preserves_convex_capability_without_rectangle_artifact():
    m = model().model_copy(update={"alpha_q": .5})
    state = TubeState(p_mw=(2, 0), q_mvar=(.58, 0), energy_mwh=1)
    command = TubeCommand(p_mw=(1, 0), q_mvar=(.29, 0))
    certificate = certify_device_transition(m, point_box(state), command)
    # The rectangle contains an impossible combination (P=1.5, Q=.58).
    assert certificate.path.q_mvar[0].high > .3*certificate.path.p_mw[0].low
    # Actual matched responses traverse one convex segment, always admissible.
    for fraction in [0, .1, .25, .5, 1]:
        p, q = 2-fraction, .58-.29*fraction
        assert abs(q) <= .3*p
