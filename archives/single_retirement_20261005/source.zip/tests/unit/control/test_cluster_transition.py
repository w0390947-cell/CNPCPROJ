"""Analytic intersample counterexamples, invariants and finite failure semantics."""

from math import exp, inf, log, nextafter
from random import Random

import pytest

from oilfield_energy.modules.control.api import authorize_cluster_transition
from oilfield_energy.modules.control.contracts import RegionalTransitionProposal, TransitionActuator
from oilfield_energy.modules.power_flow.api import thermal_loss_upper_bound


def region(name, load, previous, proposed, *, defer=True, loss=0.0, minute=0):
    return RegionalTransitionProposal(
        region=name,
        start_minute=minute,
        duration_minutes=1,
        gross_load_upper_mw=load,
        loss_upper_mw=loss,
        loss_basis="lossless" if loss == 0 else "explicit-upper-bound",
        actuators=(
            TransitionActuator(
                actuator="generator",
                previous_mw=previous,
                proposed_mw=proposed,
                defer_to_mw=max(previous, proposed) if defer else proposed,
            ),
        ),
    )


def choose(proposals, limit=10):
    return authorize_cluster_transition(
        proposals,
        expected_regions=tuple(p.region for p in proposals),
        limit_mw=limit,
    )


def values(decision):
    return {s.region: s.setpoints[0].p_mw for s in decision.selections}


def test_original_ten_mw_witness_is_deferred_and_converges_without_overshoot():
    # Independent analytic uncontrolled trajectories, not a full AC simulation.
    peak_time = log(8) / 3.5

    def uncontrolled(t):
        return 10 + 0.5 * (exp(-t / 2) - exp(-4 * t))

    assert uncontrolled(1) == pytest.approx(10.294107510411951)
    assert uncontrolled(peak_time) > uncontrolled(1)
    wind, pv = 0.0, 0.5
    envelopes = []
    for minute in range(25):
        proposals = (
            region("A", 5, wind, wind + (1 - exp(-0.5)) * (0.5 - wind), minute=minute),
            region("B", 4.5, pv, pv * exp(-4), minute=minute),
            region("C", 1, 0, 0, minute=minute),
        )
        decision = choose(proposals)
        assert decision.status == "certified"
        if minute == 0:
            assert values(decision)["B"] == 0.5
            assert decision.requested_upper_mw > 10.49
        new = values(decision)
        # Independent first-order interpolation to each selected endpoint;
        # each full closed interval is additionally bounded by the proved box.
        for j in range(101):
            t = j / 100
            w = wind + (new["A"] - wind) * (1 - exp(-t / 2)) / (1 - exp(-0.5))
            p = pv + (new["B"] - pv) * (1 - exp(-4 * t)) / (1 - exp(-4))
            assert 10.5 - w - p <= decision.selected_upper_mw + 2e-15
        envelopes.append(decision.selected_upper_mw)
        wind, pv = new["A"], new["B"]
    assert max(envelopes) <= 10
    assert abs(wind - 0.5) < 2e-6 and pv < 4e-6


def test_two_safe_sample_points_can_hide_an_unsafe_intersample_peak():
    def p(t):
        return 10 + 0.375 * (1 - exp(-4 * t)) - (1 - exp(-t / 2))

    assert p(0) == 10 and p(1) < 10
    assert p(log(3) / 3.5) > 10.12
    result = choose((region("A", 5, 0, 1 - exp(-0.5)), region("B", 5.375, 0.375, 0.375 * exp(-4))))
    assert result.status == "certified"
    assert values(result)["B"] >= 0.375  # No credit for not-yet-realized wind.
    assert result.selected_upper_mw <= 10


def test_mandatory_decrease_is_never_undone_to_manufacture_capacity():
    proposal = (region("A", 10.5, 0.5, 0, defer=False),)
    result = choose(proposal)
    assert result.status == "unproven" and not result.selections
    assert result.selected_upper_mw is None


def test_losses_and_load_jumps_cannot_be_paid_with_future_generation():
    for proposal in ((region("A", 10.1, 0, 2),), (region("A", 10, 0, 2, loss=0.1),)):
        assert choose(proposal).status == "unproven"


def test_safe_switch_keeps_proposals_and_canonical_id_order():
    proposals = (region("B", 4, 1, 0.8), region("A", 4, 1, 2))
    result = choose(proposals)
    assert values(result) == {"A": 2, "B": 0.8}
    assert result == choose(proposals[::-1])
    assert proposals[0].actuators[0].proposed_mw == 0.8


def test_exact_boundary_and_one_ulp_violation_do_not_share_a_pass():
    assert choose((region("A", 10, 0, 0),)).selected_upper_mw == 10
    assert choose((region("A", nextafter(10.0, inf), 0, 0),)).status == "unproven"


@pytest.mark.parametrize("bad", [float("nan"), float("inf"), -1])
def test_invalid_load_or_loss_is_rejected(bad):
    with pytest.raises(ValueError):
        region("A", bad, 0, 0)
    with pytest.raises(ValueError):
        region("A", 0, 0, 0, loss=bad)


def test_identity_time_and_authority_validation():
    a = region("A", 1, 0, 0)
    with pytest.raises(ValueError, match="exactly once"):
        choose((a, a))
    with pytest.raises(ValueError, match="interval"):
        choose((a, region("B", 1, 0, 0, minute=1)))
    with pytest.raises(ValueError, match="deferral"):
        TransitionActuator(actuator="x", previous_mw=0, proposed_mw=1, defer_to_mw=2)


def test_random_box_members_respect_the_joint_bound():
    rng = Random(630)
    for _ in range(100):
        proposals = tuple(
            region(str(i), rng.uniform(2, 4), rng.uniform(0, 2), rng.uniform(0, 2), loss=0.05)
            for i in range(3)
        )
        result = choose(proposals)
        if result.status != "certified":
            continue
        selected = values(result)
        for _ in range(50):
            total = sum(
                p.gross_load_upper_mw
                + p.loss_upper_mw
                - (
                    p.actuators[0].previous_mw
                    + rng.random() * (selected[p.region] - p.actuators[0].previous_mw)
                )
                for p in proposals
            )
            assert total <= result.selected_upper_mw + 3e-15 <= 10 + 3e-15


def test_receiving_end_current_loss_bound_includes_transformer_taps_implicitly():
    # |I| <= 2 MVA / (10 MVA * 0.8 pu) = 0.25 pu, loss=0.0625 MW.
    bound = thermal_loss_upper_bound(
        base_mva=10,
        minimum_voltage_pu=0.8,
        resistance_and_rating=((0.1, 2),),
    )
    assert bound == pytest.approx(0.0625)
    assert (
        thermal_loss_upper_bound(
            base_mva=10, minimum_voltage_pu=0.8, resistance_and_rating=((0, 2),)
        )
        == 0
    )


def test_roundoff_allowance_is_charged_to_capacity_instead_of_relaxing_the_limit():
    proposal = region("A", 10.5, 0.5, 0.5).model_copy(update={"injection_roundoff_mw": 1e-8})
    assert choose((proposal,)).status == "unproven"
