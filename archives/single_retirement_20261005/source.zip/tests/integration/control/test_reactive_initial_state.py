"""A3: real AC predictions from outside capability, including bounded failure."""

from dataclasses import replace
from datetime import datetime, timezone
from math import exp

import numpy as np
import pytest

from oilfield_energy.data import Line, MicrogridData, ModelAssumptions, ProjectCase, Storage
from oilfield_energy.device_control import simulate_device_tracking
from oilfield_energy.hierarchy_types import TimeScaleConfig
from oilfield_energy.modules.control.contracts import BusSeries, PlantInputs
from oilfield_energy.modules.dispatch.contracts import (
    AdoptedOrigin,
    AdoptedSchedule,
    ResourceTrajectory,
)
from oilfield_energy.network_model import assess_network_model, build_legacy_network_model_v2
from oilfield_energy.network_scenarios import NetworkSecurityLimits
from oilfield_energy.reactive_correction import correct_reactive_dispatch
from oilfield_energy.reactive_execution import ReactiveCapability


def correction(
    *,
    initial=(1.5,),
    lower=(-1.305,),
    upper=(1.305,),
    target=(-1.305,),
    alpha=1 - exp(-0.5),
    ramp=0.9,
    project=None,
    limits=None,
):
    model = build_legacy_network_model_v2(
        network_id="a3-q-state",
        buses=["A", "B"],
        pcc_bus_id="A",
        base_mva=10.0,
        lines=[Line("AB", "A", "B", 0.001, 0.001, 6.0)],
    )
    network = assess_network_model(model).require_current_solver_ready()
    # Gross Q=0; net demand corresponds to the TRUE initial Q.
    current = np.array(initial)
    result = correct_reactive_dispatch(
        network,
        limits or NetworkSecurityLimits(0.95, 1.05, 0.15, 4.0, 0.9),
        p_demand_mw=np.array([0.0, 3.0]),
        q_demand_before_mvar=np.array([0.0, -sum(initial)]),
        resource_buses=["B"] * len(initial),
        current_q=current,
        preferred_targets=np.array(target),
        capabilities=tuple(
            ReactiveCapability(str(i), lo, hi) for i, (lo, hi) in enumerate(zip(lower, upper))
        ),
        project_targets=project or (lambda x: x),
        slack_voltage_pu=1.0,
        alpha=alpha,
        ramp_mvar=ramp,
    )
    np.testing.assert_array_equal(current, initial)
    return result


@pytest.mark.parametrize("sign", [1.0, -1.0])
def test_actual_ac_accepts_recovery_using_true_initial_state(sign):
    result = correction(initial=(sign * 1.5,), target=(-sign * 1.305,))
    assert result.status == "safe"
    assert result.predicted_actual == pytest.approx((sign * 0.6,), abs=1e-10)
    assert abs(result.predicted_actual[0] - sign * 1.5) <= 0.9 + 1e-10
    assert result.minimum_constraint_margin >= -1e-8


def test_network_safe_response_outside_device_capacity_cannot_be_certified():
    # With alpha=.05 even commanding -1.305 cannot reach the new upper bound.
    result = correction(alpha=0.05)
    assert result.status in ("best_effort", "held")
    assert result.predicted_actual[0] > 1.305
    assert result.minimum_constraint_margin < 0


def test_zero_budget_and_rejected_projection_keep_actual_outside_state():
    for kwargs in ({"ramp": 0.0}, {"project": lambda _: np.array([1.5])}):
        result = correction(**kwargs)
        assert result.status == "held"
        assert result.predicted_actual == pytest.approx((1.5,), abs=1e-12)
        assert result.minimum_constraint_margin < 0


def test_fixed_zero_command_can_make_partial_progress_without_claiming_safety():
    result = correction(initial=(1.0,), lower=(0.0,), upper=(0.0,), target=(0.0,), alpha=0.4)
    assert result.status == "best_effort"
    assert result.targets == pytest.approx((0.0,), abs=1e-12)
    assert result.predicted_actual == pytest.approx((0.6,), abs=1e-12)
    assert result.minimum_constraint_margin < 0


def test_failed_network_evidence_does_not_rewrite_outside_initial_state():
    limits = replace(NetworkSecurityLimits(0.95, 1.05, 0.15, 4.0, 0.9), max_iterations=1)
    result = correction(limits=limits)
    assert result.status == "unavailable"
    assert result.predicted_actual == pytest.approx((1.5,), abs=1e-12)


def cycle(*, ramp=0.9, invalid_snapshot=False):
    """One explicit cycle; availability drops P, without an optimizer or daily run."""
    model = build_legacy_network_model_v2(
        network_id="a3-cycle",
        buses=["A", "B"],
        pcc_bus_id="A",
        base_mva=10.0,
        lines=[Line("AB", "A", "B", 0.001, 0.001, 12.0)],
    )
    mg = MicrogridData(
        name="a3",
        buses=["A", "B"],
        lines=[Line("AB", "A", "B", 0.001, 0.001, 12.0)],
        pcc_bus="A",
        base_mva=10.0,
        maximum_load_mw=8.0,
        p_grid_max_mw=6.0,
        p_grid_min_mw=0.15,
        voltage_min_pu=0.95,
        voltage_max_pu=1.05,
        load_p_mw={"A": np.zeros(1), "B": np.array([8.0])},
        load_q_mvar={"A": np.zeros(1), "B": np.zeros(1)},
        wind_available_mw={"B": np.array([4.35])},
        wind_capacity_mw={"B": 5.0},
        wind_capacity_mva={"B": 5.5},
        wind_q_abs_over_p_max={"B": 0.3},
        wind_q_abs_max_mvar={"B": 1.5},
        pv_available_mw={"B": np.zeros(1)},
        pv_capacity_mw={"B": 1.0},
        pv_capacity_mva={"B": 1.1},
        pv_reactive_enabled={"B": False},
        storage=Storage("B", 2.5, 5.0, 0.5, 5.0, 0.95, 0.95, 2.7),
        storage_reactive_enabled=False,
        svg_bus="B",
        svg_q_min_mvar=-1.8,
        svg_q_max_mvar=1.8,
        network_model_v2=model,
        network_operating_mode_id=model.default_operating_mode_id,
    )
    case = ProjectCase(
        time_hours=np.zeros(1),
        price_cny_per_mwh=np.ones(1),
        microgrids=[mg],
        assumptions=ModelAssumptions(dt_hours=1 / 60),
        cluster_import_limit_mw=6.0,
    )
    plan = AdoptedSchedule(
        microgrid_id=mg.name,
        start=datetime(2026, 1, 1, tzinfo=timezone.utc),
        step_minutes=1,
        p_grid_mw=(3.65,),
        q_grid_mvar=(1.0,),
        wind_available_mw=(4.35,),
        resource_schedules=tuple(
            ResourceTrajectory(
                resource_id=mg.resource_id(kind, "B"),
                bus_id="B",
                resource_type=kind,
                active_power_mw=(p,),
                reactive_power_mvar=(q,),
            )
            for kind, p, q in (
                ("wind", 5.0, 1.5),
                ("pv", 0.0, 0.0),
                ("storage", 0.0, 0.0),
                ("svg", 0.0, 0.0),
            )
        ),
        origins=(AdoptedOrigin(interval_index=0, window_start_interval=0, window_end_interval=1),),
    )

    def adapt(snapshot, stage):
        return (
            replace(snapshot, quality_valid=False)
            if invalid_snapshot and stage == "pre_reactive"
            else snapshot
        )

    plant = PlantInputs(
        start=plan.start,
        step_minutes=1,
        load_p=(BusSeries(bus_id="A", values=(0.0,)), BusSeries(bus_id="B", values=(8.0,))),
        load_q=(BusSeries(bus_id="A", values=(0.0,)), BusSeries(bus_id="B", values=(0.0,))),
        wind_available=(BusSeries(bus_id="B", values=(4.35,)),),
        pv_available=(BusSeries(bus_id="B", values=(0.0,)),),
    )
    return simulate_device_tracking(
        case,
        mg,
        plan,
        storage_enabled=False,
        reverse_flow_probability_15=np.zeros(1),
        config=TimeScaleConfig(reactive_power_ramp_mvar_per_minute=ramp),
        network_snapshot_adapter=adapt,
        plant_inputs=plant,
    )


def test_cycle_records_real_initial_state_and_keeps_the_whole_response_budget():
    result = cycle()
    before = next(r for r in result.network_feedback if r["stage"] == "pre_reactive")
    after = next(r for r in result.network_feedback if r["stage"] == "post_control")
    control = after["reactive_control"]
    assert before["device_capacity_within_limits"] is False
    assert before["inputs"]["snapshot"]["devices"][0]["q_mvar"] == 1.5
    assert before["inputs"]["snapshot"]["devices"][0]["p_mw"] == 4.35
    assert control["q_before_mvar"][0] == 1.5
    dynamics = control["dynamics"]
    assert dynamics["version"] == "reactive-dynamics-v1"
    assert not dynamics["initial_capacity_within_limits"]
    assert dynamics["q_maximum_mvar"][0] == pytest.approx(1.305, abs=1e-12)
    assert dynamics["ramp_compliant"] and dynamics["response_matches_prediction"]
    movement = sum(abs(q - q0) for q, q0 in zip(control["q_executed_mvar"], [1.5, 0.0, 0.0, 0.0]))
    assert movement <= 0.9 + 1e-9
    assert dynamics["aggregate_movement_mvar"] == pytest.approx(movement, abs=1e-10)
    assert after["device_capacity_within_limits"] is True
    assert control["post_action_safe"]
    # Endpoint recovery does not erase the actually observed initial violation.
    assert result.network_violation_steps == 1
    assert not result.network_security_passed


@pytest.mark.parametrize("kwargs", [{"ramp": 0.0}, {"invalid_snapshot": True}])
def test_cycle_without_response_does_not_clip_state_or_claim_safety(kwargs):
    result = cycle(**kwargs)
    after = next(r for r in result.network_feedback if r["stage"] == "post_control")
    control = after["reactive_control"]
    assert control["q_before_mvar"][0] == control["q_executed_mvar"][0] == 1.5
    assert not control["post_action_safe"]
    assert after["device_capacity_within_limits"] is False
    assert control["dynamics"]["aggregate_movement_mvar"] == 0.0
    assert not control["dynamics"]["actual_capacity_within_limits"]
    if kwargs.get("ramp") == 0.0:
        assert not control["dynamics"]["capability_reachable_without_arbitration"]
