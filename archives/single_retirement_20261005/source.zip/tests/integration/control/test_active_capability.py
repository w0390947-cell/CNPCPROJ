"""A2: fixed-state AC evidence and one-cycle candidate adoption, no daily study."""

from dataclasses import asdict, replace
from datetime import datetime, timezone

import numpy as np
import pytest

from oilfield_energy.data import (
    Line,
    MicrogridData,
    ModelAssumptions,
    ProjectCase,
    Storage,
)
from oilfield_energy.device_control import simulate_device_tracking
from oilfield_energy.minute_network import MinuteNetworkConfig, MinuteNetworkEvaluator
from oilfield_energy.modules.dispatch.contracts import (
    AdoptedOrigin,
    AdoptedSchedule,
    ResourceTrajectory,
)
from oilfield_energy.modules.resources.contracts import WindReactiveCapability
from oilfield_energy.network_model import build_legacy_network_model_v2
from oilfield_energy.network_scenarios import NetworkSecurityLimits
from oilfield_energy.power_flow_comparison import (
    BusLoadState,
    DevicePerturbation,
    DeviceState,
    FixedStateSnapshot,
    device_capability_violations,
    perturb_snapshot,
)
from oilfield_energy.resource_control_contracts import ResourceType

AT = datetime(2026, 1, 1, tzinfo=timezone.utc)


def network():
    return build_legacy_network_model_v2(
        network_id="a2-capability-regression",
        buses=["A", "B"],
        pcc_bus_id="A",
        base_mva=10.0,
        lines=[Line("AB", "A", "B", 0.001, 0.001, 6.0)],
    )


def wind(p=2.0, q=0.57, *, identity="wind", curve=None):
    return DeviceState(
        identity,
        "B",
        ResourceType.WIND,
        p,
        q,
        True,
        p_min_mw=0.0,
        p_max_mw=5.0,
        q_min_mvar=-1.5,
        q_max_mvar=1.5,
        s_max_mva=5.5,
        wind_reactive_capability=curve or WindReactiveCapability(5.5, 0.3, 1.5),
    )


def snapshot(*devices):
    return FixedStateSnapshot(
        "a2",
        AT,
        "synthetic A2 fixed-state example",
        "gross_bus_load",
        1.0,
        True,
        True,
        (BusLoadState("A", 0.0, 0.0), BusLoadState("B", 3.5, 0.57)),
        tuple(devices),
    )


def evaluator(devices):
    return MinuteNetworkEvaluator(
        network(),
        NetworkSecurityLimits(0.95, 1.05, 0.15, 4.0, 0.9),
        {d.resource_id: d.bus_id for d in devices},
        config=MinuteNetworkConfig(require_device_capabilities=True),
    )


def test_original_counterexample_improves_pcc_but_fails_device_capability():
    original = snapshot(wind())
    frozen = asdict(original)
    candidate = perturb_snapshot(original, DevicePerturbation("wind", "p_mw", -0.2))
    check = evaluator(original.devices)
    base = check.evaluate(original, at=AT, operating_mode_id=network().default_operating_mode_id)
    trial = check.evaluate(candidate, at=AT, operating_mode_id=network().default_operating_mode_id)
    assert base.recovery_safe
    assert base.flow.pcc_import_mw == pytest.approx(1.5002250675202564, abs=1e-10)
    assert trial.flow.pcc_import_mw == pytest.approx(1.7002890982934202, abs=1e-10)
    assert trial.valid and not trial.flow.violations
    assert trial.voltage_within_limits and trial.line_capacity_within_limits
    assert trial.device_capacity_within_limits is False
    assert not trial.recovery_safe
    assert trial.device_violations == (
        {
            "resource_id": "wind",
            "code": "WIND_Q_CAPABILITY",
            "actual": 0.57,
            "limit": pytest.approx(0.54),
        },
    )
    assert candidate.devices[0].q_mvar == 0.57
    assert (
        candidate.devices[0].wind_reactive_capability
        is original.devices[0].wind_reactive_capability
    )
    assert asdict(original) == frozen


@pytest.mark.parametrize("q,violated", [(0.54, False), (-0.54, False), (0.57, True), (-0.57, True)])
def test_signed_q_and_exact_ratio_boundary(q, violated):
    result = device_capability_violations(snapshot(wind(1.8, q)), 1e-9)
    assert bool(result) is violated


def test_mva_absolute_and_ratio_limits_intersect_and_check_each_resource():
    # Rising P shrinks converter headroom even when the ratio would permit Q.
    first = wind(4.0, 2.0, curve=WindReactiveCapability(5.0, 1.0, 3.0))
    first = replace(first, q_min_mvar=-3.0, q_max_mvar=3.0, s_max_mva=5.0)
    assert not device_capability_violations(snapshot(first), 1e-9)
    assert any(
        v["code"] == "S_MAX"
        for v in device_capability_violations(snapshot(replace(first, p_mw=4.9)), 1e-9)
    )
    limited = wind(2.0, 0.45, identity="absolute", curve=WindReactiveCapability(5.5, 0.3, 0.4))
    other = wind(2.0, -0.25, identity="ratio", curve=WindReactiveCapability(5.5, 0.1, 1.5))
    violations = device_capability_violations(snapshot(wind(), limited, other), 1e-9)
    assert {v["resource_id"] for v in violations} == {"absolute", "ratio"}
    assert {v["limit"] for v in violations} == {0.4, 0.2}
    assert violations == device_capability_violations(snapshot(other, limited, wind()), 1e-9)[::-1]


@pytest.mark.parametrize(
    "device",
    [replace(wind(), p_max_mw=None), replace(wind(), wind_reactive_capability=None)],
)
def test_missing_capability_is_unknown_and_cannot_authorize_adoption(device):
    result = evaluator((device,)).evaluate(
        snapshot(device), at=AT, operating_mode_id=network().default_operating_mode_id
    )
    assert not result.valid and not result.recovery_safe
    assert result.device_capacity_within_limits is None
    assert result.reasons == ("DEVICE_CAPABILITY_MISSING:wind",)


def test_explicit_converter_only_curve_remains_a_supported_historical_model():
    device = wind(q=0.9, curve=WindReactiveCapability(5.5))
    assert device.capability_complete
    assert not device_capability_violations(snapshot(device), 1e-9)
    assert not device_capability_violations(snapshot(wind(0.0, 0.0)), 1e-9)
    assert device_capability_violations(snapshot(wind(0.0, 0.01)), 1e-9)


def one_cycle(*, q=0.57, adapter=None, storage_enabled=False, pv_authorized=False):
    """Explicit one-minute input; no optimizer or multi-window simulation."""
    buses = ["A", "B"]
    mg = MicrogridData(
        name="a2",
        buses=buses,
        lines=[Line("AB", "A", "B", 0.001, 0.001, 6.0)],
        pcc_bus="A",
        base_mva=10.0,
        maximum_load_mw=3.5,
        p_grid_max_mw=4.0,
        p_grid_min_mw=0.15,
        voltage_min_pu=0.95,
        voltage_max_pu=1.05,
        load_p_mw={"A": np.zeros(1), "B": np.array([3.5])},
        load_q_mvar={"A": np.zeros(1), "B": np.array([0.57])},
        wind_available_mw={"B": np.array([5.0])},
        wind_capacity_mw={"B": 5.0},
        wind_capacity_mva={"B": 5.5},
        wind_q_abs_over_p_max={"B": 0.3},
        wind_q_abs_max_mvar={"B": 1.5},
        pv_available_mw={"B": np.zeros(1)},
        pv_capacity_mw={"B": 1.0},
        pv_capacity_mva={"B": 1.1},
        pv_reactive_enabled={"B": pv_authorized},
        storage=Storage("B", 2.5, 5.0, 0.5, 5.0, 0.95, 0.95, 2.7),
        storage_reactive_enabled=False,
        svg_bus="B",
        svg_q_min_mvar=-1.8,
        svg_q_max_mvar=1.8,
        network_model_v2=network(),
        network_operating_mode_id=network().default_operating_mode_id,
    )
    case = ProjectCase(
        time_hours=np.zeros(1),
        price_cny_per_mwh=np.ones(1),
        microgrids=[mg],
        assumptions=ModelAssumptions(dt_hours=1 / 60),
        cluster_import_limit_mw=4.0,
    )
    plan = AdoptedSchedule(
        microgrid_id=mg.name,
        start=AT,
        step_minutes=1,
        p_grid_mw=(1.7002890982934202,),
        q_grid_mvar=(0.0,),
        wind_available_mw=(5.0,),
        resource_schedules=tuple(
            ResourceTrajectory(
                resource_id=mg.resource_id(kind, "B"),
                bus_id="B",
                resource_type=kind,
                active_power_mw=(p,),
                reactive_power_mvar=(reactive,),
            )
            for kind, p, reactive in (
                ("wind", 2.0, q),
                ("pv", 0.0, 0.0),
                ("storage", 0.0, 0.0),
                ("svg", 0.0, 0.0),
            )
        ),
        origins=(AdoptedOrigin(interval_index=0, window_start_interval=0, window_end_interval=1),),
    )
    before = (mg.storage, dict(mg.wind_q_abs_over_p_max))
    result = simulate_device_tracking(
        case,
        mg,
        plan,
        storage_enabled=storage_enabled,
        reverse_flow_probability_15=np.zeros(1),
        network_snapshot_adapter=adapter,
    )
    assert mg.storage == before[0] and mg.wind_q_abs_over_p_max == before[1]
    return result


def record(result, stage):
    return next(r for r in result.network_feedback if r["stage"] == stage)


@pytest.mark.parametrize("storage_enabled", [False, True])
def test_one_cycle_rejects_qp_violation_and_preserves_baseline_without_latching(
    storage_enabled,
):
    result = one_cycle(storage_enabled=storage_enabled)
    trial = record(result, "active_tracking_candidate")
    assert trial["device_capacity_within_limits"] is False
    assert any(v["code"] == "WIND_Q_CAPABILITY" for v in trial["device_violations"])
    assert trial["is_actual"] is False
    before = record(result, "storage_tracking_response")["inputs"]["snapshot"]
    kept = record(result, "pre_control")["inputs"]["snapshot"]
    assert before["devices"] == kept["devices"]
    assert record(result, "post_control")["active_tracking"]["status"] == "network_rejected"
    assert not np.any(result.network_recovery_blocked)
    assert result.wind_actual_mw[0] == 2.0
    assert result.storage_energy_mwh[0] == 5.0


def test_legal_candidate_is_still_adopted_and_all_capabilities_are_present():
    result = one_cycle(q=0.53)
    trial = record(result, "active_tracking_candidate")
    assert trial["device_capacity_within_limits"] is True
    assert record(result, "post_control")["active_tracking"]["status"] == "adopted"
    assert result.wind_actual_mw[0] < 2.0
    assert result.network_context["device_capability_version"] == "device-capability-v2"
    for device in trial["inputs"]["snapshot"]["devices"]:
        assert all(
            device[key] is not None
            for key in ("p_min_mw", "p_max_mw", "q_min_mvar", "q_max_mvar", "s_max_mva")
        )
        if device["resource_type"] is ResourceType.PV:
            assert device["q_min_mvar"] == device["q_max_mvar"] == 0


@pytest.mark.parametrize("change", ["missing_curve", "clip_q"])
def test_probe_cannot_omit_curve_or_change_q_to_obtain_adoption(change):
    def adapt(snapshot, stage):
        if stage != "active_tracking_candidate":
            return snapshot
        return replace(
            snapshot,
            devices=tuple(
                replace(
                    d,
                    **(
                        {"wind_reactive_capability": None}
                        if change == "missing_curve"
                        else {"q_mvar": 0.5}
                    ),
                )
                if d.resource_type is ResourceType.WIND
                else d
                for d in snapshot.devices
            ),
        )

    result = one_cycle(adapter=adapt)
    trial = record(result, "active_tracking_candidate")
    assert not trial["valid"]
    assert record(result, "post_control")["active_tracking"]["status"] == "network_rejected"
    assert not np.any(result.network_recovery_blocked)
    assert result.wind_actual_mw[0] == 2.0
