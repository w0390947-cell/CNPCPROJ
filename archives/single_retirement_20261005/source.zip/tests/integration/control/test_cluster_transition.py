"""Real device, reactive controller and AC solver exercise the staged protocol."""

from dataclasses import replace
from fractions import Fraction
from math import exp, inf, nextafter

import numpy as np
import pytest

from oilfield_energy.ac_consistency import solve_case_ac_consistent
from oilfield_energy.bootstrap.adapters.cluster_execution import _persistent_plant
from oilfield_energy.bootstrap.adapters.cluster_rolling import window_case
from oilfield_energy.bootstrap.adapters.project_dataset import build_synthetic_case
from oilfield_energy.device_control import device_tracking_session
from oilfield_energy.modules.control.api import authorize_cluster_transition
from oilfield_energy.modules.control.contracts import (
    CommitDeviceTransition,
    DeviceCheckpoint,
    DevicePlanUpdate,
    RegionalTransitionProposal,
    RegionalTransitionReady,
    StopDeviceSession,
)
from oilfield_energy.workflows.cluster_execution.api import (
    prepare_transition_round,
    transition_commits,
)


@pytest.fixture(scope="module")
def inputs():
    base = build_synthetic_case(96, profile_kind="intraday")
    energies = {m.name: m.storage.e_initial_mwh for m in base.microgrids}
    case = window_case(base, 35, 37, energies, energies)
    mg = case.microgrids[0]
    checked = solve_case_ac_consistent(
        case, [mg.name], storage_enabled=False, cluster_coordination=False, time_limit_seconds=20
    )
    assert checked.passed
    return case, mg, checked.optimization, _persistent_plant(case)[mg.name]


def session_for(inputs):
    case, mg, plan, plant = inputs
    session = device_tracking_session(
        case,
        mg,
        plan,
        plant_inputs=plant,
        storage_enabled=False,
        transition_model="cluster-transition-box-v1",
    )
    assert isinstance(next(session), DeviceCheckpoint)
    return session


def authorize(proposal, limit=100):
    decision = authorize_cluster_transition(
        (proposal,), expected_regions=(proposal.region,), limit_mw=limit
    )
    assert decision.status == "certified"
    return decision.selections[0]


def finish_minute(session, proposal):
    selection = authorize(proposal)
    ready = session.send(selection)
    assert isinstance(ready, RegionalTransitionReady)
    assert ready.status == "passed", ready
    return session.send(
        CommitDeviceTransition(region=ready.region, start_minute=ready.start_minute)
    )


def test_prepared_minutes_are_not_archived_until_joint_commit(inputs):
    session = session_for(inputs)
    first = session.send(None)
    assert isinstance(first, RegionalTransitionProposal)
    checkpoint = finish_minute(session, first)
    assert checkpoint.minute == 1
    second = session.send(None)
    ready = session.send(authorize(second))
    assert ready.status == "passed"
    with pytest.raises(StopIteration) as done:
        session.throw(StopDeviceSession())
    result = done.value.value
    assert len(result.time_minutes) == len(result.storage_dynamics) == 1
    assert all(row["time_minutes"] < 1 for row in result.network_feedback)
    assert sum(row["is_actual"] for row in result.network_feedback) == 1
    assert result.network_feedback[-1]["cluster_transition"]["committed"]


def test_deferral_is_used_by_actual_device_output_before_reactive_recheck(inputs):
    case, mg, plan, _ = inputs
    session = session_for(inputs)
    finish_minute(session, session.send(None))
    data = plan.microgrids[mg.name]
    schedules = data["resource_schedules"]
    update = DevicePlanUpdate(
        start_minute=1,
        p_mw=(float(data["p_grid_mw"][0]) + 0.3,),
        q_mvar=(float(data["q_grid_mvar"][0]),),
        resource_p_mw={
            r.resource_id: (0.0 if r.resource_type.value == "pv" else float(r.active_power_mw[0]),)
            for r in schedules
        },
        resource_q_mvar={r.resource_id: (float(r.reactive_power_mvar[0]),) for r in schedules},
    )
    proposal = session.send(update)
    assert any(a.proposed_mw < a.defer_to_mw for a in proposal.actuators), proposal
    best = (
        Fraction(proposal.gross_load_upper_mw)
        + Fraction(proposal.loss_upper_mw)
        + Fraction(proposal.injection_roundoff_mw)
        - sum((Fraction(min(a.previous_mw, a.defer_to_mw)) for a in proposal.actuators), Fraction())
    )
    limit = float(best)
    if Fraction(limit) < best:
        limit = nextafter(limit, inf)
    selected = authorize(proposal, limit)
    assert any(
        s.p_mw > a.proposed_mw + 1e-5
        for s in selected.setpoints
        for a in proposal.actuators
        if s.actuator == a.actuator
    )
    ready = session.send(selected)
    assert ready.status == "passed", ready
    session.send(CommitDeviceTransition(region=mg.name, start_minute=1))
    with pytest.raises(StopIteration) as done:
        session.throw(StopDeviceSession())
    result = done.value.value
    points = {s.actuator: s.p_mw for s in selected.setpoints}
    assert result.wind_actual_mw[1] == points["wind"]
    assert result.pv_actual_mw[1] == pytest.approx(
        sum(v for k, v in points.items() if k not in ("wind", "storage"))
    )
    assert result.storage_actual_mw[1] == 0
    assert result.pcc_actual_mw[1] <= limit
    assert result.network_feedback[-1]["reactive_control"]["post_action_safe"]
    commands = result.network_feedback[-1]["cluster_transition"]["effective_commands_mw"]
    assert commands
    for actuator, command in commands.items():
        before = next(a.previous_mw for a in proposal.actuators if a.actuator == actuator)
        if actuator == "wind":
            actual = result.wind_actual_mw[1]
            tau = 2.0
        else:
            bus = actuator.removeprefix(mg.name + ":")
            actual = result.pv_station_actual_mw[bus][1]
            assert result.pv_station_control_target_mw[bus][1] == command
            tau = 0.25
        # Independent unsaturated exponential response for this small deferral.
        assert actual == pytest.approx(command + (before - command) * exp(-1 / tau), abs=1e-12)


def test_missing_commit_cannot_advance_the_device_clock(inputs):
    session = session_for(inputs)
    proposal = session.send(None)
    session.send(authorize(proposal))
    with pytest.raises(ValueError, match="joint commit"):
        session.send(None)


def test_one_real_regional_ac_failure_aborts_the_joint_minute_for_all_regions():
    case = build_synthetic_case(4)
    case = replace(
        case, time_hours=np.arange(4) / 4, assumptions=replace(case.assumptions, dt_hours=0.25)
    )
    names = tuple(m.name for m in case.microgrids)
    solved = solve_case_ac_consistent(
        case, list(names), storage_enabled=False, cluster_coordination=True, time_limit_seconds=20
    )
    assert solved.passed
    plants = _persistent_plant(case)

    def invalid_second_endpoint(snapshot, stage):
        if stage == "post_control" and snapshot.snapshot_id.split(":")[-2] == "1":
            return replace(snapshot, quality_valid=False)
        return snapshot

    sessions = {
        m.name: device_tracking_session(
            case,
            m,
            solved.optimization,
            plant_inputs=plants[m.name],
            storage_enabled=False,
            transition_model="cluster-transition-box-v1",
            network_snapshot_adapter=invalid_second_endpoint if m.name == names[1] else None,
        )
        for m in case.microgrids
    }
    try:
        for session in sessions.values():
            assert next(session).minute == 0
        for minute in (0, 1):
            proposals = tuple(sessions[name].send(None) for name in names)
            record = prepare_transition_round(
                proposals=proposals,
                names=names,
                limit_mw=case.cluster_import_limit_mw,
                prepare=lambda s: sessions[s.region].send(s),
            )
            commits = transition_commits(record)
            if minute == 0:
                assert len(commits) == 3, record.model_dump_json()
                for commit in commits:
                    assert sessions[commit.region].send(commit).minute == 1
            else:
                assert not commits and len(record.ready) == 3
                assert sum(r.status == "unknown" for r in record.ready) == 1
        for session in sessions.values():
            with pytest.raises(StopIteration) as done:
                session.throw(StopDeviceSession())
            assert len(done.value.value.time_minutes) == 1
            assert all(r["time_minutes"] == 0 for r in done.value.value.network_feedback)
    finally:
        for session in sessions.values():
            session.close()
