"""Actual AC/plant regression: charging improves PCC error but overloads its feeder.

The deterministic three-bus case has a 0.4 MW load on the battery's 0.6 MVA
feeder and a separate 1 MW load/PV feeder. The 0.8 MW PCC target calls for about
0.4 MW charging. Device/ramp limits allow it; the battery feeder does not.
"""

import json
from dataclasses import replace
from datetime import datetime, timezone

import numpy as np
import pytest

from oilfield_energy.data import Line, MicrogridData, ModelAssumptions, ProjectCase, Storage
from oilfield_energy.device_control import simulate_device_tracking
from oilfield_energy.hierarchy_reporting import write_minute_network_outputs
from oilfield_energy.modules.control.contracts import BusSeries, PlantInputs
from oilfield_energy.modules.dispatch.contracts import (
    AdoptedOrigin,
    AdoptedSchedule,
    ResourceTrajectory,
)
from oilfield_energy.network_model import build_legacy_network_model_v2
from oilfield_energy.network_scenarios import NetworkSecurityLimits


def run_case(
    *,
    rating=0.6,
    storage_plan=0.0,
    adapter=None,
    load_b=0.4,
    target=0.800032002560205,
    load_q_b=0.0,
    storage_mva=2.7,
    **kwargs,
):
    buses = ["A", "B", "C"]
    lines = [Line("AB", "A", "B", 0.001, 0.002, rating), Line("AC", "A", "C", 0.001, 0.002, 2.0)]
    network = build_legacy_network_model_v2(
        network_id="storage-adoption-regression",
        buses=buses,
        pcc_bus_id="A",
        base_mva=10.0,
        lines=lines,
    )
    mg = MicrogridData(
        name="test",
        buses=buses,
        lines=lines,
        pcc_bus="A",
        base_mva=10.0,
        maximum_load_mw=2.0,
        p_grid_max_mw=3.0,
        p_grid_min_mw=0.15,
        voltage_min_pu=0.95,
        voltage_max_pu=1.05,
        load_p_mw={b: np.array([v]) for b, v in zip(buses, (0.0, load_b, 1.0))},
        load_q_mvar={b: np.array([load_q_b if b == "B" else 0.0]) for b in buses},
        wind_available_mw={"C": np.zeros(1)},
        wind_capacity_mw={"C": 1.0},
        wind_capacity_mva={"C": 1.0},
        pv_available_mw={"C": np.ones(1)},
        pv_capacity_mw={"C": 1.0},
        pv_capacity_mva={"C": 1.1},
        storage=Storage("B", 2.5, 5.0, 0.5, 2.5, 0.95, 0.95, storage_mva),
        svg_bus="C",
        svg_q_min_mvar=-1.0,
        svg_q_max_mvar=1.0,
        network_model_v2=network,
        network_operating_mode_id=network.default_operating_mode_id,
    )
    case = ProjectCase(
        time_hours=np.zeros(1),
        price_cny_per_mwh=np.ones(1),
        microgrids=[mg],
        assumptions=ModelAssumptions(dt_hours=0.25),
        cluster_import_limit_mw=3.0,
    )
    start = datetime(2026, 1, 1, tzinfo=timezone.utc)
    plan = AdoptedSchedule(
        microgrid_id=mg.name,
        start=start,
        step_minutes=15,
        p_grid_mw=(target,),
        q_grid_mvar=(0.0,),
        wind_available_mw=(0.0,),
        resource_schedules=tuple(
            ResourceTrajectory(
                resource_id=mg.resource_id(kind, bus),
                bus_id=bus,
                resource_type=kind,
                active_power_mw=(power,),
                reactive_power_mvar=(0.0,),
            )
            for kind, bus, power in (
                ("wind", "C", 0.0),
                ("pv", "C", 1.0),
                ("storage", "B", storage_plan),
                ("svg", "C", 0.0),
            )
        ),
        origins=(AdoptedOrigin(interval_index=0, window_start_interval=0, window_end_interval=1),),
    )
    plant = PlantInputs(
        start=start,
        step_minutes=1,
        **{
            field: tuple(
                BusSeries(bus_id=b, values=(float(v[0]),) * 15)
                for b, v in getattr(mg, source).items()
            )
            for field, source in (
                ("load_p", "load_p_mw"),
                ("load_q", "load_q_mvar"),
                ("wind_available", "wind_available_mw"),
                ("pv_available", "pv_available_mw"),
            )
        },
    )
    return mg, simulate_device_tracking(
        case,
        mg,
        plan,
        plant_inputs=plant,
        network_snapshot_adapter=adapter,
        reverse_flow_probability_15=np.zeros(1),
        **kwargs,
    )


def evidence(result, stage, minute=0):
    return next(
        r for r in result.network_feedback if r["stage"] == stage and r["time_minutes"] == minute
    )


def assert_energy(mg, result):
    before = np.r_[mg.storage.e_initial_mwh, result.storage_energy_mwh[:-1]]
    power = result.storage_actual_mw
    expected = before + np.where(power < 0, -power * 0.95, -power / 0.95) / 60
    np.testing.assert_allclose(result.storage_energy_mwh, expected, atol=1e-12, rtol=0)
    for record in result.storage_dynamics:
        assert record.ramp_compliant or record.physical_override or record.hard_override
        assert record.ordinary_mw + record.ordinary_unserved_mw == pytest.approx(
            record.requested_mw
        )


def test_overload_candidate_is_rejected_without_changing_energy_or_latching_gate():
    mg, result = run_case()
    trial = evidence(result, "storage_tracking_candidate")
    base = evidence(result, "plant_response")
    selected = evidence(result, "storage_tracking_response")
    audit = evidence(result, "post_control")["storage_tracking"]
    assert base["valid"] and base["line_capacity_within_limits"]
    assert trial["valid"] and not trial["line_capacity_within_limits"]
    assert not trial["is_actual"]
    assert abs(audit["candidate"]["error_mw"]) < abs(audit["baseline"]["error_mw"])
    assert audit["status"] == "network_rejected"
    assert audit["selected_mw"] == audit["baseline"]["power_mw"] == 0.0
    assert {k: v for k, v in selected["flow"].items() if k != "point_id"} == {
        k: v for k, v in base["flow"].items() if k != "point_id"
    }
    # Q, loads and other P are identical during the probe; only battery P differs.
    base_snapshot, trial_snapshot = base["inputs"]["snapshot"], trial["inputs"]["snapshot"]
    assert base_snapshot["loads"] == trial_snapshot["loads"]
    for before, after in zip(base_snapshot["devices"], trial_snapshot["devices"]):
        assert before["q_mvar"] == after["q_mvar"]
        if before["resource_id"] != "test:storage:B":
            assert before == after
    assert result.storage_actual_mw[0] == 0.0
    assert result.storage_energy_mwh[0] == mg.storage.e_initial_mwh
    assert not np.any(result.network_recovery_blocked)
    assert result.network_security_passed
    assert_energy(mg, result)


def test_same_request_on_adequate_feeder_is_adopted_and_integrated_once():
    mg, result = run_case(rating=2.0)
    audit = evidence(result, "post_control")["storage_tracking"]
    assert audit["status"] == "adopted"
    assert audit["selected_mw"] == pytest.approx(-0.40001600128)
    assert result.storage_actual_mw[0] == audit["selected_mw"]
    assert result.storage_energy_mwh[0] > mg.storage.e_initial_mwh
    assert_energy(mg, result)


def test_invalid_probe_preserves_nonzero_baseline_and_energy_and_exports_reason(tmp_path):
    def reject(snapshot, stage):
        return (
            replace(snapshot, quality_valid=False)
            if stage == "storage_tracking_candidate"
            else snapshot
        )

    mg, result = run_case(rating=2.0, storage_plan=-0.1, adapter=reject)
    audit = evidence(result, "post_control")["storage_tracking"]
    assert audit["status"] == "network_rejected"
    assert audit["candidate"]["error_mw"] is None
    assert audit["selected_mw"] == result.storage_actual_mw[0] == -0.1
    assert result.storage_energy_mwh[0] == pytest.approx(2.5 + 0.1 * 0.95 / 60)
    assert not np.any(result.network_recovery_blocked)
    assert_energy(mg, result)
    write_minute_network_outputs(tmp_path, {mg.name: result})
    lines = [
        json.loads(line)
        for line in (tmp_path / "minute_network.jsonl").read_text(encoding="utf-8").splitlines()
    ]
    assert any(r.get("storage_tracking", {}).get("status") == "network_rejected" for r in lines)


@pytest.mark.parametrize("unknown", [False, True])
def test_unsafe_or_unknown_baseline_is_not_declared_safe_by_rollback(unknown):
    def invalidate(snapshot, stage):
        return (
            replace(snapshot, quality_valid=False)
            if unknown and stage == "plant_response"
            else snapshot
        )

    _, result = run_case(rating=0.3 if not unknown else 2.0, adapter=invalidate)
    audit = evidence(result, "post_control")["storage_tracking"]
    assert audit["status"] == "baseline_unsafe"
    assert not audit["baseline"]["safe"]
    assert audit["candidate"] is None
    assert not any(
        r["stage"] == "storage_tracking_candidate" and r["time_minutes"] == 0
        for r in result.network_feedback
    )
    assert result.network_recovery_blocked[0]
    assert not result.network_security_passed


@pytest.mark.parametrize(
    "params,check",
    [
        (
            {"network_limits": NetworkSecurityLimits(0.99994, 1.05, 0.15, 3.0, 0.9)},
            "voltage_within_limits",
        ),
        ({"storage_mva": 0.2}, "device_capacity_within_limits"),
        ({"network_limits": NetworkSecurityLimits(0.95, 1.05, 0.15, 0.6, 0.9)}, None),
        ({"target": 0.1}, None),
        ({"target": 0.2, "load_q_b": 0.15}, None),
    ],
)
def test_ac_voltage_device_pcc_and_power_factor_constraints_reject_candidates(params, check):
    mg, result = run_case(rating=2.0, **params)
    audit = evidence(result, "post_control")["storage_tracking"]
    trial = evidence(result, "storage_tracking_candidate")
    assert audit["baseline"]["safe"]
    assert trial["valid"]
    assert audit["status"] == "network_rejected"
    if check:
        assert not trial[check]
    else:
        assert trial["flow"]["violations"]
    assert audit["selected_mw"] == result.storage_actual_mw[0] == 0.0
    assert_energy(mg, result)
