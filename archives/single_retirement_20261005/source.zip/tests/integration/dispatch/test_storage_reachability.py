"""Real backends: static-feasible charging cannot violate the observed ramp state."""

import json
from dataclasses import replace
from datetime import datetime, timezone
from math import sqrt

import numpy as np
import pytest

from oilfield_energy.admm import CoordinationWorkspace
from oilfield_energy.bootstrap.adapters.cluster_execution import (
    RegionalPlanRequest,
    diagnose_regional_reference,
    realize_regional_plan,
)
from oilfield_energy.bootstrap.adapters.cluster_rolling import with_storage_reachability
from oilfield_energy.data import (
    Line,
    MicrogridData,
    ModelAssumptions,
    ProjectCase,
    Storage,
)
from oilfield_energy.device_control import device_tracking_session
from oilfield_energy.hierarchy_reporting import write_minute_network_outputs
from oilfield_energy.hierarchy_types import ADMMConfig
from oilfield_energy.misocp_model import solve_case_misocp
from oilfield_energy.model import solve_case
from oilfield_energy.modules.control.contracts import (
    BusSeries,
    DeviceCheckpoint,
    DevicePlanUpdate,
    DynamicTrackingPolicy,
    PlantInputs,
    StorageResponseSettings,
)
from oilfield_energy.modules.dispatch.api import assess_storage_reachability
from oilfield_energy.modules.dispatch.contracts import (
    AdoptedOrigin,
    AdoptedSchedule,
    DispatchCapabilities,
    ResourceTrajectory,
    StorageReachabilityPolicy,
)
from oilfield_energy.network_model import build_legacy_network_model_v2
from oilfield_energy.regional_control import RegionalConvexController
from oilfield_energy.workflows.cluster_execution.contracts import ExecutionPolicy


def case_and_policy(*, initial=2.5, terminal=2.03, minutes=1.0, steps=1, enabled=True):
    buses = ["pcc", "load"]
    lines = [Line("line", "pcc", "load", 0.001, 0.002, 12.0)]
    network = build_legacy_network_model_v2(
        network_id="storage-dynamics-synthetic",
        buses=buses,
        pcc_bus_id="pcc",
        base_mva=10.0,
        lines=lines,
    )
    mg = MicrogridData(
        name="A",
        buses=buses,
        lines=lines,
        pcc_bus="pcc",
        base_mva=10.0,
        maximum_load_mw=5.0,
        p_grid_max_mw=12.0,
        p_grid_min_mw=0.15,
        voltage_min_pu=0.95,
        voltage_max_pu=1.05,
        load_p_mw={"pcc": np.zeros(steps), "load": np.full(steps, 5.0)},
        load_q_mvar={b: np.zeros(steps) for b in buses},
        wind_available_mw={},
        wind_capacity_mw={},
        wind_capacity_mva={},
        pv_available_mw={},
        pv_capacity_mw={},
        pv_capacity_mva={},
        storage=Storage("load", 3.0, 4.0, 0.5, 2.0, 0.95, 0.95, 3.5, terminal),
        svg_bus="load",
        svg_q_min_mvar=0,
        svg_q_max_mvar=0,
        storage_reactive_enabled=False,
        network_model_v2=network,
        network_operating_mode_id=network.default_operating_mode_id,
    )
    case = ProjectCase(
        np.arange(steps) * minutes / 60,
        np.full(steps, 600.0),
        [mg],
        replace(ModelAssumptions(), dt_hours=minutes / 60),
        20.0,
    )
    policy = ExecutionPolicy(
        dynamic_tracking=DynamicTrackingPolicy(),
        storage_reachability=StorageReachabilityPolicy() if enabled else None,
    )
    if enabled:
        case = with_storage_reachability(
            case,
            policy=policy.storage_reachability,
            dynamics=policy.dynamic_tracking,
            checkpoints={
                "A": DeviceCheckpoint(minute=0, storage_energy_mwh=2.0, storage_power_mw=initial)
            },
            storage_enabled=True,
            execution_step_minutes=1,
        )
    return case, policy


def request(case, policy):
    return RegionalPlanRequest(
        case,
        "A",
        np.full(len(case.time_hours), 7.0),
        np.zeros(len(case.time_hours)),
        True,
        15,
        policy,
    )


def test_static_plan_passes_but_current_discharge_makes_even_diagnostic_energy_infeasible():
    old_case, old_policy = case_and_policy(enabled=False)
    old, _ = realize_regional_plan(request(old_case, old_policy))
    assert old.executable_plan and old.storage_power_mw[0] < -1.9
    assert old.storage_energy_mwh[-1] >= 1.98
    case, policy = case_and_policy()
    row, plan = realize_regional_plan(request(case, policy))
    assert plan is None and not row.executable_plan
    assert row.solver_stop_reason == "solver_infeasible"
    diagnostic = diagnose_regional_reference((request(case, policy), 1))
    assert diagnostic.calibration is None and diagnostic.evidence.status == "violated"


@pytest.mark.parametrize("backend", ["linear", "misocp", "regional"])
def test_all_three_backends_reject_the_terminal_energy_ramp_contradiction(backend):
    case, _ = case_and_policy()
    if backend == "regional":
        with pytest.raises(RuntimeError, match="infeasible"):
            RegionalConvexController(case, case.microgrids[0], ADMMConfig()).solve(
                None, fallback=True
            )
    else:
        solver = solve_case if backend == "linear" else solve_case_misocp
        result = solver(case, ["A"], time_limit_seconds=15)
        assert not result.success


def test_changing_only_actual_initial_power_makes_the_same_reference_reachable():
    case, policy = case_and_policy(initial=-2.0)
    row, plan = realize_regional_plan(request(case, policy))
    assert plan is not None and row.executable_plan, row
    assert row.storage_reachability.status == "passed"
    assert row.storage_reachability.inputs.initial_power_mw == -2.0
    assert abs(row.storage_reachability.first_command_mw[0]) <= 3.0 + 1e-6
    assert row.storage_energy_mwh[-1] == pytest.approx(
        2.0 - row.storage_power_mw[0] * 0.95 / 60,
        abs=1e-6,
    )
    assert type(row).model_validate_json(row.model_dump_json()) == row


@pytest.mark.parametrize("fault", ["power", "resource", "clock", "missing_witness"])
def test_regional_certificate_cannot_be_detached_from_the_adopted_trajectory(fault):
    case, policy = case_and_policy(initial=-2.0)
    row, _ = realize_regional_plan(request(case, policy))
    raw = row.model_dump()
    if fault == "power":
        raw["storage_power_mw"] = (0.0,)
    elif fault == "resource":
        raw["resource_p_mw"][row.storage_reachability.inputs.resource_id] = (0.0,)
    elif fault == "clock":
        raw["time_minutes"] = (1.0,)
    else:
        raw["storage_reachability"] = None
    with pytest.raises(ValueError, match="storage reachability"):
        type(row).model_validate(raw)


def test_legacy_policy_and_plan_do_not_acquire_a_reachability_certificate():
    case, policy = case_and_policy(enabled=False)
    row, _ = realize_regional_plan(request(case, policy))
    raw = row.model_dump()
    raw.pop("storage_reachability")
    assert type(row).model_validate(raw).storage_reachability is None
    assert ExecutionPolicy.model_validate({}).storage_reachability is None


def two_bus_import(storage_power):
    """Independent receiving-end DistFlow solution; avoids a feedback disturbance."""
    p, r, x, base = (5.0 - storage_power) / 10.0, 0.001, 0.002, 10.0
    a = 1.0 - 2.0 * r * p
    current = 2 * p * p / (a + sqrt(a * a - 4 * (r * r + x * x) * p * p))
    return (p + r * current) * base, x * current * base


def with_plant_resources(case):
    # The existing synthetic plant requires wind/PV identities; their available
    # injections are exactly zero and do not alter this storage-only scenario.
    mg = replace(
        case.microgrids[0],
        wind_available_mw={"load": np.zeros(len(case.time_hours))},
        wind_capacity_mw={"load": 1.0},
        wind_capacity_mva={"load": 1.0},
        wind_q_abs_over_p_max={"load": 0.3},
        pv_available_mw={"load": np.zeros(len(case.time_hours))},
        pv_capacity_mw={"load": 1.0},
        pv_capacity_mva={"load": 1.0},
    )
    return replace(case, microgrids=[mg])


def execute_storage_targets(minutes, powers, *, pcc_offset=0.0, settings_override=None):
    """Use the real original lag/ramp/SOC engine and fixed-state AC evaluation."""
    case, _ = case_and_policy(initial=0.0, terminal=2.0, minutes=minutes, steps=len(powers))
    case = with_plant_resources(case)
    mg = case.microgrids[0]
    start = datetime(2026, 1, 1, tzinfo=timezone.utc)
    p0, q0 = two_bus_import(0.0)
    resources = tuple(
        ResourceTrajectory(
            resource_id=mg.resource_id(kind, "load"),
            bus_id="load",
            resource_type=kind,
            active_power_mw=(0.0,) * len(powers),
            reactive_power_mvar=(0.0,) * len(powers),
        )
        for kind in ("storage", "svg", "wind", "pv")
    )
    seed = AdoptedSchedule(
        microgrid_id="A",
        start=start,
        step_minutes=minutes,
        p_grid_mw=(p0,) * len(powers),
        q_grid_mvar=(q0,) * len(powers),
        wind_available_mw=(0.0,) * len(powers),
        resource_schedules=resources,
        origins=tuple(
            AdoptedOrigin(
                interval_index=t,
                window_start_interval=t,
                window_end_interval=len(powers),
            )
            for t in range(len(powers))
        ),
    )
    minute_p = tuple(float(p) for p in np.repeat(powers, minutes))
    n = len(minute_p)
    plant = PlantInputs(
        start=start,
        step_minutes=1,
        load_p=(
            BusSeries(bus_id="pcc", values=(0.0,) * n),
            BusSeries(bus_id="load", values=(5.0,) * n),
        ),
        load_q=tuple(BusSeries(bus_id=b, values=(0.0,) * n) for b in mg.buses),
        wind_available=(BusSeries(bus_id="load", values=(0.0,) * n),),
        pv_available=(BusSeries(bus_id="load", values=(0.0,) * n),),
    )
    pcc = tuple(two_bus_import(p) for p in minute_p)
    spec = case.storage_reachability["A"]
    settings = StorageResponseSettings(
        execution_minutes=spec.execution_minutes,
        time_constant_minutes=spec.time_constant_minutes,
        ramp_mw_per_minute=spec.ramp_mw_per_minute,
        power_tolerance_mw=spec.policy.power_tolerance_mw,
    )
    if settings_override:
        settings = settings.model_copy(update=settings_override)
    packet = DevicePlanUpdate(
        start_minute=0,
        p_mw=tuple(p + pcc_offset for p, q in pcc),
        q_mvar=tuple(q for p, q in pcc),
        resource_p_mw={
            r.resource_id: minute_p if r.resource_type == "storage" else (0.0,) * n
            for r in resources
        },
        resource_q_mvar={r.resource_id: (0.0,) * n for r in resources},
        storage_response=settings,
    )
    session = device_tracking_session(
        case,
        mg,
        seed,
        plant_inputs=plant,
        reverse_flow_probability_15=np.zeros(len(powers)),
    )
    states = [next(session)]
    assert states[0].storage_power_mw == 0.0
    try:
        states.append(session.send(packet))
        while True:
            states.append(next(session))
    except StopIteration as stop:
        return case, stop.value, states
    finally:
        session.close()


@pytest.mark.parametrize("minutes", [1, 15])
def test_certified_signed_power_and_energy_replay_through_the_actual_device_engine(
    minutes, tmp_path
):
    powers = (0.2, -0.2, 0.0)
    case, actual, states = execute_storage_targets(minutes, powers)
    spec = case.storage_reachability["A"]
    expected = [2.0]
    for p in powers:
        expected.append(expected[-1] + minutes / 60 * (-p * 0.95 if p < 0 else -p / 0.95))
    proof = assess_storage_reachability(spec, p_mw=powers, energy_mwh=tuple(expected))
    assert proof.status == "passed"
    np.testing.assert_allclose(
        actual.storage_actual_mw, np.repeat(powers, minutes), atol=1e-6, rtol=0
    )
    np.testing.assert_allclose(
        actual.storage_energy_mwh[minutes - 1 :: minutes],
        expected[1:],
        atol=1e-6,
        rtol=0,
    )
    assert all(r.ramp_compliant and r.plan_response.followed for r in actual.storage_dynamics)
    assert all(abs(r.plan_response.effective_command_mw) <= 3.0 for r in actual.storage_dynamics)
    for state in states[1:]:
        assert state.storage_power_mw == actual.storage_actual_mw[state.minute - 1]
        assert state.storage_energy_mwh == actual.storage_energy_mwh[state.minute - 1]
    write_minute_network_outputs(tmp_path, {"A": actual})
    archived = json.loads((tmp_path / "storage_dynamics.json").read_text(encoding="utf-8"))
    assert all(r["plan_response"]["followed"] for r in archived["A"]["records"])


def test_execution_feedback_deviation_is_not_reported_as_following_the_nominal_plan():
    _, actual, _ = execute_storage_targets(1, (0.2,), pcc_offset=0.2)
    response = actual.storage_dynamics[0].plan_response
    assert response.reachable and not response.followed
    assert response.actual_mw == actual.storage_actual_mw[0]
    p = response.actual_mw
    assert actual.storage_energy_mwh[0] == pytest.approx(
        2.0 + (-p * 0.95 if p < 0 else -p / 0.95) / 60
    )


def test_device_rejects_a_planning_response_model_that_differs_from_its_own():
    with pytest.raises(ValueError, match="differ from the actual device model"):
        execute_storage_targets(1, (0.2,), settings_override={"time_constant_minutes": 4.0})


def test_coordination_cache_rebuilds_when_actual_power_or_the_reachability_mode_changes():
    cache = CoordinationWorkspace()
    first, _ = case_and_policy(initial=0.0)
    changed, _ = case_and_policy(initial=-2.0)
    legacy = replace(changed, storage_reachability={})

    def prepare(case):
        return cache.prepare(
            case,
            case.microgrids,
            ADMMConfig(),
            DispatchCapabilities(),
            {"A": np.full(1, 0.15)},
            None,
        )[0]["A"]

    before = prepare(first)
    assert prepare(first) is before
    after = prepare(changed)
    assert after is not before
    with pytest.raises(ValueError, match="reachability"):
        before.update_window(changed, changed.microgrids[0], None, np.full(1, 0.15))
    assert prepare(legacy) is not after


@pytest.mark.parametrize("fault", ["missing", "stale", "energy", "unknown_region"])
def test_later_window_requires_complete_current_physical_state(fault):
    case, policy = case_and_policy(enabled=False)
    case = replace(case, time_hours=np.array([1.0 / 60]))
    state = DeviceCheckpoint(minute=1, storage_power_mw=2.5, storage_energy_mwh=2.0)
    states = {"A": state}
    if fault == "missing":
        states = {}
    elif fault == "stale":
        states = {"A": state.model_copy(update={"minute": 0})}
    elif fault == "energy":
        states = {"A": state.model_copy(update={"storage_energy_mwh": 1.9})}
    else:
        states["unknown"] = state
    with pytest.raises(ValueError, match="checkpoint"):
        with_storage_reachability(
            case,
            policy=StorageReachabilityPolicy(),
            dynamics=policy.dynamic_tracking,
            checkpoints=states,
            storage_enabled=True,
            execution_step_minutes=1,
        )


@pytest.mark.parametrize("minute", [31, 124])
def test_minute_hour_roundoff_does_not_reject_a_fresh_checkpoint_or_command(minute):
    from oilfield_energy.bootstrap.adapters.cluster_rolling import first_command

    case, policy = case_and_policy(initial=-2.0)
    case = replace(case, storage_reachability={}, time_hours=np.array([minute / 60]))
    assert float(case.time_hours[0] * 60) != minute  # Exercise the non-exact conversion.
    case = with_storage_reachability(
        case,
        policy=policy.storage_reachability,
        dynamics=policy.dynamic_tracking,
        checkpoints={
            "A": DeviceCheckpoint(minute=minute, storage_energy_mwh=2.0, storage_power_mw=-2.0)
        },
        storage_enabled=True,
        execution_step_minutes=1,
    )
    row, plan = realize_regional_plan(request(case, policy))
    assert plan is not None and row.executable_plan
    assert first_command(row, minute, 1).storage_response is not None
    with pytest.raises(ValueError, match="certified planning boundary"):
        first_command(row, minute + 1, 1)


def test_startup_assumption_is_explicit_and_disabled_storage_has_no_false_certificate():
    case, policy = case_and_policy(enabled=False)
    startup = with_storage_reachability(
        case,
        policy=StorageReachabilityPolicy(),
        dynamics=policy.dynamic_tracking,
        checkpoints={},
        storage_enabled=True,
        execution_step_minutes=1,
    )
    assert startup.storage_reachability["A"].initial_power_mw is None
    disabled = with_storage_reachability(
        startup,
        policy=StorageReachabilityPolicy(),
        dynamics=policy.dynamic_tracking,
        checkpoints={},
        storage_enabled=False,
        execution_step_minutes=1,
    )
    assert not disabled.storage_reachability


def test_nonuniform_time_grid_cannot_reuse_a_uniform_interval_certificate():
    case, _ = case_and_policy(initial=0.0, steps=2)
    with pytest.raises(ValueError, match="exact planning window"):
        replace(case, time_hours=np.array([0.0, 2.0 / 60]))


def test_new_policy_cannot_silently_omit_the_state_constraints():
    case, _ = case_and_policy(enabled=False)
    _, policy = case_and_policy()
    with pytest.raises(ValueError, match="reachability"):
        request(case, policy)


@pytest.mark.parametrize("minute_replan", [False, True])
def test_real_rolling_window_uses_the_completed_checkpoint_and_keeps_response_settings(
    minute_replan,
):
    from oilfield_energy.admm import run_admm_coordination
    from oilfield_energy.bootstrap.adapters.cluster_execution import ExecutionEngines
    from oilfield_energy.bootstrap.adapters.cluster_rolling import RollingClusterEngine
    from oilfield_energy.hierarchy_types import CommunicationConfig

    case, _ = case_and_policy(terminal=2.0, minutes=1, steps=2, enabled=False)
    case = with_plant_resources(case)
    mg = replace(case.microgrids[0], pv_reactive_enabled={"load": False})
    case = replace(case, microgrids=[mg, replace(mg, name="B")])
    policy = ExecutionPolicy(
        update_minutes=1,
        horizon_minutes=2,
        dynamic_tracking=DynamicTrackingPolicy(),
        storage_reachability=StorageReachabilityPolicy(),
    )
    cfg = ADMMConfig(max_iterations=1000)
    reference = run_admm_coordination(case, admm_config=cfg)
    engines = ExecutionEngines(case, case, {}, reference, True, 15, policy, cfg)
    ahead = engines.run_stage("day_ahead")
    assert all(r.executable_plan for r in ahead), ahead
    assert ahead[0].storage_reachability.inputs.initial_power_mw is None
    start = datetime(2026, 1, 1, tzinfo=timezone.utc)
    plant = PlantInputs(
        start=start,
        step_minutes=1,
        load_p=(
            BusSeries(bus_id="pcc", values=(0.0,) * 2),
            BusSeries(bus_id="load", values=(5.0,) * 2),
        ),
        load_q=tuple(BusSeries(bus_id=b, values=(0.0,) * 2) for b in case.microgrids[0].buses),
        wind_available=(BusSeries(bus_id="load", values=(0.0,) * 2),),
        pv_available=(BusSeries(bus_id="load", values=(0.0,) * 2),),
    )

    def strict(window, ref):
        return {
            m.name: realize_regional_plan(engines.plan_request(window, m.name, ref))
            for m in window.microgrids
        }

    engine = RollingClusterEngine(
        case=case,
        original_case=case,
        plants={"A": plant, "B": plant},
        original_admm=engines.admm,
        day_ahead=ahead,
        storage_enabled=True,
        policy=policy,
        admm_config=cfg,
        communication_config=CommunicationConfig(),
        loss_calibration=None,
        solve_regions=strict,
        progress=lambda _: None,
    )
    try:
        first = engine.prepare(0, 1, 2)
        assert first.adopted, first.reason
        assert not first.initial_storage_power_mw
        try:
            engine.advance(0, 1)
        except RuntimeError:
            pytest.fail(engine.transitions[-1].model_dump_json(indent=2))
        observed = engine.checkpoints["A"]
        assert observed.minute == 1
        following = engine.prepare(1, 2, 2, minute_replan=minute_replan)
        assert following.adopted, [
            c
            for checks in following.regional_checks.values()
            for c in checks
            if c.status != "passed"
        ] or following.reason
        accepted = engine.accepted["A"][-1]
        assert accepted.storage_reachability.inputs.initial_power_mw == observed.storage_power_mw
        assert following.initial_storage_power_mw["A"] == observed.storage_power_mw
        assert accepted.storage_energy_mwh[0] == pytest.approx(
            observed.storage_energy_mwh, abs=1e-7
        )
        assert engine.commands["A"].storage_response is not None
        assert engine.checkpoints["A"] is observed  # Planning never advances the plant.
        engine.advance(1, 2)
        assert len(engine.results["A"].storage_dynamics) == 2
        assert engine.results["A"].storage_dynamics[-1].previous_mw == observed.storage_power_mw
    finally:
        for stream in engine.sessions.values():
            stream.close()
