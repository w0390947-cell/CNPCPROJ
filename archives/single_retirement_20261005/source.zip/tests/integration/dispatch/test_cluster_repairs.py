from dataclasses import replace
from types import SimpleNamespace
from unittest.mock import patch

import numpy as np
import pytest

from oilfield_energy import admm, cli, service
from oilfield_energy.bootstrap.adapters.project_dataset import (
    build_synthetic_case as packaged_case,
)
from oilfield_energy.hierarchy_types import ADMMConfig, CommunicationConfig
from tests.legacy_case_fixture import build_synthetic_case


def test_disabled_storage_reaches_actual_admm_and_scope_is_explicit():
    captured = []
    original = service.run_admm_coordination
    # Capability correction now permits execution; keep this authority/contract
    # test to one hour. The packaged 24-point capability regression is separate.
    case = packaged_case(4)
    case = replace(
        case,
        time_hours=np.arange(4) / 4,
        assumptions=replace(case.assumptions, dt_hours=0.25),
    )

    def observe(*args, **kwargs):
        result = original(*args, **kwargs)
        captured.append(result)
        return result

    with patch.object(service, "run_admm_coordination", side_effect=observe):
        result = service.run_simulation(
            service.SimulationRequest(
                scenario_type=service.ScenarioType.CLUSTER_COORDINATION,
                storage_enabled=False,
                steps=4,
            ),
            input_case=case,
        )
    assert result.executive_summary.overall_passed == all(
        i.passed for i in result.validation_items
    )
    assert "分布式执行未校核" not in result.executive_summary.headline
    assert result.cluster_validation.scope == "hierarchical_execution"
    assert result.cluster_validation.execution_status != "not_computed"
    for stage in result.cluster_execution.stages:
        for region in stage.regions:
            if region.p_mw:
                assert max(abs(p) for p in region.storage_power_mw) < 1e-6
            else:
                assert region.status != "passed" and region.reason
    sc = next(r for r in result.cluster_execution.stages[0].regions if r.region == "SC")
    assert sc.status == "passed"
    assert len(result.cluster_execution.rolling_updates) == 4
    assert all(w.adopted for w in result.cluster_execution.rolling_updates)
    assert all(len(r.p_mw) == 60 for r in result.cluster_execution.stages[2].regions)
    assert result.coordination_snapshot.capabilities.storage_enabled is False
    for schedule in captured[0].schedules.values():
        assert np.max(np.abs(schedule.storage_charge_mw)) < 1e-8
        assert np.max(np.abs(schedule.storage_discharge_mw)) < 1e-8
        np.testing.assert_allclose(
            schedule.storage_energy_mwh, schedule.storage_energy_mwh[0], atol=1e-8
        )
    assert result.reference_economics.reference.storage_degradation_cost_cny < 1e-7
    assert all(i.validation_basis is not None for i in result.validation_items)
    archived = service.SimulationResult.model_validate_json(result.model_dump_json())
    # Item 09 deliberately separates historical records from executable requests.
    # Pydantic equality includes model type; verify wire data and revalidation.
    assert type(archived.request) is service.SimulationRequestRecord
    assert archived.model_dump(mode="json") == result.model_dump(mode="json")
    assert (
        service.SimulationRequest.model_validate(archived.request.model_dump())
        == result.request
    )


def test_delayed_messages_do_not_regress_accepted_epoch_and_certificate_matches():
    accepted_epochs = {}
    original = admm.RegionalConvexController.solve

    def observe(controller, signal, **kwargs):
        if signal is not None:
            previous = accepted_epochs.get(controller.microgrid.name, -1)
            assert signal.iteration >= previous
            accepted_epochs[controller.microgrid.name] = signal.iteration
        return original(controller, signal, **kwargs)

    with patch.object(admm.RegionalConvexController, "solve", new=observe):
        result = admm.run_admm_coordination(
            build_synthetic_case(8),
            admm_config=ADMMConfig(max_iterations=220),
            communication_config=CommunicationConfig(
                max_delay_iterations=4, stale_limit_iterations=5, random_seed=20260830
            ),
        )
    assert result.converged
    assert result.communication.rejected_stale_messages > 0
    snap = result.coordination_snapshot
    assert snap is not None and snap.converged
    assert {p.signal_iteration for p in snap.regions} == {snap.epoch}
    assert {p.signal_iteration for p in result.schedules.values()} == {snap.epoch}
    x = np.array([p.p_grid_mw for p in snap.regions])
    q = np.array([p.q_grid_mvar for p in snap.regions])
    primal = np.sqrt(
        np.sum((x - snap.p_references_mw) ** 2)
        + np.sum((q - snap.q_references_mvar) ** 2)
    )
    dual = snap.rho * np.sqrt(
        np.sum((np.array(snap.p_references_mw) - snap.previous_p_references_mw) ** 2)
        + np.sum(
            (np.array(snap.q_references_mvar) - snap.previous_q_references_mvar) ** 2
        )
    )
    assert primal == pytest.approx(result.history[-1].primal_residual, abs=1e-12)
    assert dual == pytest.approx(result.history[-1].dual_residual, abs=1e-12)
    assert sum(p.local_objective_cny for p in snap.regions) == pytest.approx(
        result.history[-1].local_objective_cny
    )
    for plan in snap.regions:
        assert result.schedules[plan.name].economic_cost == plan.economic_cost
    before = snap.regions[0].p_grid_mw
    result.schedules[snap.regions[0].name].p_grid_mw[0] = 999
    assert snap.regions[0].p_grid_mw == before


def test_total_outage_has_no_certified_snapshot():
    result = admm.run_admm_coordination(
        build_synthetic_case(4),
        admm_config=ADMMConfig(max_iterations=8),
        communication_config=CommunicationConfig(
            loss_probability=1, stale_limit_iterations=2
        ),
    )
    assert not result.converged
    assert result.coordination_snapshot is None
    assert result.communication.fallback_uses > 0


def test_cli_refuses_uncertified_archived_execution(tmp_path):
    result = SimpleNamespace(cluster_execution=SimpleNamespace(status="unknown"))
    with patch.object(cli, "run_cluster_study", return_value=result) as archive:
        with pytest.raises(RuntimeError, match="not certified"):
            cli.run_hierarchy(4, tmp_path, 30, False)
    archive.assert_called_once()
    assert archive.call_args.args[0].scenario_type is service.ScenarioType.CLUSTER_COORDINATION
