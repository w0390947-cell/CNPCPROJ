"""The single workflow advances only adopted plans and uses completed feedback."""

import pytest

from oilfield_energy.modules.control.contracts import DeviceCheckpoint
from oilfield_energy.workflows.cluster_execution.contracts import (
    ExecutionCheck,
    ExecutionPolicy,
    RegionalExecution,
)
from oilfield_energy.workflows.single_execution.api import run_single_feedback
from oilfield_energy.workflows.single_execution.contracts import (
    SingleExecution,
    SingleWindow,
)


def state(minute, energy=2.5, q=0.3):
    return DeviceCheckpoint(
        minute=minute,
        storage_energy_mwh=energy,
        storage_power_mw=0.1,
        reactive_power_mvar={"wind": q},
    )


def window(start, end, horizon, initial, *, passed=True):
    checks = tuple(
        ExecutionCheck(code=c, label=c, status="passed")
        for c in ("DEVICE_PLAN", "AC_NETWORK", "REACTIVE_PLAN_ENVELOPE")
    )
    plan = RegionalExecution(
        region="SC",
        status="passed" if passed else "unknown",
        checks=checks,
        time_minutes=(float(start),),
        p_mw=(2.0,),
        q_mvar=(0.0,),
        p_target_mw=(2.0,),
        q_target_mvar=(0.0,),
        storage_power_mw=(0.0,),
    )
    return SingleWindow(
        start_minute=start,
        end_minute=end,
        horizon_end_minute=horizon,
        initial_state=initial,
        terminal_energy_mwh=2.5,
        reactive_constraint_count=10,
        plan=plan,
    )


def test_next_plan_receives_actual_energy_and_q_not_previous_plan():
    seen, events = [], []

    def prepare(start, end, horizon, actual):
        seen.append(actual)
        return window(start, end, horizon, actual)

    def advance(start, end):
        return state(end, energy=2.2 - end / 100, q=-0.1 - end / 100)

    rows, reason = run_single_feedback(
        total_minutes=30,
        initial_state=state(0),
        policy=ExecutionPolicy(),
        prepare=prepare,
        advance=advance,
        progress=events.append,
    )
    assert not reason and len(rows) == 2
    assert seen[1] == rows[0].actual_end_state
    assert seen[1].storage_energy_mwh == pytest.approx(2.05, abs=1e-12)
    assert seen[1].reactive_power_mvar == {"wind": -0.25}
    assert seen[1].storage_energy_mwh != rows[0].terminal_energy_mwh
    assert [e.phase for e in events] == ["preparing", "executing", "completed"] * 2
    assert events[-1].completed_windows == 2


def test_rejected_second_plan_retains_first_feedback_and_never_advances():
    advanced = []

    def advance(start, end):
        advanced.append(start)
        return state(end)

    rows, reason = run_single_feedback(
        total_minutes=45,
        initial_state=state(0),
        policy=ExecutionPolicy(),
        prepare=lambda s, e, h, q: window(s, e, h, q, passed=s == 0),
        advance=advance,
    )
    assert reason and advanced == [0] and len(rows) == 2
    assert rows[0].actual_end_state == rows[1].initial_state
    assert rows[1].actual_end_state is None


def test_wrong_feedback_clock_cannot_complete_a_window():
    rows, reason = run_single_feedback(
        total_minutes=30,
        initial_state=state(0),
        policy=ExecutionPolicy(),
        prepare=window,
        advance=lambda s, e: state(e - 1),
    )
    assert "did not complete" in reason
    assert len(rows) == 1 and rows[0].actual_end_state is None


def test_changed_initial_state_is_rejected_before_execution():
    def prepare(s, e, h, q):
        return window(s, e, h, state(s, energy=4.0))

    def unexpected(s, e):
        pytest.fail("an altered initial state must not be adopted")

    rows, reason = run_single_feedback(
        total_minutes=30,
        initial_state=state(0),
        policy=ExecutionPolicy(),
        prepare=prepare,
        advance=unexpected,
    )
    assert not rows and "different boundaries or actual initial state" in reason


def test_pass_cannot_be_created_without_executed_evidence():
    with pytest.raises(ValueError, match="complete planning and execution"):
        SingleExecution(
            region="SC",
            status="passed",
            storage_enabled=True,
            policy=ExecutionPolicy(),
            input_basis="test",
            total_minutes=30,
        )
