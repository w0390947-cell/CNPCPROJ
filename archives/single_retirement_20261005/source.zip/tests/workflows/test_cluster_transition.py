"""No regional commit before complete joint proof and endpoint readiness."""

from oilfield_energy.modules.control.contracts import (
    ClusterTransitionRecord,
    RegionalTransitionProposal,
    RegionalTransitionReady,
    TransitionActuator,
)
from oilfield_energy.workflows.cluster_execution.api import (
    prepare_transition_round,
    transition_commits,
)
from oilfield_energy.workflows.cluster_execution.contracts import ExecutionPolicy


def proposals():
    return tuple(
        RegionalTransitionProposal(
            region=name,
            start_minute=2,
            duration_minutes=1,
            gross_load_upper_mw=2,
            loss_upper_mw=0,
            loss_basis="lossless",
            actuators=(
                TransitionActuator(actuator="w", previous_mw=1, proposed_mw=1, defer_to_mw=1),
            ),
        )
        for name in ("A", "B", "C")
    )


def ready(selection, status="passed", p=1):
    return RegionalTransitionReady(
        region=selection.region, start_minute=2, selection=selection, status=status, pcc_import_mw=p
    )


def test_complete_ready_barrier_preserves_interval_and_identity():
    called = []

    def prepare(s):
        called.append(s.region)
        return ready(s)

    record = prepare_transition_round(
        proposals=proposals(), names=("A", "B", "C"), limit_mw=10, prepare=prepare
    )
    assert not record.committed
    commits = transition_commits(record)
    assert called == [c.region for c in commits] == ["A", "B", "C"]
    assert all(c.start_minute == 2 for c in commits)


def test_any_failed_endpoint_prevents_every_commit():
    record = prepare_transition_round(
        proposals=proposals(),
        names=("A", "B", "C"),
        limit_mw=10,
        prepare=lambda s: ready(s, "unknown" if s.region == "B" else "passed"),
    )
    assert len(record.ready) == 3 and not transition_commits(record)


def test_unproven_capacity_does_not_prepare_or_commit():
    def forbidden(_):
        raise AssertionError("cannot prepare an uncertified selection")

    record = prepare_transition_round(
        proposals=proposals(), names=("A", "B", "C"), limit_mw=2, prepare=forbidden
    )
    assert record.decision.status == "unproven" and not transition_commits(record)


def test_failed_solver_or_unexpected_physical_endpoint_cannot_commit():
    def broken(_):
        raise RuntimeError("AC unavailable")

    for operation in (broken, lambda s: ready(s, p=4)):
        record = prepare_transition_round(
            proposals=proposals(), names=("A", "B", "C"), limit_mw=10, prepare=operation
        )
        assert not transition_commits(record)


def test_record_roundtrip_and_historical_policy_do_not_invent_certificates():
    record = prepare_transition_round(
        proposals=proposals(), names=("A", "B", "C"), limit_mw=10, prepare=ready
    )
    completed = record.model_copy(update={"committed": True})
    assert ClusterTransitionRecord.model_validate_json(completed.model_dump_json()) == completed
    assert ExecutionPolicy.model_validate({}).cluster_transition_version is None
