"""Constructive safety, shifted feasibility and finite-entry proofs, not curve fits."""

import pytest

from oilfield_energy.modules.control.api import point_box
from oilfield_energy.modules.control.contracts import (
    TubeCommand,
    TubeDeviceModel,
    TubeResource,
    TubeState,
)
from oilfield_energy.modules.power_flow.contracts import (
    EnvelopeBranch,
    PowerInterval as I,
    RadialEnvelope,
)
from oilfield_energy.workflows.single_execution.api import (
    CertifiedSingleController,
    certify_tube_plan,
)
from oilfield_energy.workflows.single_execution.contracts import (
    BoundedBusLoad,
    ClosedLoopDomain,
    ConditionalGuaranteeRequest,
    FirmGeneration,
)


def fixture_domain():
    network = RadialEnvelope(
        network_id="two-bus",
        buses=("pcc", "load"),
        branches=(
            EnvelopeBranch(
                parent=0, child=1, r_pu=0.01, x_pu=0.02, tap=1, rating_mva=10
            ),
        ),
        slack=0,
        base_mva=10,
        slack_voltage_pu=1,
        shunt_q_mvar=(0, 0),
        voltage_min_pu=0.95,
        voltage_max_pu=1.05,
        pcc_min_mw=0.1,
        pcc_max_mw=5,
        pf_min=0.9,
    )
    resources = (
        TubeResource(
            resource_id="w",
            bus="load",
            kind="wind",
            p=I(low=0, high=1.5),
            q=I(low=-0.6, high=0.6),
            s_mva=2,
            q_over_p=0.3,
            alpha_p=0.5,
            ramp_p_mw=0.4,
        ),
        TubeResource(
            resource_id="s",
            bus="load",
            kind="storage",
            p=I(low=-0.5, high=0.5),
            q=I(low=-0.5, high=0.5),
            s_mva=1,
            alpha_p=1,
            ramp_p_mw=0.4,
        ),
        TubeResource(
            resource_id="q",
            bus="load",
            kind="svg",
            p=I(low=0, high=0),
            q=I(low=-1, high=1),
            s_mva=1,
            alpha_p=1,
            ramp_p_mw=0,
        ),
    )
    devices = TubeDeviceModel(
        resources=resources,
        alpha_q=0.5,
        aggregate_q_ramp_mvar=0.9,
        step_minutes=1,
        energy_mwh=I(low=0.2, high=2),
        eta_charge=0.95,
        eta_discharge=0.95,
        context_id="fixed",
    )
    settings = ConditionalGuaranteeRequest(
        source="declared analytical test, not field data",
        loads=(
            BoundedBusLoad(bus="pcc", p_mw=I(low=0, high=0), q_mvar=I(low=0, high=0)),
            BoundedBusLoad(
                bus="load",
                p_mw=I(low=2.999, high=3.001),
                q_mvar=I(low=0.299, high=0.301),
            ),
        ),
        generation=(FirmGeneration(resource_id="w", minimum_available_mw=1.5),),
        target_p_mw=2.0040595683,
        target_q_mvar=0.2081191366,
        maximum_target_step_mw=0.1,
        maximum_target_step_mvar=0.1,
        minimum_target_dwell_steps=10,
    )
    domain = ClosedLoopDomain(
        assumptions=settings,
        network=network,
        devices=devices,
        p_band_mw=0.05,
        q_band_mvar=0.05,
        maximum_settling_steps=10,
    )
    initial = TubeState(p_mw=(0.8, 0, 0), q_mvar=(0, 0, 0), energy_mwh=1)
    command = TubeCommand(p_mw=(1, 0, 0), q_mvar=(0, 0, 0.1))
    return domain, initial, command


def observations(domain, sign=1):
    loads = tuple(
        BoundedBusLoad(
            bus=b.bus,
            p_mw=I(
                low=b.p_mw.high if sign > 0 else b.p_mw.low,
                high=b.p_mw.high if sign > 0 else b.p_mw.low,
            ),
            q_mvar=I(
                low=b.q_mvar.high if sign > 0 else b.q_mvar.low,
                high=b.q_mvar.high if sign > 0 else b.q_mvar.low,
            ),
        )
        for b in domain.assumptions.loads
    )
    return dict(
        loads=loads, generation=domain.assumptions.generation, context_id="fixed"
    )


def test_finite_entry_and_indefinite_terminal_continuation_under_alternating_disturbance():
    domain, initial, command = fixture_domain()
    c = CertifiedSingleController(domain, initial, (command,))
    plan = c.plans[0]
    assert 0 < len(plan.transitions) <= 10
    assert plan.ultimate_p_error_mw <= 0.05 and plan.ultimate_q_error_mvar <= 0.05
    assert all(p.certified for p in plan.network_paths)
    for k in range(60):
        result = c.advance(
            **observations(domain, (-1) ** k), proposal_failure="optimizer timed out"
        )
        # Independent closed forms; no calls to the response implementation.
        assert result.after.p_mw[0] == pytest.approx(1 - 0.2 * 0.5 ** (k + 1))
        assert result.after.q_mvar[2] == pytest.approx(0.1 * (1 - 0.5 ** (k + 1)))
        assert result.after.energy_mwh == 1
        assert result.deadline_step == 10
    assert c.steps[-1].disposition == "terminal"


def test_rejected_proposal_preserves_the_shifted_witness_and_does_not_advance_twice():
    domain, initial, command = fixture_domain()
    c = CertifiedSingleController(domain, initial, (command,))
    rejected = TubeCommand(p_mw=(0, 0.5, 0), q_mvar=(0.6, 0, 0))
    old = c.plans[0]
    step = c.advance(**observations(domain), proposal=(rejected,))
    assert c.plans == [old]
    assert step.command == command and step.proposal_reason
    assert step.after.p_mw[0] == pytest.approx(0.9)


def test_reoptimization_cannot_postpone_the_original_tracking_deadline():
    domain, initial, command = fixture_domain()
    c = CertifiedSingleController(domain, initial, (command,))
    for _ in range(20):
        step = c.advance(**observations(domain), proposal=(command,))
        assert step.deadline_step == 10
    assert len(c.plans[-1].transitions) == 0


@pytest.mark.parametrize("change", ["load", "availability", "context"])
def test_assumption_violation_prevents_a_certified_commit(change):
    domain, initial, command = fixture_domain()
    c = CertifiedSingleController(domain, initial, (command,))
    obs = observations(domain)
    if change == "load":
        obs["loads"] = (
            obs["loads"][0],
            BoundedBusLoad(
                bus="load", p_mw=I(low=4, high=4), q_mvar=I(low=0.3, high=0.3)
            ),
        )
    elif change == "availability":
        obs["generation"] = (FirmGeneration(resource_id="w", minimum_available_mw=1),)
    else:
        obs["context_id"] = "new permission or topology"
    with pytest.raises(ValueError):
        c.advance(**obs)
    assert c.state == initial and not c.steps


def test_initial_q_is_not_clipped_when_new_p_capability_excludes_it():
    domain, initial, command = fixture_domain()
    initial = initial.model_copy(update={"q_mvar": (0.4, 0, 0)})
    with pytest.raises(ValueError, match="capability"):
        certify_tube_plan(
            domain, point_box(initial), (command,), target_p_mw=2, target_q_mvar=0.2
        )
    assert initial.q_mvar[0] == 0.4


def test_storage_cannot_supply_an_infinite_nonzero_terminal_tail():
    domain, initial, command = fixture_domain()
    command = command.model_copy(update={"p_mw": (1, 0.1, 0)})
    with pytest.raises(ValueError, match="zero net PCS"):
        certify_tube_plan(
            domain, point_box(initial), (command,), target_p_mw=2, target_q_mvar=0.2
        )


def test_wide_disturbance_domain_cannot_receive_a_tracking_certificate():
    domain, initial, command = fixture_domain()
    a = domain.assumptions
    loads = (a.loads[0], a.loads[1].model_copy(update={"p_mw": I(low=2.8, high=3.2)}))
    domain = domain.model_copy(
        update={"assumptions": a.model_copy(update={"loads": loads})}
    )
    with pytest.raises(ValueError, match="engineering-band deadline"):
        CertifiedSingleController(domain, initial, (command,))


def test_target_changes_require_dwell_amplitude_and_a_new_certificate():
    domain, initial, command = fixture_domain()
    c = CertifiedSingleController(domain, initial, (command,))
    new = command.model_copy(update={"p_mw": (0.95, 0, 0)})
    target = (domain.assumptions.target_p_mw + 0.05, domain.assumptions.target_q_mvar)
    denied = c.advance(**observations(domain), proposal=(new,), target=target)
    assert (
        denied.accepted_target_p_mw == domain.assumptions.target_p_mw
        and denied.deadline_step == 10
    )
    for _ in range(19):
        c.advance(**observations(domain))
    accepted = c.advance(**observations(domain), proposal=(new,), target=target)
    assert accepted.disposition == "adopted" and accepted.deadline_step == 30
    assert accepted.accepted_target_p_mw == target[0]


def test_band_preserving_storage_action_can_be_adopted_after_the_original_deadline():
    domain, initial, command = fixture_domain()
    c = CertifiedSingleController(domain, initial, (command,))
    for _ in range(20):
        c.advance(**observations(domain))
    prefix = TubeCommand(p_mw=(0.99, 0.005, 0), q_mvar=command.q_mvar)
    step = c.advance(**observations(domain), proposal=(prefix, command))
    assert step.disposition == "adopted", step.proposal_reason
    assert step.deadline_step == 10 and c.plans[-1].entry_after_steps == 0
    assert step.after.energy_mwh == pytest.approx(1 - 0.005 / 0.95 / 60)
    c.advance(**observations(domain))
    assert c.state.p_mw[1] == 0


def test_unmodeled_state_drift_cannot_be_hidden_by_new_optimization():
    domain, initial, command = fixture_domain()
    c = CertifiedSingleController(domain, initial, (command,))
    c.state = initial.model_copy(update={"energy_mwh": 0.9})
    with pytest.raises(ValueError, match="actual state left"):
        c.advance(**observations(domain), proposal=(command,))
    assert not c.steps


def test_response_failure_cannot_partially_commit_an_adopted_plan(monkeypatch):
    from oilfield_energy.workflows.single_execution import guarantee

    domain, initial, command = fixture_domain()
    c = CertifiedSingleController(domain, initial, (command,))
    old = tuple(c.plans)

    def fail_response(*args):
        raise ArithmeticError("injected response failure")

    monkeypatch.setattr(guarantee, "execute_tube_command", fail_response)
    with pytest.raises(ArithmeticError, match="injected response failure"):
        c.advance(**observations(domain), proposal=(command,))
    assert tuple(c.plans) == old and c.state == initial and not c.steps
    assert c.offset == 0 and c.deadline == 10 and c.last_target_change == 0
