"""Safety induction, finite storage, future availability, and honest tracking."""

import pytest

from oilfield_energy.modules.control.contracts import (
    TubeCommand,
    TubeDeviceModel,
    TubeResource,
    TubeState,
)
from oilfield_energy.modules.power_flow.contracts import EnvelopeBranch, RadialEnvelope
from oilfield_energy.modules.power_flow.contracts import PowerInterval as I
from oilfield_energy.workflows.single_execution.api import (
    UnifiedSingleController,
    verify_unified_execution,
)
from oilfield_energy.workflows.single_execution.contracts import (
    BoundedBusLoad,
    FirmGeneration,
    SingleForecastEnvelope,
    SingleResearchPolicy,
    UnifiedDomain,
    UnifiedExecution,
)


def domain(*, sunset=None):
    network = RadialEnvelope(
        network_id="analytic",
        buses=("pcc", "load"),
        branches=(EnvelopeBranch(parent=0, child=1, r_pu=0.01, x_pu=0.02, tap=1, rating_mva=10),),
        slack=0,
        base_mva=10,
        slack_voltage_pu=1,
        shunt_q_mvar=(0, 0),
        voltage_min_pu=0.95,
        voltage_max_pu=1.05,
        pcc_min_mw=0.1,
        pcc_max_mw=5,
        pf_min=0.9,
    )
    resources = (
        TubeResource(
            resource_id="wind",
            bus="load",
            kind="wind",
            p=I(low=0, high=1.5),
            q=I(low=-0.5, high=0.5),
            s_mva=2,
            q_over_p=0.3,
            alpha_p=0.5,
            ramp_p_mw=0.4,
        ),
        TubeResource(
            resource_id="pv",
            bus="load",
            kind="pv",
            p=I(low=0, high=1),
            q=I(low=0, high=0),
            s_mva=1.1,
            alpha_p=0.98,
            ramp_p_mw=0.2,
        ),
        TubeResource(
            resource_id="pcs",
            bus="load",
            kind="storage",
            p=I(low=-0.5, high=0.5),
            q=I(low=0, high=0),
            s_mva=1,
            alpha_p=1,
            ramp_p_mw=0.4,
        ),
    )
    devices = TubeDeviceModel(
        version="unified-device-v1",
        resources=resources,
        alpha_q=0.5,
        aggregate_q_ramp_mvar=0.9,
        step_minutes=1,
        energy_mwh=I(low=0.2, high=2),
        eta_charge=0.95,
        eta_discharge=0.95,
        context_id="analytic",
        settling_resolution=0.0001,
    )
    forecasts = tuple(
        SingleForecastEnvelope(
            loads=(
                BoundedBusLoad(bus="pcc", p_mw=I(low=0, high=0), q_mvar=I(low=0, high=0)),
                BoundedBusLoad(bus="load", p_mw=I(low=2.99, high=3.01), q_mvar=I(low=0, high=0)),
            ),
            generation=(
                FirmGeneration(resource_id="wind", minimum_available_mw=1.5),
                FirmGeneration(
                    resource_id="pv",
                    minimum_available_mw=0 if sunset is not None and k >= sunset else 1,
                ),
            ),
        )
        for k in range(30)
    )
    return UnifiedDomain(
        research=SingleResearchPolicy(),
        network=network,
        devices=devices,
        forecasts=forecasts,
        terminal_command=TubeCommand(p_mw=(0, 0, 0), q_mvar=(0, 0, 0)),
        p_band_mw=0.05,
        q_band_mvar=0.05,
        response_steps=10,
        context_id="analytic",
    )


def observation(d, step):
    f = d.forecasts[min(step, len(d.forecasts) - 1)]
    return f.model_copy(
        update={
            "loads": tuple(
                b.model_copy(
                    update={
                        "p_mw": I(
                            low=(b.p_mw.low + b.p_mw.high) / 2, high=(b.p_mw.low + b.p_mw.high) / 2
                        )
                    }
                )
                for b in f.loads
            )
        }
    )


def initial():
    return TubeState(p_mw=(0, 0, 0), q_mvar=(0, 0, 0), energy_mwh=1)


def test_optimizer_failure_executes_certified_tail_and_integrates_energy_once():
    d = domain()
    c = UnifiedSingleController(d, initial())
    command = TubeCommand(p_mw=(0.6, 0.1, 0.2), q_mvar=(0, 0, 0))
    first = c.advance(
        observation(d, 0), context_id=d.context_id, target=(2.5, 0.02), proposal=command
    )
    assert first.disposition == "economic"
    assert first.after.energy_mwh == pytest.approx(1 - 0.2 / 0.95 / 60, abs=1e-15)
    certificate = c.plans[-1]
    for k in range(1, 25):
        row = c.advance(
            observation(d, k),
            context_id=d.context_id,
            target=(2.5, 0.02),
            proposal=None,
            proposal_failure="solver timeout",
        )
        assert row.command == (
            certificate.commands[k] if k < len(certificate.commands) else d.terminal_command
        )
        assert row.after.energy_mwh == first.after.energy_mwh
        assert row.deadline_step == 10
    assert c.state.p_mw == (0, 0, 0)
    evidence = UnifiedExecution(
        domain=d,
        initial=initial(),
        status="passed",
        requested_steps=25,
        steps=tuple(c.steps),
        plans=tuple(c.plans),
        terminal_proof_digest=c.terminal_proof_digest,
        tracking_status="violated",
    )
    verify_unified_execution(evidence)
    changed = c.steps[0].model_copy(update={"deadline_step": 100})
    with pytest.raises(ValueError, match="does not recompute"):
        verify_unified_execution(evidence.model_copy(update={"steps": (changed, *c.steps[1:])}))


def test_forecast_sunset_rejects_uncontinuable_pv_candidate_before_the_boundary():
    d = domain(sunset=4)
    c = UnifiedSingleController(d, initial())
    for k in range(4):
        row = c.advance(
            observation(d, k),
            context_id=d.context_id,
            target=(3, 0),
            proposal=TubeCommand(p_mw=(0, 0.1, 0), q_mvar=(0, 0, 0)),
        )
        if k == 0:
            assert row.disposition == "economic" and row.after.p_mw[1] > 0
    assert c.state.p_mw[1] == 0
    row = c.advance(observation(d, 4), context_id=d.context_id, target=(3, 0), proposal=None)
    assert row.after.p_mw[1] == 0


def test_out_of_domain_observation_or_context_never_advances_or_adopts():
    d = domain()
    c = UnifiedSingleController(d, initial())
    old_plans, old_state = tuple(c.plans), c.state
    wrong = observation(d, 0)
    wrong = wrong.model_copy(
        update={
            "loads": (wrong.loads[0], wrong.loads[1].model_copy(update={"p_mw": I(low=4, high=4)}))
        }
    )
    for observed, context in ((wrong, d.context_id), (observation(d, 0), "changed")):
        with pytest.raises(ValueError):
            c.advance(observed, context_id=context, target=(3, 0), proposal=d.terminal_command)
        assert c.state == old_state and tuple(c.plans) == old_plans and not c.steps


def test_unsafe_storage_candidate_cannot_replace_available_backup():
    d = domain()
    c = UnifiedSingleController(d, initial())
    row = c.advance(
        observation(d, 0),
        context_id=d.context_id,
        target=(3, 0),
        proposal=TubeCommand(p_mw=(0, 0, 10), q_mvar=(0, 0, 0)),
    )
    assert row.disposition == "terminal" and row.after == initial()
    assert row.proposal_reason and len(c.plans) == 1
