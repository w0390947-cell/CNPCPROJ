"""Migrated cluster/device integration assertions against the sole rolling path."""

from __future__ import annotations

import csv
import unittest
from dataclasses import replace
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
from unittest.mock import patch

import numpy as np

from oilfield_energy import service
from oilfield_energy.admm import run_admm_coordination
from oilfield_energy.bootstrap.adapters.cluster_rolling import RollingClusterEngine
from oilfield_energy.bootstrap.adapters.project_dataset import build_synthetic_case
from oilfield_energy.hierarchy_reporting import (
    _write_group_control_events,
    _write_group_control_timeseries,
)
from oilfield_energy.hierarchy_types import ADMMConfig, CommunicationConfig


class ClusterRollingTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        case = build_synthetic_case(4)
        cls.case = replace(
            case, time_hours=np.arange(4) / 4, assumptions=replace(case.assumptions, dt_hours=0.25)
        )
        cls.names = [mg.name for mg in cls.case.microgrids]
        captured = []
        original = RollingClusterEngine.run

        def observe(engine):
            original(engine)
            captured.append(engine)

        with patch.object(RollingClusterEngine, "run", new=observe):
            cls.execution = service.run_simulation(
                service.SimulationRequest(
                    scenario_type="cluster_coordination", steps=4, storage_enabled=False
                ),
                input_case=cls.case,
            ).cluster_execution
        assert captured and captured[0].results
        cls.result = SimpleNamespace(tracking=captured[0].results)

    def test_rolling_evidence_replaces_the_one_shot_plan(self):
        self.assertEqual(self.execution.algorithm_version, "cluster-rolling-v3")
        self.assertGreaterEqual(len(self.execution.rolling_updates), 2)
        for update in self.execution.rolling_updates:
            if update.adopted:
                self.assertTrue(update.adopted_p_mw)
                self.assertTrue(update.adopted_q_mvar)
        self.assertTrue(self.execution.cluster_transitions)
        self.assertTrue(all(r.committed for r in self.execution.cluster_transitions))

    def test_group_control_csv_retains_physical_channels(self):
        with TemporaryDirectory(dir=Path.cwd()) as directory:
            output = Path(directory)
            _write_group_control_timeseries(output / "series.csv", self.result.tracking)
            _write_group_control_events(output / "events.csv", self.result.tracking)
            with (output / "series.csv").open(encoding="utf-8-sig", newline="") as handle:
                rows = list(csv.DictReader(handle))
            self.assertEqual(
                len(rows), sum(len(t.time_minutes) for t in self.result.tracking.values())
            )
            self.assertTrue(
                {
                    "risk_index",
                    "state",
                    "action",
                    "storage_q_actual_mvar",
                    "reactive_execution_known",
                }.issubset(rows[0])
            )
            with (output / "events.csv").open(encoding="utf-8-sig", newline="") as handle:
                events = list(csv.DictReader(handle))
            self.assertEqual(
                len(events), sum(len(t.group_control_events) for t in self.result.tracking.values())
            )

    def test_device_layer_separates_wind_pv_and_group_control(self) -> None:
        valid_states = {
            "normal",
            "prepared",
            "risk_observing",
            "curtailing",
            "curtailed_hold",
            "restore_wait",
            "restoring",
            "recovery_aborted",
            "recovery_inhibit",
            "output_block",
            "hard_override",
        }
        for item in self.result.tracking.values():
            length = len(item.time_minutes)
            series = (
                item.wind_command_mw,
                item.wind_available_mw,
                item.wind_actual_mw,
                item.pv_plan_mw,
                item.pv_available_mw,
                item.pv_control_target_mw,
                item.pv_actual_mw,
                item.storage_actual_mw,
                item.wind_reactive_actual_mvar,
                item.pv_reactive_actual_mvar,
                item.storage_reactive_actual_mvar,
                item.svg_reactive_actual_mvar,
                item.reactive_dispatch_unserved_mvar,
                item.shancheng_reactive_command_accepted,
                item.reactive_execution_known,
                item.hard_wind_storage_target_mw,
                item.hard_safety_unserved_mw,
                item.hard_wind_storage_command_accepted,
                item.group_control_state,
                item.group_control_action,
                item.group_risk_limit_mw,
                item.group_safety_threshold_mw,
                item.group_restore_threshold_mw,
                item.group_current_net_load_mw,
                item.group_load_change_rate,
                item.group_pv_penetration,
                item.group_reverse_flow_probability,
                item.group_observed_reverse_flow_probability,
                item.group_reverse_flow_probability_valid,
                item.group_risk_index,
                item.group_required_curtailment_mw,
                item.group_requested_curtailment_mw,
                item.group_unserved_curtailment_mw,
                item.group_requested_restoration_mw,
                item.group_achieved_restoration_mw,
                item.group_remaining_curtailment_mw,
                item.group_recovery_dwell_remaining_minutes,
                item.group_recovery_evaluation_passed,
                item.group_restoration_response_error_mw,
                item.measured_pv_curtailment_mw,
                item.pcc_before_local_safety_mw,
                item.local_reverse_flow_reduction_mw,
                item.group_hard_override_active,
                item.local_power_factor_adjustment_mvar,
                item.actual_power_factor,
                item.storage_energy_mwh,
                item.storage_soc_within_limits,
            )
            self.assertTrue(all(len(values) == length for values in series))
            self.assertTrue(np.all(item.wind_actual_mw >= -1e-9))
            self.assertTrue(np.all(item.pv_actual_mw >= -1e-9))
            self.assertTrue(np.all(item.pv_control_target_mw >= -1e-9))
            self.assertTrue(np.all(item.pv_control_target_mw <= item.pv_available_mw + 1e-9))
            self.assertEqual(
                set(item.pv_station_actual_mw),
                set(item.pv_station_control_target_mw),
            )
            self.assertTrue(
                np.allclose(
                    np.sum(np.vstack(list(item.pv_station_actual_mw.values())), axis=0),
                    item.pv_actual_mw,
                )
            )
            self.assertTrue(
                np.allclose(
                    np.sum(
                        np.vstack(list(item.pv_station_control_target_mw.values())),
                        axis=0,
                    ),
                    item.pv_control_target_mw,
                )
            )
            mg = next(mg for mg in self.case.microgrids if mg.name == item.name)
            resource_ids = {mg.resource_id("wind", bus) for bus in mg.wind_available_mw}
            resource_ids |= {mg.resource_id("pv", bus) for bus in mg.pv_available_mw}
            resource_ids |= {
                mg.resource_id("storage", mg.storage.bus),
                mg.resource_id("svg", mg.svg_bus),
            }
            self.assertEqual(set(item.reactive_resource_plan_mvar), resource_ids)
            self.assertEqual(set(item.reactive_resource_target_mvar), resource_ids)
            self.assertEqual(set(item.reactive_resource_actual_mvar), resource_ids)
            for values in item.reactive_resource_actual_mvar.values():
                self.assertEqual(len(values), length)
                self.assertTrue(np.all(np.isfinite(values)))
            np.testing.assert_allclose(
                np.sum(
                    np.vstack(tuple(item.reactive_resource_actual_mvar.values())),
                    axis=0,
                ),
                item.wind_reactive_actual_mvar
                + item.pv_reactive_actual_mvar
                + item.storage_reactive_actual_mvar
                + item.svg_reactive_actual_mvar,
            )
            self.assertTrue(np.all(item.reactive_dispatch_unserved_mvar <= 1e-8))
            self.assertTrue(np.all(item.shancheng_reactive_command_accepted))
            self.assertTrue(np.all(item.reactive_execution_known))
            self.assertTrue(
                np.all(np.abs(item.wind_reactive_actual_mvar) <= 0.30 * item.wind_actual_mw + 1e-8)
            )
            self.assertTrue(set(item.group_control_state).issubset(valid_states))
            self.assertTrue(np.all(item.group_risk_limit_mw < item.group_safety_threshold_mw))
            self.assertTrue(
                np.all(item.group_safety_threshold_mw < item.group_restore_threshold_mw)
            )
            self.assertTrue(np.all((item.group_risk_index >= 0.0)))
            self.assertTrue(np.all((item.group_risk_index <= 1.0)))
            self.assertTrue(np.all((item.group_reverse_flow_probability >= 0.0)))
            self.assertTrue(np.all((item.group_reverse_flow_probability <= 1.0)))
            valid = item.group_reverse_flow_probability_valid
            # The explicit held-profile PlantInputs have no probability observations.
            # A deterministic fallback must not be presented as a measured probability.
            self.assertFalse(np.any(valid))
            self.assertTrue(np.all(np.isfinite(item.group_observed_reverse_flow_probability[valid])))
            self.assertTrue(np.all(np.isnan(item.group_observed_reverse_flow_probability[~valid])))
            self.assertEqual(
                item.safety_interventions,
                item.local_reverse_flow_interventions + item.local_power_factor_interventions,
            )
            self.assertEqual(
                item.group_curtailment_commands,
                sum(
                    event.event_type == "curtailment_command" for event in item.group_control_events
                ),
            )
            self.assertEqual(
                item.group_restoration_commands,
                sum(
                    event.event_type == "restoration_command" for event in item.group_control_events
                ),
            )

    def test_delay_loss_outage_fallback_and_recovery(self) -> None:
        fault = run_admm_coordination(
            build_synthetic_case(8),
            self.names,
            admm_config=ADMMConfig(max_iterations=220),
            communication_config=CommunicationConfig(
                loss_probability=0.05,
                min_delay_iterations=0,
                max_delay_iterations=2,
                stale_limit_iterations=3,
                outage_region="YA_B",
                outage_start_iteration=12,
                outage_end_iteration=22,
            ),
        )
        self.assertTrue(fault.converged, fault.stop_reason)
        self.assertGreater(fault.communication.dropped, 0)
        self.assertGreater(fault.communication.delayed, 0)
        self.assertGreater(fault.communication.outage_dropped, 0)
        self.assertGreater(fault.communication.stale_uses, 0)
        self.assertGreater(fault.communication.fallback_uses, 0)
        self.assertLessEqual(
            float(np.max(fault.aggregate_import_mw)),
            self.case.cluster_import_limit_mw + 1e-6,
        )
