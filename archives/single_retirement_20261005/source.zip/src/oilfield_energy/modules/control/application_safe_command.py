"""A conservative, capacity-preserving command proposal; acceptance is separate."""

from .contracts_tube import TubeCommand, TubeDeviceModel, TubeState


def approach_device_command(
    model: TubeDeviceModel, state: TubeState, target: TubeCommand, *, movement_fraction: float = 1.0
) -> TubeCommand:
    """Move along a convex command segment with a strict actuator budget reserve.

    Different P/Q response constants can still make a path infeasible; the caller
    must certify the resulting transition. This function never changes state.
    """
    if not 0 < movement_fraction <= 1:
        raise ValueError("command movement fraction must be in (0, 1]")
    scale = 1.0
    for r, p, u in zip(model.resources, state.p_mw, target.p_mw, strict=True):
        movement = abs(u - p) * r.alpha_p
        if movement:
            scale = min(scale, 0.98 * r.ramp_p_mw / movement)
    movement_q = sum(
        abs(u - q) * model.alpha_q for q, u in zip(state.q_mvar, target.q_mvar, strict=True)
    )
    if movement_q:
        scale = min(scale, 0.98 * model.aggregate_q_ramp_mvar / movement_q)
    scale *= movement_fraction
    return TubeCommand(
        p_mw=tuple(
            u if scale == 1 else p + scale * (u - p)
            for p, u in zip(state.p_mw, target.p_mw, strict=True)
        ),
        q_mvar=tuple(
            u if scale == 1 else q + scale * (u - q)
            for q, u in zip(state.q_mvar, target.q_mvar, strict=True)
        ),
    )
