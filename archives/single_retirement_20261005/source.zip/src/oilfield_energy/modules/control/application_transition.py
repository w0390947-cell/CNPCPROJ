"""Joint, conservative intersample guard; no I/O, network solve or future data."""

from fractions import Fraction
from math import inf, isfinite, nextafter

from .contracts import (
    ClusterTransitionDecision,
    RegionalTransitionProposal,
    RegionalTransitionSelection,
    TransitionSetpoint,
)


def _upper_float(value: Fraction) -> float:
    result = float(value)
    return nextafter(result, inf) if Fraction(result) < value else result


def authorize_cluster_transition(
    proposals: tuple[RegionalTransitionProposal, ...],
    *,
    expected_regions: tuple[str, ...],
    limit_mw: float,
) -> ClusterTransitionDecision:
    """Select reachable endpoints whose entire monotone response box is safe.

    Only explicitly deferrable injection decreases are changed. No benefit from
    this interval's increases is spent until the next interval. Exact rational
    arithmetic on the supplied binary floats prevents optimistic summation or
    allocation roundoff. An unproven box does NOT prove physical infeasibility.
    """
    if not isfinite(limit_mw) or limit_mw <= 0:
        raise ValueError("cluster import limit must be finite and positive")
    names = tuple(p.region for p in proposals)
    if (
        not names
        or len(set(names)) != len(names)
        or len(set(expected_regions)) != len(expected_regions)
        or set(names) != set(expected_regions)
    ):
        raise ValueError("transition proposals must cover each expected region exactly once")
    if len({(p.start_minute, p.duration_minutes) for p in proposals}) != 1:
        raise ValueError("transition proposals must share the same interval")
    # Canonical ID order makes allocation independent of caller iteration order.
    ordered = tuple(sorted(proposals, key=lambda p: p.region))
    demand = sum(
        (
            Fraction(p.gross_load_upper_mw)
            + Fraction(p.loss_upper_mw)
            + Fraction(p.injection_roundoff_mw)
            for p in ordered
        ),
        Fraction(),
    )
    requested = demand - sum(
        (Fraction(min(a.previous_mw, a.proposed_mw)) for p in ordered for a in p.actuators),
        Fraction(),
    )
    best = demand - sum(
        (Fraction(min(a.previous_mw, a.defer_to_mw)) for p in ordered for a in p.actuators),
        Fraction(),
    )
    if best > Fraction(limit_mw):
        return ClusterTransitionDecision(
            status="unproven",
            limit_mw=limit_mw,
            requested_upper_mw=_upper_float(requested),
            proposals=ordered,
            reason="负荷、网损及不可延后动作的区间上界已超出容量预算；不构成物理不可行证明",
        )
    headroom = Fraction(limit_mw) - best
    selections: list[RegionalTransitionSelection] = []
    for proposal in ordered:
        points: list[TransitionSetpoint] = []
        for actuator in sorted(proposal.actuators, key=lambda a: a.actuator):
            room = Fraction(actuator.defer_to_mw) - Fraction(actuator.proposed_mw)
            used = min(room, headroom)
            selected = _upper_float(Fraction(actuator.defer_to_mw) - used)
            # Rounding upwards retains extra injection and cannot spend budget.
            headroom -= Fraction(actuator.defer_to_mw) - Fraction(selected)
            points.append(TransitionSetpoint(actuator=actuator.actuator, p_mw=selected))
        selections.append(
            RegionalTransitionSelection(
                region=proposal.region,
                start_minute=proposal.start_minute,
                setpoints=tuple(points),
            )
        )
    selected_by_id = {(s.region, a.actuator): a.p_mw for s in selections for a in s.setpoints}
    upper = demand - sum(
        (
            Fraction(min(a.previous_mw, selected_by_id[p.region, a.actuator]))
            for p in ordered
            for a in p.actuators
        ),
        Fraction(),
    )
    if upper > Fraction(limit_mw):
        raise ArithmeticError("transition allocation violated its exact capacity invariant")
    return ClusterTransitionDecision(
        status="certified",
        limit_mw=limit_mw,
        requested_upper_mw=_upper_float(requested),
        selected_upper_mw=_upper_float(upper),
        proposals=ordered,
        selections=tuple(selections),
        reason="在所列负荷/网损上界和无超调响应假设下，整个闭区间的集群受电上界不超过容量",
    )


def validate_transition_selection(
    proposal: RegionalTransitionProposal,
    selection: RegionalTransitionSelection,
) -> dict[str, float]:
    """Validate a same-interval authorization before using any selected endpoint."""
    points = {s.actuator: s.p_mw for s in selection.setpoints}
    if (
        selection.region != proposal.region
        or selection.start_minute != proposal.start_minute
        or len(points) != len(selection.setpoints)
        or set(points) != {a.actuator for a in proposal.actuators}
    ):
        raise ValueError("transition selection identity or interval mismatch")
    if any(not a.proposed_mw <= points[a.actuator] <= a.defer_to_mw for a in proposal.actuators):
        raise ValueError("transition selection exceeds the authorized deferral range")
    return points
