"""Pure device-command fitting problem consumed by an injected numerical solver."""

from collections.abc import Callable
from dataclasses import dataclass
from math import sqrt

from .application_safe_command import approach_device_command
from .contracts_tube import TubeCommand, TubeDeviceModel, TubeState


@dataclass(frozen=True)
class CommandFitProblem:
    model: TubeDeviceModel
    state: TubeState
    nominal: TubeCommand
    target: tuple[float, float]
    response: Callable[[tuple[float, ...], tuple[float, ...]], tuple[float, float]]
    network_margins: Callable[[tuple[float, ...], tuple[float, ...]], tuple[float, ...]] | None = (
        None
    )
    storage_feedback_headroom_mw: float = 0.3

    @property
    def bounds(self) -> tuple[tuple[float, float], ...]:
        bounds: list[tuple[float, float]] = []
        for r, p, nominal in zip(
            self.model.resources, self.state.p_mw, self.nominal.p_mw, strict=True
        ):
            radius = 0.98 * r.ramp_p_mw / r.alpha_p
            low, high = max(r.p.low, p - radius), min(r.p.high, p + radius)
            if r.kind == "storage":
                center = min(high, max(low, nominal))
                low, high = (
                    max(low, center - self.storage_feedback_headroom_mw),
                    min(high, center + self.storage_feedback_headroom_mw),
                )
            bounds.append((low, high))
        for r, p in zip(self.model.resources, self.state.p_mw, strict=True):
            cap = r.s_mva if r.q_over_p is None else r.q_over_p * max(0, p)
            bounds.append((max(r.q.low, -cap), min(r.q.high, cap)))
        return tuple(bounds)

    @property
    def seed(self) -> tuple[float, ...]:
        n = len(self.model.resources)
        desired = (*self.nominal.p_mw, *self.nominal.q_mvar)
        clipped = tuple(
            min(hi, max(lo, x)) for x, (lo, hi) in zip(desired, self.bounds, strict=True)
        )
        command = approach_device_command(
            self.model, self.state, TubeCommand(p_mw=clipped[:n], q_mvar=clipped[n:])
        )
        return (*command.p_mw, *command.q_mvar)

    def endpoint(self, command: tuple[float, ...]) -> tuple[tuple[float, ...], tuple[float, ...]]:
        n = len(self.model.resources)
        return (
            tuple(
                p + r.alpha_p * (u - p)
                for r, p, u in zip(self.model.resources, self.state.p_mw, command[:n], strict=True)
            ),
            tuple(
                q + self.model.alpha_q * (u - q)
                for q, u in zip(self.state.q_mvar, command[n:], strict=True)
            ),
        )

    def objective(self, command: tuple[float, ...]) -> float:
        ps, qs = self.endpoint(command)
        pcc, qcc = self.response(ps, qs)
        return (
            (pcc - self.target[0]) ** 2
            + (qcc - self.target[1]) ** 2
            + 0.01 * sum((p - u) ** 2 for p, u in zip(ps, self.nominal.p_mw, strict=True))
            + 0.01 * sum((q - u) ** 2 for q, u in zip(qs, self.nominal.q_mvar, strict=True))
        )

    def margins(self, command: tuple[float, ...]) -> tuple[float, ...]:
        n, model = len(self.model.resources), self.model
        ps, qs = self.endpoint(command)
        values = [
            0.98 * model.aggregate_q_ramp_mvar
            - sum(abs(q - v) for q, v in zip(qs, self.state.q_mvar, strict=True))
        ]
        for i, r in enumerate(model.resources):
            circle_reserve = min(
                1e-7,
                max(0.0, r.s_mva - sqrt(self.state.p_mw[i] ** 2 + self.state.q_mvar[i] ** 2)) / 2,
            )
            for p, q in (
                (command[i], command[n + i]),
                (
                    max(abs(self.state.p_mw[i]), abs(ps[i])),
                    max(abs(self.state.q_mvar[i]), abs(qs[i])),
                ),
            ):
                values.append(r.s_mva - sqrt(p * p + q * q) - circle_reserve)
            if r.q_over_p is not None:
                reserve = min(
                    1e-6, max(0.0, r.q_over_p * self.state.p_mw[i] - abs(self.state.q_mvar[i])) / 2
                )
                values.extend(
                    (
                        r.q_over_p * command[i] - abs(command[n + i]) - reserve,
                        r.q_over_p * ps[i] - abs(qs[i]) - reserve,
                    )
                )
            if r.kind == "storage":
                p = command[i]
                energy = (
                    self.state.energy_mwh
                    + (-p / model.eta_discharge if p >= 0 else -p * model.eta_charge)
                    * model.step_minutes
                    / 60
                )
                values.extend(
                    (energy - model.energy_mwh.low - 1e-7, model.energy_mwh.high - energy - 1e-7)
                )
        if self.network_margins is not None:
            values.extend(self.network_margins(ps, qs))
        return tuple(values)
