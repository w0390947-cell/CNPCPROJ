"""Conditional loss bound from receiving-end thermal and voltage envelopes."""

from fractions import Fraction
from math import inf, isfinite, nextafter


def thermal_loss_upper_bound(
    *,
    base_mva: float,
    minimum_voltage_pu: float,
    resistance_and_rating: tuple[tuple[float, float], ...],
) -> float:
    """Return an outward-rounded I²R upper bound in MW.

    Each pair is (r_pu, receiving-end |S| upper bound in MVA), for every
    energized branch, on base_mva. Assumes |V_child| >= minimum_voltage_pu
    THROUGHOUT the interval. Taps need no correction at the receiving end.
    This does not certify those network assumptions. See Cluster_Transition.md.
    """
    if not all(isfinite(x) and x > 0 for x in (base_mva, minimum_voltage_pu)):
        raise ValueError("loss envelope requires positive finite base and voltage")
    if any(not isfinite(r) or r < 0 or not isfinite(s) or s <= 0 for r, s in resistance_and_rating):
        raise ValueError("loss envelope requires nonnegative resistance and positive rating")
    value = sum((Fraction(r) * Fraction(s) ** 2 for r, s in resistance_and_rating), Fraction())
    value /= Fraction(base_mva) * Fraction(minimum_voltage_pu) ** 2
    result = float(value)
    return nextafter(result, inf) if Fraction(result) < value else result
