"""Numerical and legacy-data ports for the sole formal single-microgrid workflow."""

from collections.abc import Callable
from dataclasses import replace
from datetime import datetime, timezone
from typing import Protocol, cast

import numpy as np
from numpy.typing import NDArray
from scipy.optimize import (  # pyright: ignore[reportMissingTypeStubs]
    minimize,  # pyright: ignore[reportUnknownVariableType]
)

from oilfield_energy.data import ProjectCase
from oilfield_energy.model import OptimizationResult
from oilfield_energy.modules.control.api import CommandFitProblem
from oilfield_energy.modules.control.contracts import (
    BusSeries,
    DeviceCheckpoint,
    PlantInputs,
    TubeCommand,
    TubeState,
)
from oilfield_energy.modules.dispatch.api import single_planning_power_factor
from oilfield_energy.modules.power_flow.api import radial_point_response, radial_proposal_margins
from oilfield_energy.modules.power_flow.contracts import PowerInterval
from oilfield_energy.modules.studies.contracts import ScenarioEvent
from oilfield_energy.workflows.cluster_execution.contracts import ExecutionPolicy, RollingProgress
from oilfield_energy.workflows.single_execution.api import (
    build_unified_domain,
    device_model_at,
    forecast_at,
    run_unified_feedback,
)
from oilfield_energy.workflows.single_execution.contracts import (
    BoundedBusLoad,
    ConditionalGuaranteeRequest,
    FirmGeneration,
    SingleEconomicProposal,
    SingleExecution,
    SingleForecastEnvelope,
    SingleResearchPolicy,
    UnifiedDomain,
)

from .cluster_execution import RegionalPlanRequest, execution_inputs, realize_regional_plan
from .cluster_rolling import forecast_grid, window_case
from .project_dataset import build_synthetic_case
from .single_model import assemble_closed_loop_domain
from .single_planning import prepare_single_case


class _OptimizerResult(Protocol):
    x: NDArray[np.float64]


_minimize = cast(Callable[..., _OptimizerResult], minimize)


def _checkpoint(domain: UnifiedDomain, state: TubeState, step: int) -> DeviceCheckpoint:
    i = next(i for i, r in enumerate(domain.devices.resources) if r.kind == "storage")
    return DeviceCheckpoint(
        minute=step,
        storage_energy_mwh=state.energy_mwh,
        storage_power_mw=state.p_mw[i],
        reactive_power_mvar={
            r.resource_id: q for r, q in zip(domain.devices.resources, state.q_mvar, strict=True)
        },
    )


class SingleNumericalPorts:
    def __init__(
        self,
        case: ProjectCase,
        reference: OptimizationResult,
        region: str,
        domain: UnifiedDomain,
        plant: PlantInputs,
        policy: ExecutionPolicy,
        storage_enabled: bool,
        seconds: float,
        reference_minutes: float,
        declared: ConditionalGuaranteeRequest | None,
    ) -> None:
        self.case, self.reference, self.region, self.domain, self.plant = (
            case,
            reference,
            region,
            domain,
            plant,
        )
        self.policy, self.storage_enabled, self.seconds = policy, storage_enabled, seconds
        self.reference_minutes, self.declared = reference_minutes, declared

    def observe(self, step: int) -> SingleForecastEnvelope:
        mg = self.case.microgrids[0]
        q = {b.bus_id: b.values[step] for b in self.plant.load_q}
        return SingleForecastEnvelope(
            loads=tuple(
                BoundedBusLoad(
                    bus=b.bus_id,
                    p_mw=PowerInterval(low=b.values[step], high=b.values[step]),
                    q_mvar=PowerInterval(low=q[b.bus_id], high=q[b.bus_id]),
                )
                for b in self.plant.load_p
            ),
            generation=tuple(
                FirmGeneration(
                    resource_id=mg.resource_id("wind" if kind == "wind" else "pv", b.bus_id),
                    minimum_available_mw=b.values[step],
                )
                for kind, rows in (
                    ("wind", self.plant.wind_available),
                    ("pv", self.plant.pv_available),
                )
                for b in rows
            ),
        )

    def propose(self, step: int, state: TubeState) -> SingleEconomicProposal:
        interval = round(self.case.assumptions.dt_hours * 60)
        stop = min(step + self.policy.horizon_minutes, len(self.case.time_hours) * interval)
        energy = np.asarray(
            self.reference.microgrids[self.region]["storage_energy_mwh"], dtype=float
        )
        terminal = (
            float(np.interp(stop, np.arange(len(energy)) * self.reference_minutes, energy))
            if self.storage_enabled
            else state.energy_mwh
        )
        storage = self.case.microgrids[0].storage
        if (
            not storage.e_min_mwh - self.policy.numerical_tolerance
            <= terminal
            <= storage.e_max_mwh + self.policy.numerical_tolerance
        ):
            raise ValueError("reference terminal energy exceeds physical bounds")
        terminal = min(storage.e_max_mwh, max(storage.e_min_mwh, terminal))
        window = window_case(
            self.case,
            step // interval,
            stop // interval,
            {self.region: state.energy_mwh},
            {self.region: terminal},
        )
        mg = window.microgrids[0]
        generation = [
            {
                x.resource_id: x.minimum_available_mw
                for x in self.domain.forecasts[min(k, len(self.domain.forecasts) - 1)].generation
            }
            for k in range(step, stop, interval)
        ]
        mg = replace(
            mg,
            wind_available_mw={
                b: np.asarray([v[mg.resource_id("wind", b)] for v in generation])
                for b in mg.wind_capacity_mw
            },
            pv_available_mw={
                b: np.asarray([v[mg.resource_id("pv", b)] for v in generation])
                for b in mg.pv_capacity_mw
            },
        )
        base_pf_target = window.assumptions.pf_dispatch_target
        window = replace(
            window,
            microgrids=[mg],
            assumptions=replace(
                window.assumptions,
                pf_dispatch_target=max(
                    window.assumptions.pf_dispatch_target,
                    single_planning_power_factor(
                        window.assumptions.pf_min, self.domain.research.planning_pf_tangent_fraction
                    ),
                ),
            ),
        )
        window = prepare_single_case(
            window,
            self.region,
            storage_enabled=self.storage_enabled,
            policy=self.policy,
            checkpoint=_checkpoint(self.domain, state, step),
        )
        p_target = (
            np.full(len(window.time_hours), self.declared.target_p_mw) if self.declared else None
        )
        q_target = (
            np.full(len(window.time_hours), self.declared.target_q_mvar) if self.declared else None
        )
        result, solved = realize_regional_plan(
            RegionalPlanRequest(
                window,
                self.region,
                p_target,
                q_target,
                self.storage_enabled,
                self.seconds,
                self.policy,
            )
        )
        pf_targets = (window.assumptions.pf_dispatch_target,)
        # Extra proposal headroom is a preference, never an extra physical limit.
        # A failed tighter solve may retry the declared planning target; both
        # candidates still face the identical independent safety supervisor.
        if result.status != "passed" and base_pf_target < pf_targets[0]:
            window = replace(
                window, assumptions=replace(window.assumptions, pf_dispatch_target=base_pf_target)
            )
            result, solved = realize_regional_plan(
                RegionalPlanRequest(
                    window,
                    self.region,
                    p_target,
                    q_target,
                    self.storage_enabled,
                    self.seconds,
                    self.policy,
                )
            )
            pf_targets = (*pf_targets, base_pf_target)
        command = None
        if result.status == "passed" and solved is not None:
            command = TubeCommand(
                p_mw=tuple(
                    result.resource_p_mw[r.resource_id][0] for r in self.domain.devices.resources
                ),
                q_mvar=tuple(
                    result.resource_q_mvar[r.resource_id][0] for r in self.domain.devices.resources
                ),
            )
        return SingleEconomicProposal(
            start_step=step,
            initial=state,
            command=command,
            target_p_mw=self.declared.target_p_mw
            if self.declared
            else (result.p_mw[0] if result.p_mw else 0),
            target_q_mvar=self.declared.target_q_mvar
            if self.declared
            else (result.q_mvar[0] if result.q_mvar else 0),
            result=result,
            planning_pf_targets=pf_targets,
        )

    def feedback(
        self,
        step: int,
        state: TubeState,
        observed: SingleForecastEnvelope,
        proposal: SingleEconomicProposal,
    ) -> TubeCommand:
        assert proposal.command is not None
        network = self.domain.network
        model = device_model_at(self.domain, step)
        loads = {b.bus: b for b in observed.loads}
        indices = tuple(
            tuple(i for i, r in enumerate(model.resources) if r.bus == bus) for bus in network.buses
        )

        def response(ps: tuple[float, ...], qs: tuple[float, ...]) -> tuple[float, float]:
            return radial_point_response(
                network,
                tuple(
                    loads[bus].p_mw.low - sum(ps[i] for i in ids)
                    for bus, ids in zip(network.buses, indices, strict=True)
                ),
                tuple(
                    loads[bus].q_mvar.low - sum(qs[i] for i in ids)
                    for bus, ids in zip(network.buses, indices, strict=True)
                ),
            )

        forecast_loads = {b.bus: b for b in forecast_at(self.domain, step).loads}

        def network_margins(ps: tuple[float, ...], qs: tuple[float, ...]) -> tuple[float, ...]:
            return radial_proposal_margins(
                network,
                tuple(
                    PowerInterval(
                        low=forecast_loads[bus].p_mw.low
                        - sum(max(state.p_mw[i], ps[i]) for i in ids),
                        high=forecast_loads[bus].p_mw.high
                        - sum(min(state.p_mw[i], ps[i]) for i in ids),
                    )
                    for bus, ids in zip(network.buses, indices, strict=True)
                ),
                tuple(
                    PowerInterval(
                        low=forecast_loads[bus].q_mvar.low
                        - sum(max(state.q_mvar[i], qs[i]) for i in ids),
                        high=forecast_loads[bus].q_mvar.high
                        - sum(min(state.q_mvar[i], qs[i]) for i in ids),
                    )
                    for bus, ids in zip(network.buses, indices, strict=True)
                ),
            )

        problem = CommandFitProblem(
            model,
            state,
            proposal.command,
            (proposal.target_p_mw, proposal.target_q_mvar),
            response,
            network_margins,
            self.domain.research.storage_feedback_headroom_mw,
        )

        def objective(x: NDArray[np.float64]) -> float:
            return problem.objective(tuple(float(v) for v in x))

        def margins(x: NDArray[np.float64]) -> NDArray[np.float64]:
            return np.asarray(problem.margins(tuple(float(v) for v in x)))

        solved = _minimize(
            objective,
            np.asarray(problem.seed),
            method="SLSQP",
            bounds=problem.bounds,
            constraints={"type": "ineq", "fun": margins},
            options={"maxiter": 100, "ftol": 1e-10},
        )
        values = tuple(float(v) for v in solved.x)
        if not all(np.isfinite(values)) or min(problem.margins(values)) < -1e-8:
            raise ValueError("feedback command optimizer returned no feasible device candidate")
        n = len(model.resources)
        return TubeCommand(p_mw=values[:n], q_mvar=values[n:])


def run_unified_single(
    case: ProjectCase,
    reference: OptimizationResult,
    region: str,
    *,
    storage_enabled: bool,
    time_limit_seconds: float,
    packaged_inputs: bool,
    events: list[ScenarioEvent],
    policy: ExecutionPolicy,
    progress: Callable[[RollingProgress], None] | None = None,
    guarantee: ConditionalGuaranteeRequest | None = None,
    research: SingleResearchPolicy | None = None,
) -> SingleExecution:
    research = research or SingleResearchPolicy(
        forecast_interpolation="linear" if packaged_inputs else "hold"
    )
    source = build_synthetic_case(steps=96) if packaged_inputs else case
    if packaged_inputs and source.dataset_sha256 != case.dataset_sha256:
        raise ValueError("native forecast dataset identity differs from the reference study")
    intraday, plants, basis = execution_inputs(source, packaged=packaged_inputs, events=events)
    intraday = replace(
        intraday,
        microgrids=[m for m in intraday.microgrids if m.name == region],
        reactive_plans={},
        storage_reserves={},
    )
    intraday = forecast_grid(intraday, policy.update_minutes)
    mg = intraday.microgrids[0]

    def series(rows: dict[str, NDArray[np.float64]]) -> tuple[BusSeries, ...]:
        return tuple(
            BusSeries(bus_id=b, values=tuple(float(v) for v in values))
            for b, values in rows.items()
        )

    forecast = PlantInputs(
        start=datetime(2026, 9, 1, tzinfo=timezone.utc),
        step_minutes=policy.update_minutes,
        load_p=series(mg.load_p_mw),
        load_q=series(mg.load_q_mvar),
        wind_available=series(mg.wind_available_mw),
        pv_available=series(mg.pv_available_mw),
    )
    declaration = ConditionalGuaranteeRequest(
        source=research.source,
        loads=tuple(
            BoundedBusLoad(
                bus=b.bus_id,
                p_mw=PowerInterval(low=b.values[0], high=b.values[0]),
                q_mvar=PowerInterval(low=q.values[0], high=q.values[0]),
            )
            for b in forecast.load_p
            for q in forecast.load_q
            if q.bus_id == b.bus_id
        ),
        generation=tuple(
            FirmGeneration(
                resource_id=mg.resource_id("wind" if kind == "wind" else "pv", b),
                minimum_available_mw=v,
            )
            for kind, capacities in (("wind", mg.wind_capacity_mw), ("pv", mg.pv_capacity_mw))
            for b, v in capacities.items()
        ),
        target_p_mw=0,
        target_q_mvar=0,
        maximum_target_step_mw=0,
        maximum_target_step_mvar=0,
        minimum_target_dwell_steps=1,
    )
    base = assemble_closed_loop_domain(
        mg, intraday, declaration, policy, storage_enabled=storage_enabled
    )
    total = round(len(case.time_hours) * case.assumptions.dt_hours * 60)
    domain = build_unified_domain(
        base.network,
        base.devices,
        forecast,
        research,
        total_steps=total,
        p_band_mw=base.p_band_mw,
        q_band_mvar=base.q_band_mvar,
        response_steps=base.maximum_settling_steps,
        declared=guarantee,
    )
    initial = TubeState(
        p_mw=domain.terminal_command.p_mw,
        q_mvar=domain.terminal_command.q_mvar,
        energy_mwh=mg.storage.e_initial_mwh,
    )
    if guarantee is not None and guarantee.initial_state is not None:
        ids = tuple(r.resource_id for r in domain.devices.resources)
        if set(ids) != set(guarantee.initial_resource_ids):
            raise ValueError("declared initial resource identities differ")
        axis = tuple(guarantee.initial_resource_ids.index(r) for r in ids)
        initial = TubeState(
            p_mw=tuple(guarantee.initial_state.p_mw[i] for i in axis),
            q_mvar=tuple(guarantee.initial_state.q_mvar[i] for i in axis),
            energy_mwh=guarantee.initial_state.energy_mwh,
        )
    ports = SingleNumericalPorts(
        intraday,
        reference,
        region,
        domain,
        plants[region],
        policy,
        storage_enabled,
        time_limit_seconds,
        case.assumptions.dt_hours * 60,
        guarantee,
    )

    def report(completed: int) -> None:
        if progress is not None and completed % policy.update_minutes == 0:
            progress(
                RollingProgress(
                    current_window=(completed - 1) // policy.update_minutes + 1,
                    completed_windows=completed // policy.update_minutes,
                    total_windows=(total + policy.update_minutes - 1) // policy.update_minutes,
                    start_minute=(completed - 1) // policy.update_minutes * policy.update_minutes,
                    end_minute=completed,
                    total_minutes=total,
                    phase="completed",
                )
            )

    execution = run_unified_feedback(
        domain,
        initial,
        total_steps=total,
        update_steps=policy.update_minutes,
        initial_target=(guarantee.target_p_mw, guarantee.target_q_mvar) if guarantee else (0, 0),
        observe=ports.observe,
        propose=ports.propose,
        feedback=ports.feedback,
        progress=report,
    )
    last = execution.steps[-1].after if execution.steps else initial
    return SingleExecution(
        version="single-execution-v2",
        region=region,
        status="passed"
        if execution.status == "passed" and execution.tracking_status == "passed"
        else "violated"
        if execution.tracking_status == "violated"
        else "unknown",
        reason=execution.reason
        or (
            "PCC tracking did not meet every retained deadline"
            if execution.tracking_status == "violated"
            else ""
        ),
        storage_enabled=storage_enabled,
        policy=policy,
        input_basis=basis,
        initialization="declared_actual_state"
        if guarantee and guarantee.initial_state
        else "declared_safe_state",
        initial_state=_checkpoint(domain, initial, 0),
        last_completed_state=_checkpoint(domain, last, len(execution.steps)),
        total_minutes=total,
        completed_minutes=len(execution.steps),
        unified=execution,
    )
