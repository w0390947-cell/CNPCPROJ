"""Explicit composition roots."""
