"""Prepare all regional endpoints before committing any SIL interval."""

from collections.abc import Callable
from fractions import Fraction

from oilfield_energy.modules.control.api import authorize_cluster_transition
from oilfield_energy.modules.control.contracts import (
    ClusterTransitionRecord,
    CommitDeviceTransition,
    RegionalTransitionProposal,
    RegionalTransitionReady,
    RegionalTransitionSelection,
)


def prepare_transition_round(
    *,
    proposals: tuple[RegionalTransitionProposal, ...],
    names: tuple[str, ...],
    limit_mw: float,
    prepare: Callable[[RegionalTransitionSelection], RegionalTransitionReady],
) -> ClusterTransitionRecord:
    """Compute a joint permission and obtain independent regional AC readiness.

    Does not commit. Rejected preparations have no executed interval; callers
    terminate their staged sessions and preserve only the completed prefix.
    """
    decision = authorize_cluster_transition(proposals, expected_regions=names, limit_mw=limit_mw)
    if decision.status != "certified":
        return ClusterTransitionRecord(decision=decision, reason=decision.reason)
    ready: list[RegionalTransitionReady] = []
    for selection in decision.selections:
        try:
            result = prepare(selection)
        except (ValueError, RuntimeError, FloatingPointError) as exc:
            result = RegionalTransitionReady(
                region=selection.region,
                start_minute=selection.start_minute,
                selection=selection,
                status="unknown",
                reason=str(exc),
            )
        if (
            result.region != selection.region
            or result.start_minute != selection.start_minute
            or result.selection != selection
        ):
            raise ValueError("regional readiness does not acknowledge the selected transition")
        ready.append(result)
    endpoint_sum = sum(
        (Fraction(r.pcc_import_mw) for r in ready if r.pcc_import_mw is not None), Fraction()
    )
    all_passed = all(
        r.status == "passed" and r.pcc_import_mw is not None for r in ready
    ) and endpoint_sum <= Fraction(limit_mw)
    return ClusterTransitionRecord(
        decision=decision,
        ready=tuple(ready),
        reason=""
        if all_passed
        else (
            "所选端点的实际 AC 总受电超出容量，本轮未执行"
            if endpoint_sum > Fraction(limit_mw)
            else "联合过渡端点未全部通过独立 AC/设备校核，本轮未执行"
        ),
    )


def transition_commits(record: ClusterTransitionRecord) -> tuple[CommitDeviceTransition, ...]:
    """The sole commit barrier: complete, matching, passed regional readiness."""
    selections = record.decision.selections
    if (
        record.decision.status != "certified"
        or record.committed
        or record.reason
        or len(record.ready) != len(selections)
        or not selections
        or any(
            r.status != "passed" or r.selection != s
            for r, s in zip(record.ready, selections, strict=True)
        )
    ):
        return ()
    return tuple(
        CommitDeviceTransition(region=s.region, start_minute=s.start_minute) for s in selections
    )
