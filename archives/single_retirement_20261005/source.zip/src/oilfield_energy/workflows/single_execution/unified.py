"""Economic proposals, certified continuation, and exactly one physical executor.

The finite-horizon forecast envelope persists at its last sample. A terminal
command is proved safe for every remaining sample and the persistent tail.
Optimization success is never a premise of the safety induction.
"""

from fractions import Fraction as F
from hashlib import sha256
from math import ceil, floor

from oilfield_energy.kernel.enclosures import lower, upper
from oilfield_energy.modules.control.api import (
    approach_device_command,
    certify_device_transition,
    execute_tube_command,
    point_box,
    tube_contains,
    validate_device_box,
)
from oilfield_energy.modules.control.contracts import (
    TubeBox,
    TubeCommand,
    TubeDeviceModel,
    TubeState,
)
from oilfield_energy.modules.power_flow.api import certify_ac_box
from oilfield_energy.modules.power_flow.contracts import ACBoxCertificate, PowerInterval

from .contracts_unified import (
    SingleForecastEnvelope,
    UnifiedDomain,
    UnifiedExecution,
    UnifiedPlanCertificate,
    UnifiedStep,
)


def forecast_at(domain: UnifiedDomain, step: int) -> SingleForecastEnvelope:
    return domain.forecasts[min(step, len(domain.forecasts) - 1)]


def device_model_at(domain: UnifiedDomain, step: int) -> TubeDeviceModel:
    floors = {r.resource_id: r.minimum_available_mw for r in forecast_at(domain, step).generation}
    return domain.devices.model_copy(
        update={
            "resources": tuple(
                r.model_copy(
                    update={
                        "p": PowerInterval(low=r.p.low, high=min(r.p.high, floors[r.resource_id]))
                    }
                )
                if r.resource_id in floors
                else r
                for r in domain.devices.resources
            )
        }
    )


def unified_network_box(
    domain: UnifiedDomain, box: TubeBox, loads: SingleForecastEnvelope, *, reusable: bool = False
) -> ACBoxCertificate:
    demand = {v.bus: v for v in loads.loads}
    p: list[PowerInterval] = []
    q: list[PowerInterval] = []
    for bus in domain.network.buses:
        indices = [i for i, r in enumerate(domain.devices.resources) if r.bus == bus]
        p.append(
            PowerInterval(
                low=lower(
                    F(demand[bus].p_mw.low) - sum((F(box.p_mw[i].high) for i in indices), F(0))
                ),
                high=upper(
                    F(demand[bus].p_mw.high) - sum((F(box.p_mw[i].low) for i in indices), F(0))
                ),
            )
        )
        q.append(
            PowerInterval(
                low=lower(
                    F(demand[bus].q_mvar.low) - sum((F(box.q_mvar[i].high) for i in indices), F(0))
                ),
                high=upper(
                    F(demand[bus].q_mvar.high) - sum((F(box.q_mvar[i].low) for i in indices), F(0))
                ),
            )
        )
    if reusable:
        # Nearby proposals can share an outward rational AC box. Failure retries
        # the original tight enclosure; no physical limit or guarantee is relaxed.
        def grid(x: PowerInterval) -> PowerInterval:
            return PowerInterval(
                low=lower(F(floor(F(x.low) * 40), 40)), high=upper(F(ceil(F(x.high) * 40), 40))
            )

        coarse = certify_ac_box(
            domain.network, tuple(grid(x) for x in p), tuple(grid(x) for x in q)
        )
        if coarse.certified:
            return coarse
    return certify_ac_box(domain.network, tuple(p), tuple(q))


def _midpoint(box: TubeBox) -> TubeState:
    return TubeState(
        p_mw=tuple((p.low + p.high) / 2 for p in box.p_mw),
        q_mvar=tuple((q.low + q.high) / 2 for q in box.q_mvar),
        energy_mwh=(box.energy_mwh.low + box.energy_mwh.high) / 2,
    )


def _terminal(domain: UnifiedDomain, box: TubeBox) -> bool:
    return all(
        x.low == x.high == u
        for x, u in zip(
            (*box.p_mw, *box.q_mvar),
            (*domain.terminal_command.p_mw, *domain.terminal_command.q_mvar),
            strict=True,
        )
    )


def certify_unified_terminal(domain: UnifiedDomain) -> str:
    command = domain.terminal_command
    if any(p != 0 for p in command.p_mw):
        raise ValueError(
            "the certified terminal policy requires zero active generation and PCS power"
        )
    box = point_box(
        TubeState(
            p_mw=command.p_mw, q_mvar=command.q_mvar, energy_mwh=domain.devices.energy_mwh.low
        )
    )
    box = box.model_copy(update={"energy_mwh": domain.devices.energy_mwh})
    digest = sha256()
    seen: set[str] = set()
    for k, forecast in enumerate(domain.forecasts):
        identity = forecast.model_dump_json()
        if identity in seen:
            continue
        seen.add(identity)
        transition = certify_device_transition(device_model_at(domain, k), box, command)
        if transition.endpoint != box:
            raise ValueError("terminal device set is not invariant")
        network = unified_network_box(domain, box, forecast, reusable=True)
        if not network.certified:
            raise ValueError("terminal AC continuation unavailable: " + network.reason)
        digest.update(network.model_dump_json().encode())
    return digest.hexdigest()


def certify_unified_plan(
    domain: UnifiedDomain,
    initial: TubeBox,
    start: int,
    proposal: tuple[TubeCommand, ...] = (),
) -> UnifiedPlanCertificate:
    """Certify a proposal followed by a constructive return to the terminal set."""
    box = initial
    commands: list[TubeCommand] = []
    digest = sha256()
    for offset in range(len(proposal) + domain.research.backup_maximum_steps + 1):
        if offset >= len(proposal) and _terminal(domain, box):
            return UnifiedPlanCertificate(
                start_step=start,
                initial=initial,
                commands=tuple(commands),
                terminal=box,
                network_proof_digest=digest.hexdigest(),
            )
        model = device_model_at(domain, start + offset)
        # Smaller certified backup movements recover paths whose independent
        # P/Q box would otherwise lose too much correlation. No failed trial
        # advances time, state, energy, or the retained certificate.
        fractions = (1.0,) if offset < len(proposal) else (1.0, 0.5, 0.25, 0.125, 0.0625)
        failure = "backup path unavailable"
        for fraction in fractions:
            command = (
                proposal[offset]
                if offset < len(proposal)
                else approach_device_command(
                    model, _midpoint(box), domain.terminal_command, movement_fraction=fraction
                )
            )
            try:
                transition = certify_device_transition(model, box, command)
                validate_device_box(
                    device_model_at(domain, start + offset + 1), transition.endpoint
                )
                network = unified_network_box(
                    domain, transition.path, forecast_at(domain, start + offset), reusable=True
                )
                if not network.certified:
                    raise ValueError("backup path AC certificate unavailable: " + network.reason)
            except ValueError as exc:
                failure = str(exc)
            else:
                break
        else:
            raise ValueError(failure)
        digest.update(network.model_dump_json().encode())
        commands.append(command)
        box = transition.endpoint
    raise ValueError("backup does not enter its invariant terminal set within the declared horizon")


def validate_unified_observation(
    domain: UnifiedDomain, step: int, actual: SingleForecastEnvelope
) -> None:
    expected = forecast_at(domain, step)
    loads = {x.bus: x for x in actual.loads}
    generation = {x.resource_id: x.minimum_available_mw for x in actual.generation}
    if len(loads) != len(actual.loads) or loads.keys() != {x.bus for x in expected.loads}:
        raise ValueError("load observation identities differ")
    for bound in expected.loads:
        value = loads[bound.bus]
        if (
            value.p_mw.low != value.p_mw.high
            or value.q_mvar.low != value.q_mvar.high
            or not bound.p_mw.contains(value.p_mw.low)
            or not bound.q_mvar.contains(value.q_mvar.low)
        ):
            raise ValueError("load observation left the declared forecast envelope")
    if (
        len(generation) != len(actual.generation)
        or generation.keys() != {x.resource_id for x in expected.generation}
        or any(generation[x.resource_id] < x.minimum_available_mw for x in expected.generation)
    ):
        raise ValueError("renewable availability left the declared forecast envelope")


class UnifiedSingleController:
    """The sole authority for committing one device cycle and retaining its tail."""

    def __init__(self, domain: UnifiedDomain, initial: TubeState) -> None:
        self.domain, self.state = domain, initial
        self.terminal_proof_digest = certify_unified_terminal(domain)
        self.plans = [certify_unified_plan(domain, point_box(initial), 0)]
        self.steps: list[UnifiedStep] = []
        self.target: tuple[float, float] | None = None
        self.deadline = domain.response_steps
        self.expected = point_box(initial)

    def advance(
        self,
        observed: SingleForecastEnvelope,
        *,
        context_id: str,
        target: tuple[float, float],
        proposal: TubeCommand | None,
        proposal_failure: str = "",
        target_changed: bool = False,
    ) -> UnifiedStep:
        k, domain = len(self.steps), self.domain
        if context_id != domain.context_id:
            raise ValueError("network, authorization, dynamics or forecast context changed")
        validate_unified_observation(domain, k, observed)
        if not tube_contains(self.expected, self.state):
            raise ValueError("actual state left the retained certified continuation")
        plan, reason = self.plans[-1], proposal_failure
        offset = k - plan.start_step
        disposition = "backup" if offset < len(plan.commands) else "terminal"
        replacement: UnifiedPlanCertificate | None = None
        accepted_fraction = 0.0
        if proposal is not None:
            backup = (
                plan.commands[offset] if offset < len(plan.commands) else domain.terminal_command
            )
            fractions = (
                (1.0, 0.5, 0.25, 0.125, 0.0625)
                if len(proposal.p_mw) == len(backup.p_mw)
                and len(proposal.q_mvar) == len(backup.q_mvar)
                else (1.0,)
            )
            for fraction in fractions:
                candidate = (
                    proposal
                    if fraction == 1
                    else TubeCommand(
                        p_mw=tuple(
                            b + fraction * (p - b)
                            for b, p in zip(backup.p_mw, proposal.p_mw, strict=True)
                        ),
                        q_mvar=tuple(
                            b + fraction * (p - b)
                            for b, p in zip(backup.q_mvar, proposal.q_mvar, strict=True)
                        ),
                    )
                )
                try:
                    replacement = certify_unified_plan(
                        domain, point_box(self.state), k, (candidate,)
                    )
                except ValueError as exc:
                    reason = str(exc)
                else:
                    accepted_fraction = fraction
                    if fraction < 1:
                        reason = f"candidate filtered at fraction {fraction}: {reason}"
                    plan, offset, disposition = replacement, 0, "economic"
                    break
        deadline = self.deadline
        if self.target is None or (target_changed and target != self.target):
            deadline = k + domain.response_steps
        command = plan.commands[offset] if offset < len(plan.commands) else domain.terminal_command
        # Recompute the retained prefix against the observed state before commit.
        source = plan.initial if replacement is not None else self.expected
        transition = certify_device_transition(device_model_at(domain, k), source, command)
        network = unified_network_box(domain, transition.path, observed)
        if not network.certified:
            raise ValueError("observed executed path fails its AC certificate: " + network.reason)
        after = execute_tube_command(device_model_at(domain, k), self.state, command)
        if not tube_contains(transition.endpoint, after):
            raise ValueError("executed response escaped its certified enclosure")
        endpoint = unified_network_box(domain, point_box(after), observed)
        p, q = endpoint.pcc_p_mw, endpoint.pcc_q_mvar
        if not endpoint.certified or p is None or q is None:
            raise ValueError("executed endpoint has no AC enclosure")
        track = (
            max(abs(p.low - target[0]), abs(p.high - target[0])) <= domain.p_band_mw
            and max(abs(q.low - target[1]), abs(q.high - target[1])) <= domain.q_band_mvar
        )
        row = UnifiedStep(
            step=k,
            before=self.state,
            after=after,
            command=command,
            proposed_command=proposal,
            candidate_fraction=accepted_fraction,
            observed=observed,
            disposition=disposition,
            proposal_reason=reason,
            plan_index=len(self.plans) if replacement else len(self.plans) - 1,
            plan_offset=offset,
            requested_p_mw=target[0],
            requested_q_mvar=target[1],
            deadline_step=deadline,
            pcc_p_mw=p,
            pcc_q_mvar=q,
            tracking_certified=track,
        )
        if replacement is not None:
            self.plans.append(replacement)
        self.steps.append(row)
        self.state = after
        self.expected, self.deadline, self.target = transition.endpoint, deadline, target
        return row


def verify_unified_execution(evidence: UnifiedExecution) -> None:
    """Recompute mathematical certificates and execution; reject altered claims."""
    if not evidence.plans:
        if evidence.status == "passed" or evidence.steps:
            raise ValueError("executed evidence has no initial certified continuation")
        return
    controller = UnifiedSingleController(evidence.domain, evidence.initial)
    if (
        controller.terminal_proof_digest != evidence.terminal_proof_digest
        or controller.plans[0] != evidence.plans[0]
    ):
        raise ValueError("initial or terminal certificate does not recompute")
    for row in evidence.steps:
        if row.plan_index not in (len(controller.plans), len(controller.plans) - 1):
            raise ValueError("certificate adoption order differs")
        target = (row.requested_p_mw, row.requested_q_mvar)
        replay = controller.advance(
            row.observed,
            context_id=evidence.domain.context_id,
            target=target,
            proposal=row.proposed_command,
            proposal_failure=row.proposal_reason,
            target_changed=controller.target != target,
        )
        if replay != row or controller.plans != list(evidence.plans[: len(controller.plans)]):
            raise ValueError(
                "recorded command, response, target deadline or AC evidence does not recompute"
            )
    if controller.plans != list(evidence.plans):
        raise ValueError("unexecuted certificate recorded as adopted")
    UnifiedExecution.model_validate(evidence.model_dump())
