"""One execution chain and its separately reported safety/tracking evidence."""

from typing import Literal

from pydantic import Field, model_validator

from oilfield_energy.modules.control.contracts import (
    TubeBox,
    TubeCommand,
    TubeDeviceModel,
    TubeState,
)
from oilfield_energy.modules.power_flow.contracts import PowerInterval, RadialEnvelope
from oilfield_energy.workflows.cluster_execution.contracts import RegionalExecution

from .contracts_guarantee import BoundedBusLoad, FirmGeneration, GuaranteeValue


class SingleResearchPolicy(GuaranteeValue):
    version: Literal["single-research-v1"] = "single-research-v1"
    source: str = (
        "Configurable research bounds for the seeded synthetic study; not field-validated limits"
    )
    load_relative_error: float = Field(default=0.025, ge=0, lt=1)
    wind_nameplate_error: float = Field(default=0.05, ge=0, lt=1)
    pv_nameplate_error: float = Field(default=0.15, ge=0, lt=1)
    settling_resolution: float = Field(default=0.0001, gt=0, le=0.001)
    backup_maximum_steps: int = Field(default=90, ge=10, le=240)
    planning_pf_tangent_fraction: float = Field(default=0.6, gt=0, le=1)
    forecast_interpolation: Literal["linear", "hold"] = "linear"
    storage_feedback_headroom_mw: float = Field(default=0.3, ge=0)
    terminal_persistence: Literal["last_forecast_envelope"] = "last_forecast_envelope"
    within_step_disturbance: Literal["zero_order_hold"] = "zero_order_hold"


class SingleForecastEnvelope(GuaranteeValue):
    loads: tuple[BoundedBusLoad, ...]
    generation: tuple[FirmGeneration, ...]


class UnifiedDomain(GuaranteeValue):
    version: Literal["unified-single-v1"] = "unified-single-v1"
    research: SingleResearchPolicy
    bound_source: str = Field(default="Explicit research domain", min_length=1)
    network: RadialEnvelope
    devices: TubeDeviceModel
    forecasts: tuple[SingleForecastEnvelope, ...]
    terminal_command: TubeCommand
    p_band_mw: float = Field(gt=0)
    q_band_mvar: float = Field(gt=0)
    response_steps: int = Field(ge=1)
    context_id: str

    @model_validator(mode="after")
    def coverage(self) -> "UnifiedDomain":
        if not self.forecasts or self.devices.version != "unified-device-v1":
            raise ValueError(
                "unified execution requires its explicit physical model and forecast bounds"
            )
        buses = set(self.network.buses)
        renewable = {r.resource_id for r in self.devices.resources if r.kind in ("wind", "pv")}
        for forecast in self.forecasts:
            if len(forecast.loads) != len(buses) or {b.bus for b in forecast.loads} != buses:
                raise ValueError("forecast load identities differ")
            if (
                len(forecast.generation) != len(renewable)
                or {r.resource_id for r in forecast.generation} != renewable
            ):
                raise ValueError("forecast generation identities differ")
        return self


class UnifiedPlanCertificate(GuaranteeValue):
    start_step: int = Field(ge=0)
    initial: TubeBox
    commands: tuple[TubeCommand, ...]
    terminal: TubeBox
    network_proof_digest: str


class SingleEconomicProposal(GuaranteeValue):
    start_step: int = Field(ge=0)
    initial: TubeState
    command: TubeCommand | None = None
    target_p_mw: float
    target_q_mvar: float
    result: RegionalExecution
    planning_pf_targets: tuple[float, ...] = ()


class UnifiedStep(GuaranteeValue):
    step: int = Field(ge=0)
    before: TubeState
    after: TubeState
    command: TubeCommand
    proposed_command: TubeCommand | None = None
    candidate_fraction: float = Field(default=0, ge=0, le=1)
    observed: SingleForecastEnvelope
    disposition: Literal["economic", "backup", "terminal"]
    proposal_reason: str = ""
    plan_index: int = Field(ge=0)
    plan_offset: int = Field(ge=0)
    requested_p_mw: float
    requested_q_mvar: float
    deadline_step: int = Field(ge=0)
    pcc_p_mw: PowerInterval
    pcc_q_mvar: PowerInterval
    tracking_certified: bool


class UnifiedExecution(GuaranteeValue):
    version: Literal["unified-single-v1"] = "unified-single-v1"
    domain: UnifiedDomain
    initial: TubeState
    status: Literal["passed", "unproven", "assumption_violated"]
    reason: str = ""
    requested_steps: int = Field(ge=1)
    steps: tuple[UnifiedStep, ...] = ()
    plans: tuple[UnifiedPlanCertificate, ...] = ()
    terminal_proof_digest: str
    tracking_status: Literal["passed", "violated", "not_assessed"]
    tracking_scope: Literal["completed_cycle_pcc"] = "completed_cycle_pcc"
    economic_proposals: tuple[SingleEconomicProposal, ...] = ()

    @model_validator(mode="after")
    def chain(self) -> "UnifiedExecution":
        state = self.initial
        for k, row in enumerate(self.steps):
            if row.step != k or row.before != state or row.plan_index >= len(self.plans):
                raise ValueError("unified evidence has a causal gap")
            plan = self.plans[row.plan_index]
            if row.plan_offset != k - plan.start_step:
                raise ValueError("backup clock was reset")
            command = (
                plan.commands[row.plan_offset]
                if row.plan_offset < len(plan.commands)
                else self.domain.terminal_command
            )
            if row.command != command:
                raise ValueError("executed command differs from its safety certificate")
            state = row.after
        if self.status == "passed" and (len(self.steps) != self.requested_steps or not self.plans):
            raise ValueError("safety success requires the complete executed chain")
        if self.tracking_status == "passed" and (
            not any(r.step + 1 >= r.deadline_step for r in self.steps)
            or any(not r.tracking_certified for r in self.steps if r.step + 1 >= r.deadline_step)
        ):
            raise ValueError("tracking success lacks deadline evidence")
        for proposal in self.economic_proposals:
            expected = (
                self.steps[proposal.start_step].before
                if proposal.start_step < len(self.steps)
                else state
            )
            if proposal.start_step > len(self.steps) or proposal.initial != expected:
                raise ValueError("economic replanning did not inherit the actual completed state")
        return self
