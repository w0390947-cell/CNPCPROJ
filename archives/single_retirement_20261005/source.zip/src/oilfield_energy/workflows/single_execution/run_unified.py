"""The single production orchestration; numerical and observation ports are injected."""

from collections.abc import Callable
from typing import Literal

from oilfield_energy.modules.control.contracts import TubeCommand, TubeState

from .contracts_unified import (
    SingleEconomicProposal,
    SingleForecastEnvelope,
    UnifiedDomain,
    UnifiedExecution,
)
from .unified import UnifiedSingleController


def run_unified_feedback(
    domain: UnifiedDomain,
    initial: TubeState,
    *,
    total_steps: int,
    update_steps: int,
    initial_target: tuple[float, float],
    observe: Callable[[int], SingleForecastEnvelope],
    propose: Callable[[int, TubeState], SingleEconomicProposal],
    feedback: Callable[
        [int, TubeState, SingleForecastEnvelope, SingleEconomicProposal], TubeCommand
    ],
    progress: Callable[[int], None] | None = None,
) -> UnifiedExecution:
    controller: UnifiedSingleController | None = None
    proposals: list[SingleEconomicProposal] = []
    active: SingleEconomicProposal | None = None
    target = initial_target
    reason, failure = "", ""
    status: Literal["passed", "unproven", "assumption_violated"] = "unproven"
    try:
        controller = UnifiedSingleController(domain, initial)
        for k in range(total_steps):
            observed = observe(k)
            changed = False
            if k % update_steps == 0:
                active, failure = None, ""
                try:
                    proposal = propose(k, controller.state)
                    if proposal.start_step != k or proposal.initial != controller.state:
                        raise ValueError("economic planner did not use the completed actual state")
                    proposals.append(proposal)
                    if proposal.result.status == "passed" and proposal.command is not None:
                        active = proposal
                        new_target = (proposal.target_p_mw, proposal.target_q_mvar)
                        changed, target = new_target != target, new_target
                    else:
                        failure = proposal.result.reason or "economic proposal unavailable"
                except (ValueError, RuntimeError, FloatingPointError) as exc:
                    failure = str(exc)
            command = None
            cycle_failure = failure
            if active is not None:
                try:
                    command = feedback(k, controller.state, observed, active)
                    cycle_failure = ""
                except (ValueError, RuntimeError, FloatingPointError) as exc:
                    cycle_failure = str(exc)
            controller.advance(
                observed,
                context_id=domain.context_id,
                target=target,
                proposal=command,
                proposal_failure=cycle_failure,
                target_changed=changed,
            )
            if progress is not None:
                progress(k + 1)
        status = "passed"
    except (ValueError, RuntimeError, FloatingPointError) as exc:
        reason = str(exc)
        status = "assumption_violated" if controller is not None else "unproven"
    rows = tuple(controller.steps) if controller else ()
    assessed = tuple(r for r in rows if r.step + 1 >= r.deadline_step)
    tracking: Literal["passed", "violated", "not_assessed"] = "not_assessed"
    if assessed:
        tracking = "passed" if all(r.tracking_certified for r in assessed) else "violated"
    return UnifiedExecution(
        domain=domain,
        initial=initial,
        status=status,
        reason=reason,
        requested_steps=total_steps,
        steps=rows,
        plans=tuple(controller.plans) if controller else (),
        terminal_proof_digest=controller.terminal_proof_digest if controller else "",
        tracking_status=tracking,
        economic_proposals=tuple(proposals),
    )
