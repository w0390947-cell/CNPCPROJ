"""Construct, retain and execute a feasible tail plus an invariant terminal box.

The optimizer is a proposal source. Only this supervisor owns accepted commands.
No online success, future observation, or endpoint-only AC test is an axiom.
"""

from fractions import Fraction as F

from oilfield_energy.kernel.enclosures import lower, upper
from oilfield_energy.modules.control.api import (
    certify_device_transition,
    execute_tube_command,
    point_box,
    tube_contains,
    tube_hull,
    validate_device_box,
)
from oilfield_energy.modules.control.contracts import (
    TubeBox,
    TubeCommand,
    TubeState,
    TubeTransition,
)
from oilfield_energy.modules.power_flow.api import certify_ac_box
from oilfield_energy.modules.power_flow.contracts import ACBoxCertificate, PowerInterval

from .contracts_guarantee import (
    BoundedBusLoad,
    CertifiedTubePlan,
    ClosedLoopDomain,
    ConditionalExecution,
    ConditionalStep,
    FirmGeneration,
)


def network_tube(domain: ClosedLoopDomain, box: TubeBox) -> ACBoxCertificate:
    loads = {v.bus: v for v in domain.assumptions.loads}
    p: list[PowerInterval] = []
    q: list[PowerInterval] = []
    for bus in domain.network.buses:
        indices = [i for i, r in enumerate(domain.devices.resources) if r.bus == bus]
        p.append(
            PowerInterval(
                low=lower(
                    F(loads[bus].p_mw.low)
                    - sum((F(box.p_mw[i].high) for i in indices), F(0))
                ),
                high=upper(
                    F(loads[bus].p_mw.high)
                    - sum((F(box.p_mw[i].low) for i in indices), F(0))
                ),
            )
        )
        q.append(
            PowerInterval(
                low=lower(
                    F(loads[bus].q_mvar.low)
                    - sum((F(box.q_mvar[i].high) for i in indices), F(0))
                ),
                high=upper(
                    F(loads[bus].q_mvar.high)
                    - sum((F(box.q_mvar[i].low) for i in indices), F(0))
                ),
            )
        )
    return certify_ac_box(domain.network, tuple(p), tuple(q))


def _subset(inner: TubeBox, outer: TubeBox) -> bool:
    return all(
        b.low <= a.low <= a.high <= b.high
        for a, b in zip(
            (*inner.p_mw, *inner.q_mvar, inner.energy_mwh),
            (*outer.p_mw, *outer.q_mvar, outer.energy_mwh),
            strict=True,
        )
    )


def _errors(cert: ACBoxCertificate, p: float, q: float) -> tuple[float, float]:
    if cert.pcc_p_mw is None or cert.pcc_q_mvar is None:
        raise ValueError("missing PCC enclosure")
    return (
        upper(max(abs(F(cert.pcc_p_mw.low) - F(p)), abs(F(cert.pcc_p_mw.high) - F(p)))),
        upper(
            max(abs(F(cert.pcc_q_mvar.low) - F(q)), abs(F(cert.pcc_q_mvar.high) - F(q)))
        ),
    )


def certify_tube_plan(
    domain: ClosedLoopDomain,
    initial: TubeBox,
    commands: tuple[TubeCommand, ...],
    *,
    target_p_mw: float,
    target_q_mvar: float,
    maximum_steps: int | None = None,
    band_after_steps: int | None = None,
) -> CertifiedTubePlan:
    """Build a finite-entry certificate; terminal holds have zero storage power.

    Rejects outside-domain proposals, rather than weakening limits. The terminal
    box is explicitly tested for invariance under the same executed dynamics.
    """
    limit = domain.maximum_settling_steps if maximum_steps is None else maximum_steps
    band_after = limit if band_after_steps is None else band_after_steps
    if not commands or not 0 <= limit <= domain.maximum_settling_steps:
        raise ValueError("invalid certificate horizon")
    if not 0 <= band_after <= domain.maximum_settling_steps:
        raise ValueError("invalid response deadline")
    storage = next(
        i for i, r in enumerate(domain.devices.resources) if r.kind == "storage"
    )
    final = commands[-1]
    if final.p_mw[storage] != 0:
        raise ValueError("terminal continuation must have zero net PCS power")
    validate_device_box(domain.devices, initial)
    transitions: list[TubeTransition] = []
    networks: list[ACBoxCertificate] = []
    box = initial
    last_reason = "terminal tracking envelope does not fit the engineering band"
    for k in range(limit + 1):
        # A last constant command may be repeated forever; earlier commands may
        # not be silently dropped merely because the current state is safe.
        if (
            k >= len(commands) - 1
            and box.p_mw[storage].low == box.p_mw[storage].high == 0
        ):
            target_box = point_box(
                TubeState(
                    p_mw=final.p_mw, q_mvar=final.q_mvar, energy_mwh=box.energy_mwh.low
                )
            )
            terminal = tube_hull(box, target_box)
            try:
                image = certify_device_transition(domain.devices, terminal, final)
                cert = network_tube(domain, terminal)
                ep, eq = _errors(cert, target_p_mw, target_q_mvar)
                if (
                    cert.certified
                    and _subset(image.endpoint, terminal)
                    and ep <= domain.p_band_mw
                    and eq <= domain.q_band_mvar
                ):
                    return CertifiedTubePlan(
                        initial=initial,
                        target_p_mw=target_p_mw,
                        target_q_mvar=target_q_mvar,
                        transitions=tuple(transitions),
                        network_paths=tuple(networks),
                        terminal=terminal,
                        terminal_command=final,
                        terminal_network=cert,
                        ultimate_p_error_mw=ep,
                        ultimate_q_error_mvar=eq,
                        entry_after_steps=min(k, band_after),
                    )
                last_reason = cert.reason or last_reason
            except ValueError as exc:
                last_reason = str(exc)
        if k == limit:
            break
        command = commands[min(k, len(commands) - 1)]
        transition = certify_device_transition(domain.devices, box, command)
        cert = network_tube(domain, transition.path)
        if not cert.certified:
            raise ValueError(
                "continuous quasi-static AC envelope unproven: " + cert.reason
            )
        if k >= band_after:
            ep, eq = _errors(cert, target_p_mw, target_q_mvar)
            if ep > domain.p_band_mw or eq > domain.q_band_mvar:
                raise ValueError(
                    "proposal leaves the engineering band after the retained deadline"
                )
        elif k + 1 >= band_after:
            endpoint = network_tube(domain, transition.endpoint)
            ep, eq = _errors(endpoint, target_p_mw, target_q_mvar)
            if (
                not endpoint.certified
                or ep > domain.p_band_mw
                or eq > domain.q_band_mvar
            ):
                raise ValueError(
                    "proposal misses the retained engineering-band deadline"
                )
        transitions.append(transition)
        networks.append(cert)
        box = transition.endpoint
    raise ValueError("finite-entry / terminal certificate unavailable: " + last_reason)


class CertifiedSingleController:
    """Causal supervisor with an immutable certificate and a non-resetting deadline.

    Fixed permissions/no override and the entire-interval exogenous envelope are
    explicit assumptions. The observations below detect violations; they cannot
    establish unobserved future bounds or undo an external physical disturbance.
    """

    def __init__(
        self,
        domain: ClosedLoopDomain,
        initial: TubeState,
        commands: tuple[TubeCommand, ...],
    ) -> None:
        plan = certify_tube_plan(
            domain,
            point_box(initial),
            commands,
            target_p_mw=domain.assumptions.target_p_mw,
            target_q_mvar=domain.assumptions.target_q_mvar,
        )
        self.domain, self.state = domain, initial
        self.plans = [plan]
        self.steps: list[ConditionalStep] = []
        self.offset = 0
        self.deadline = domain.maximum_settling_steps
        self.last_target_change = 0

    def advance(
        self,
        *,
        loads: tuple[BoundedBusLoad, ...],
        generation: tuple[FirmGeneration, ...],
        context_id: str,
        proposal: tuple[TubeCommand, ...] | None = None,
        target: tuple[float, float] | None = None,
        proposal_failure: str = "",
    ) -> ConditionalStep:
        domain = self.domain
        if context_id != domain.devices.context_id:
            raise ValueError("topology, dynamics or control authority context changed")
        expected = {b.bus: b for b in domain.assumptions.loads}
        actual = {b.bus: b for b in loads}
        if len(actual) != len(loads) or actual.keys() != expected.keys():
            raise ValueError("observed load identities differ")
        if any(
            v.p_mw.low != v.p_mw.high
            or v.q_mvar.low != v.q_mvar.high
            or not expected[b].p_mw.contains(v.p_mw.low)
            or not expected[b].q_mvar.contains(v.q_mvar.low)
            for b, v in actual.items()
        ):
            raise ValueError("observed load left the declared disturbance envelope")
        floors = {
            g.resource_id: g.minimum_available_mw for g in domain.assumptions.generation
        }
        available = {g.resource_id: g.minimum_available_mw for g in generation}
        if (
            len(available) != len(generation)
            or available.keys() != floors.keys()
            or any(available[rid] < floor for rid, floor in floors.items())
        ):
            raise ValueError("available generation left the declared firm envelope")
        plan = self.plans[-1]
        source = (
            plan.transitions[self.offset].initial
            if self.offset < len(plan.transitions)
            else plan.terminal
        )
        if not tube_contains(source, self.state):
            raise ValueError("actual state left the retained feasible tube")
        k, reason = len(self.steps), proposal_failure
        offset, deadline = self.offset, self.deadline
        last_target_change = self.last_target_change
        replacement: CertifiedTubePlan | None = None
        disposition = "backup" if self.offset < len(plan.transitions) else "terminal"
        if not self.steps:
            disposition = "initial"
        if proposal is not None:
            proposed_target = target or (plan.target_p_mw, plan.target_q_mvar)
            changed = proposed_target != (plan.target_p_mw, plan.target_q_mvar)
            try:
                deadline = self.deadline
                if changed:
                    a = domain.assumptions
                    if (
                        k - self.last_target_change < a.minimum_target_dwell_steps
                        or self.offset < len(plan.transitions)
                        or abs(F(proposed_target[0]) - F(plan.target_p_mw))
                        > F(a.maximum_target_step_mw)
                        or abs(F(proposed_target[1]) - F(plan.target_q_mvar))
                        > F(a.maximum_target_step_mvar)
                    ):
                        raise ValueError(
                            "target change fails amplitude / dwell / settled-state admission"
                        )
                    deadline = k + domain.maximum_settling_steps
                new = certify_tube_plan(
                    domain,
                    point_box(self.state),
                    proposal,
                    target_p_mw=proposed_target[0],
                    target_q_mvar=proposed_target[1],
                    band_after_steps=max(0, deadline - k),
                )
                replacement, offset, plan = new, 0, new
                if changed:
                    last_target_change = k
                disposition, reason = "adopted", ""
            except (ValueError, FloatingPointError, OverflowError) as exc:
                reason = str(exc)
                deadline = self.deadline
        command = (
            plan.transitions[offset].command
            if offset < len(plan.transitions)
            else plan.terminal_command
        )
        after = execute_tube_command(domain.devices, self.state, command)
        end = (
            plan.transitions[offset].endpoint
            if offset < len(plan.transitions)
            else plan.terminal
        )
        if not tube_contains(end, after):
            raise ArithmeticError(
                "execution differs from the certified ordinary response"
            )
        step = ConditionalStep(
            step=k,
            before=self.state,
            after=after,
            command=command,
            disposition=disposition,
            proposal_reason=reason,
            accepted_target_p_mw=plan.target_p_mw,
            accepted_target_q_mvar=plan.target_q_mvar,
            deadline_step=deadline,
            plan_index=len(self.plans) - 1 + int(replacement is not None),
            plan_offset=offset,
            observed_loads=loads,
            observed_generation=generation,
            context_id=context_id,
        )
        # Even an unexpected pure-response failure leaves the old witness intact.
        # Commit only after the endpoint and complete step record are validated.
        if replacement is not None:
            self.plans.append(replacement)
        self.steps.append(step)
        self.state = after
        self.offset, self.deadline = offset + 1, deadline
        self.last_target_change = last_target_change
        return step


def verify_conditional_execution(evidence: ConditionalExecution) -> None:
    """Recompute certificates and transitions; a deserialized status is not a proof.

    This validates the implemented model and declared bounds. It cannot attest
    to the authenticity of supplied measurements or future external bounds.
    """
    if not evidence.plans:
        if evidence.status == "passed":
            raise ValueError("no initial feasible witness")
        return

    def commands(plan: CertifiedTubePlan) -> tuple[TubeCommand, ...]:
        return (*tuple(t.command for t in plan.transitions), plan.terminal_command)

    controller = CertifiedSingleController(
        evidence.domain, evidence.initial, commands(evidence.plans[0])
    )
    if controller.plans[0] != evidence.plans[0]:
        raise ValueError("initial certificate does not recompute")
    for recorded in evidence.steps:
        proposal = None
        target = None
        if recorded.plan_index == len(controller.plans):
            plan = evidence.plans[recorded.plan_index]
            proposal, target = commands(plan), (plan.target_p_mw, plan.target_q_mvar)
        elif recorded.plan_index != len(controller.plans) - 1:
            raise ValueError("certificate adoption order differs")
        replayed = controller.advance(
            loads=recorded.observed_loads,
            generation=recorded.observed_generation,
            context_id=recorded.context_id,
            proposal=proposal,
            target=target,
            proposal_failure=recorded.proposal_reason,
        )
        if replayed != recorded or controller.plans != list(
            evidence.plans[: len(controller.plans)]
        ):
            raise ValueError("certificate or execution does not recompute")
    if controller.plans != list(evidence.plans):
        raise ValueError("unadopted certificate recorded as adopted")
