"""Declared disturbance domain and constructive conditional closed-loop evidence."""

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

from oilfield_energy.modules.control.contracts import (
    TubeBox,
    TubeCommand,
    TubeDeviceModel,
    TubeState,
    TubeTransition,
)
from oilfield_energy.modules.power_flow.contracts import (
    ACBoxCertificate,
    PowerInterval,
    RadialEnvelope,
)


class GuaranteeValue(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid", allow_inf_nan=False)


class BoundedBusLoad(GuaranteeValue):
    bus: str = Field(min_length=1)
    p_mw: PowerInterval
    q_mvar: PowerInterval


class FirmGeneration(GuaranteeValue):
    resource_id: str = Field(min_length=1)
    minimum_available_mw: float = Field(ge=0)


class ConditionalGuaranteeRequest(GuaranteeValue):
    """Absolute envelopes remain valid through execution AND terminal continuation.

    No default disturbance amplitude is invented. This v1 domain uses a fixed
    topology, slack voltage, authorized device set and ordinary response model.
    """

    source: str = Field(min_length=1)
    loads: tuple[BoundedBusLoad, ...]
    generation: tuple[FirmGeneration, ...]
    target_p_mw: float
    target_q_mvar: float
    maximum_target_step_mw: float = Field(ge=0)
    maximum_target_step_mvar: float = Field(ge=0)
    minimum_target_dwell_steps: int = Field(ge=1)
    initial_state: TubeState | None = None
    initial_resource_ids: tuple[str, ...] = ()

    @model_validator(mode="after")
    def unique(self) -> "ConditionalGuaranteeRequest":
        if (
            not self.loads
            or len({b.bus for b in self.loads}) != len(self.loads)
            or len({g.resource_id for g in self.generation}) != len(self.generation)
        ):
            raise ValueError("disturbance envelopes require unique complete identities")
        if any(b.p_mw.low < 0 for b in self.loads):
            raise ValueError("gross load P must be nonnegative")
        if (self.initial_state is None) != (not self.initial_resource_ids):
            raise ValueError(
                "declared initial state requires its resource identity axis"
            )
        if self.initial_state is not None and (
            len(set(self.initial_resource_ids)) != len(self.initial_resource_ids)
            or len(self.initial_state.p_mw) != len(self.initial_resource_ids)
            or len(self.initial_state.q_mvar) != len(self.initial_resource_ids)
        ):
            raise ValueError("initial state resource axis differs")
        return self


class ClosedLoopDomain(GuaranteeValue):
    version: Literal["conditional-single-v1"] = "conditional-single-v1"
    assumptions: ConditionalGuaranteeRequest
    network: RadialEnvelope
    devices: TubeDeviceModel
    p_band_mw: float = Field(gt=0)
    q_band_mvar: float = Field(gt=0)
    maximum_settling_steps: int = Field(ge=1, le=120)

    @model_validator(mode="after")
    def coverage(self) -> "ClosedLoopDomain":
        if {b.bus for b in self.assumptions.loads} != set(self.network.buses):
            raise ValueError("load domain must cover the exact network bus set")
        renewable = {
            r.resource_id: r for r in self.devices.resources if r.kind in ("wind", "pv")
        }
        floors = {
            g.resource_id: g.minimum_available_mw for g in self.assumptions.generation
        }
        if renewable.keys() != floors.keys():
            raise ValueError(
                "firm generation domain must cover every renewable resource"
            )
        if any(r.bus not in self.network.buses for r in self.devices.resources):
            raise ValueError("unknown resource bus")
        if any(r.p.high > floors[rid] for rid, r in renewable.items()):
            raise ValueError("device envelope exceeds declared firm generation")
        return self


class CertifiedTubePlan(GuaranteeValue):
    initial: TubeBox
    target_p_mw: float
    target_q_mvar: float
    transitions: tuple[TubeTransition, ...]
    network_paths: tuple[ACBoxCertificate, ...]
    terminal: TubeBox
    terminal_command: TubeCommand
    terminal_network: ACBoxCertificate
    ultimate_p_error_mw: float = Field(ge=0)
    ultimate_q_error_mvar: float = Field(ge=0)
    entry_after_steps: int = Field(ge=0)

    @model_validator(mode="after")
    def complete(self) -> "CertifiedTubePlan":
        if len(self.transitions) != len(
            self.network_paths
        ) or self.entry_after_steps > len(self.transitions):
            raise ValueError("tube proof length or entry bound differs")
        state = self.initial
        for transition, network in zip(
            self.transitions, self.network_paths, strict=True
        ):
            if transition.initial != state or not network.certified:
                raise ValueError("tube certificate has a gap or unsafe interval")
            state = transition.endpoint
        if not self.terminal_network.certified:
            raise ValueError("missing terminal network proof")
        source = (*state.p_mw, *state.q_mvar, state.energy_mwh)
        terminal = (
            *self.terminal.p_mw,
            *self.terminal.q_mvar,
            self.terminal.energy_mwh,
        )
        if len(source) != len(terminal) or any(
            not b.low <= a.low <= a.high <= b.high
            for a, b in zip(source, terminal, strict=True)
        ):
            raise ValueError("last reachable box is outside the terminal set")
        return self


class ConditionalStep(GuaranteeValue):
    step: int = Field(ge=0)
    before: TubeState
    after: TubeState
    command: TubeCommand
    disposition: Literal["initial", "adopted", "backup", "terminal"]
    proposal_reason: str = ""
    accepted_target_p_mw: float
    accepted_target_q_mvar: float
    deadline_step: int = Field(ge=0)
    plan_index: int = Field(ge=0)
    plan_offset: int = Field(ge=0)
    observed_loads: tuple[BoundedBusLoad, ...]
    observed_generation: tuple[FirmGeneration, ...]
    context_id: str


class ConditionalExecution(GuaranteeValue):
    version: Literal["conditional-single-v1"] = "conditional-single-v1"
    domain: ClosedLoopDomain
    status: Literal["passed", "unproven", "assumption_violated"]
    reason: str = ""
    initial: TubeState
    steps: tuple[ConditionalStep, ...] = ()
    plans: tuple[CertifiedTubePlan, ...] = ()
    requested_steps: int = Field(ge=1)

    @model_validator(mode="after")
    def sequence(self) -> "ConditionalExecution":
        state = self.initial
        for i, step in enumerate(self.steps):
            if (
                step.step != i
                or step.before != state
                or step.plan_index >= len(self.plans)
            ):
                raise ValueError("conditional execution evidence is not a causal chain")
            plan = self.plans[step.plan_index]
            command = (
                plan.transitions[step.plan_offset].command
                if step.plan_offset < len(plan.transitions)
                else plan.terminal_command
            )
            if step.command != command or (
                step.accepted_target_p_mw,
                step.accepted_target_q_mvar,
            ) != (plan.target_p_mw, plan.target_q_mvar):
                raise ValueError("execution does not use the adopted certificate")
            if step.context_id != self.domain.devices.context_id:
                raise ValueError("execution proof context differs")
            state = step.after
        if any(
            p.ultimate_p_error_mw > self.domain.p_band_mw
            or p.ultimate_q_error_mvar > self.domain.q_band_mvar
            for p in self.plans
        ):
            raise ValueError("certificate error bound exceeds engineering band")
        if self.status == "passed" and (
            len(self.steps) != self.requested_steps or not self.plans
        ):
            raise ValueError("conditional success requires a complete executed chain")
        return self
