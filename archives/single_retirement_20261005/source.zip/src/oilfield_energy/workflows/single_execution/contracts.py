"""Versioned evidence for an autonomous single-microgrid V2 execution."""

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

from oilfield_energy.modules.control.contracts import (
    DeviceCheckpoint,
    ReactiveDynamicsRecord,
)
from oilfield_energy.workflows.cluster_execution.contracts import (
    ExecutionPolicy,
    ExecutionStatus,
    RegionalExecution,
)

from .contracts_guarantee import (
    BoundedBusLoad as BoundedBusLoad,
)
from .contracts_guarantee import (
    CertifiedTubePlan as CertifiedTubePlan,
)
from .contracts_guarantee import (
    ClosedLoopDomain as ClosedLoopDomain,
)
from .contracts_guarantee import (
    ConditionalExecution as ConditionalExecution,
)
from .contracts_guarantee import (
    ConditionalGuaranteeRequest as ConditionalGuaranteeRequest,
)
from .contracts_guarantee import (
    ConditionalStep as ConditionalStep,
)
from .contracts_guarantee import (
    FirmGeneration as FirmGeneration,
)
from .contracts_unified import (
    SingleEconomicProposal as SingleEconomicProposal,
)
from .contracts_unified import (
    SingleForecastEnvelope as SingleForecastEnvelope,
)
from .contracts_unified import (
    SingleResearchPolicy as SingleResearchPolicy,
)
from .contracts_unified import (
    UnifiedDomain as UnifiedDomain,
)
from .contracts_unified import (
    UnifiedExecution as UnifiedExecution,
)
from .contracts_unified import (
    UnifiedPlanCertificate as UnifiedPlanCertificate,
)
from .contracts_unified import (
    UnifiedStep as UnifiedStep,
)


class SingleWindow(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid", allow_inf_nan=False)
    start_minute: int = Field(ge=0)
    end_minute: int = Field(gt=0)
    horizon_end_minute: int = Field(gt=0)
    initial_state: DeviceCheckpoint
    terminal_energy_mwh: float
    reactive_constraint_count: int = Field(ge=0)
    plan: RegionalExecution
    actual_end_state: DeviceCheckpoint | None = None

    @property
    def adopted(self) -> bool:
        required = {"DEVICE_PLAN", "AC_NETWORK", "REACTIVE_PLAN_ENVELOPE"}
        return (
            self.plan.status == "passed"
            and required <= {c.code for c in self.plan.checks if c.status == "passed"}
            and all(c.status == "passed" for c in self.plan.checks)
        )

    @model_validator(mode="after")
    def aligned(self) -> "SingleWindow":
        if not self.start_minute < self.end_minute <= self.horizon_end_minute:
            raise ValueError("invalid single-microgrid window")
        if self.initial_state.minute != self.start_minute:
            raise ValueError("window initial state must be the completed boundary state")
        if self.actual_end_state is not None and (
            not self.adopted or self.actual_end_state.minute != self.end_minute
        ):
            raise ValueError("only an adopted and completed window has an end state")
        return self


class SingleExecution(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid", allow_inf_nan=False)
    version: Literal["single-execution-v1", "single-execution-v2"] = "single-execution-v1"
    scope: Literal["synthetic_execution"] = "synthetic_execution"
    region: str
    status: ExecutionStatus
    reason: str = ""
    storage_enabled: bool
    policy: ExecutionPolicy
    input_basis: str
    initialization: Literal[
        "declared_reference_state", "declared_actual_state", "declared_safe_state"
    ] = "declared_reference_state"
    startup_transition_assessed: Literal[False] = False
    initial_state: DeviceCheckpoint | None = None
    last_completed_state: DeviceCheckpoint | None = None
    total_minutes: int = Field(gt=0)
    completed_minutes: int = Field(default=0, ge=0)
    windows: tuple[SingleWindow, ...] = ()
    minute: RegionalExecution | None = None
    reactive_dynamics: tuple[ReactiveDynamicsRecord, ...] = ()
    conditional_guarantee: ConditionalExecution | None = None
    unified: UnifiedExecution | None = None

    @model_validator(mode="after")
    def causal_evidence(self) -> "SingleExecution":
        if self.unified is not None:
            evidence = self.unified
            if self.version != "single-execution-v2" or self.conditional_guarantee is not None:
                raise ValueError("unified execution cannot mix historical controller evidence")
            if (
                self.policy.single_execution_version != evidence.version
                or self.windows
                or self.reactive_dynamics
            ):
                raise ValueError("unified execution requires its own policy and state evidence")
            if (
                self.completed_minutes != len(evidence.steps)
                or self.total_minutes != evidence.requested_steps
            ):
                raise ValueError("unified execution clock differs")
            if self.status == "passed" and (
                evidence.status != "passed" or evidence.tracking_status != "passed"
            ):
                raise ValueError("execution success requires both safety and tracking evidence")
            resources = evidence.domain.devices.resources
            storage = next(i for i, r in enumerate(resources) if r.kind == "storage")
            last = evidence.steps[-1].after if evidence.steps else evidence.initial
            for checkpoint, state, minute in (
                (self.initial_state, evidence.initial, 0),
                (self.last_completed_state, last, len(evidence.steps)),
            ):
                if (
                    checkpoint is None
                    or checkpoint.minute != minute
                    or checkpoint.storage_energy_mwh != state.energy_mwh
                    or checkpoint.storage_power_mw != state.p_mw[storage]
                    or checkpoint.reactive_power_mvar
                    != {r.resource_id: q for r, q in zip(resources, state.q_mvar, strict=True)}
                ):
                    raise ValueError("unified checkpoint differs from executed state")
            return self
        if self.version == "single-execution-v2" and self.status == "passed":
            raise ValueError("unified success requires its certificate chain")
        if self.conditional_guarantee is not None:
            evidence = self.conditional_guarantee
            if (
                self.completed_minutes != len(evidence.steps)
                or self.total_minutes != evidence.requested_steps
            ):
                raise ValueError("conditional execution clock differs")
            if self.status == "passed" and evidence.status != "passed":
                raise ValueError("missing conditional proof or failed assumptions")
            if self.windows or self.minute is not None or self.reactive_dynamics:
                raise ValueError("conditional and historical execution evidence cannot be mixed")
            resources = evidence.domain.devices.resources
            storage = next(i for i, r in enumerate(resources) if r.kind == "storage")
            last = evidence.steps[-1].after if evidence.steps else evidence.initial
            for checkpoint, actual, minute in (
                (self.initial_state, evidence.initial, 0),
                (self.last_completed_state, last, len(evidence.steps)),
            ):
                if checkpoint is None or (
                    checkpoint.minute != minute
                    or checkpoint.storage_energy_mwh != actual.energy_mwh
                    or checkpoint.storage_power_mw != actual.p_mw[storage]
                    or checkpoint.reactive_power_mvar
                    != {r.resource_id: q for r, q in zip(resources, actual.q_mvar, strict=True)}
                ):
                    raise ValueError("conditional checkpoint differs from the actual state chain")
            return self
        previous = self.initial_state
        for window in self.windows:
            if previous is None or window.initial_state != previous:
                raise ValueError("replanning must inherit the last completed actual state")
            if window.plan.region != self.region:
                raise ValueError("single execution cannot include another region")
            previous = window.actual_end_state
        if self.completed_minutes > self.total_minutes:
            raise ValueError("execution exceeds its requested horizon")
        if (
            self.last_completed_state is not None
            and self.last_completed_state.minute != self.completed_minutes
        ):
            raise ValueError("last completed state differs from the executed duration")
        if self.status == "passed" and (
            self.initial_state is None
            or not self.windows
            or previous is None
            or previous.minute != self.total_minutes
            or self.completed_minutes != self.total_minutes
            or self.minute is None
            or self.minute.status != "passed"
            or len(self.minute.time_minutes) != self.total_minutes
            or len(self.reactive_dynamics) != self.total_minutes
            or any(not w.adopted or w.actual_end_state is None for w in self.windows)
        ):
            raise ValueError("a V2 pass requires complete planning and execution evidence")
        if self.status == "passed" and (
            self.policy.dynamic_tracking is None
            or self.policy.reactive_planning is None
            or self.policy.reactive_planning.version != "reactive-planning-v2"
            or self.policy.device_capability_version != "device-capability-v2"
            or self.policy.reactive_dynamics_version != "reactive-dynamics-v1"
            or self.last_completed_state != previous
            or any(
                not r.ramp_compliant
                or not r.response_matches_prediction
                or not r.actual_capacity_within_limits
                for r in self.reactive_dynamics
            )
        ):
            raise ValueError("a V2 pass requires matching dynamics and capability evidence")
        return self
