"""Causal single-region orchestration; numerical engines are injected."""

from collections.abc import Callable

from oilfield_energy.modules.control.contracts import DeviceCheckpoint
from oilfield_energy.workflows.cluster_execution.contracts import (
    ExecutionPolicy,
    RollingProgress,
)

from .contracts import SingleWindow
from .forecast import build_unified_domain
from .guarantee import (
    CertifiedSingleController,
    certify_tube_plan,
    network_tube,
    verify_conditional_execution,
)
from .run_unified import run_unified_feedback
from .unified import (
    UnifiedSingleController,
    certify_unified_plan,
    certify_unified_terminal,
    device_model_at,
    forecast_at,
    unified_network_box,
    validate_unified_observation,
    verify_unified_execution,
)


def run_single_feedback(
    *,
    total_minutes: int,
    initial_state: DeviceCheckpoint,
    policy: ExecutionPolicy,
    prepare: Callable[[int, int, int, DeviceCheckpoint], SingleWindow],
    advance: Callable[[int, int], DeviceCheckpoint],
    progress: Callable[[RollingProgress], None] | None = None,
) -> tuple[tuple[SingleWindow, ...], str]:
    """Adopt one segment, execute it once, then pass its actual end state forward."""
    if initial_state.minute != 0 or total_minutes <= 0:
        raise ValueError("single execution must start at boundary zero")
    windows: list[SingleWindow] = []
    state = initial_state
    count = (total_minutes + policy.update_minutes - 1) // policy.update_minutes
    for start in range(0, total_minutes, policy.update_minutes):
        end = min(start + policy.update_minutes, total_minutes)
        horizon = min(start + policy.horizon_minutes, total_minutes)
        observation = RollingProgress(
            current_window=len(windows) + 1,
            completed_windows=len(windows),
            total_windows=count,
            start_minute=start,
            end_minute=end,
            total_minutes=total_minutes,
            phase="preparing",
        )
        if progress is not None:
            progress(observation)
        try:
            window = prepare(start, end, horizon, state)
            if (window.start_minute, window.end_minute, window.horizon_end_minute) != (
                start,
                end,
                horizon,
            ) or window.initial_state != state:
                raise ValueError("planner returned different boundaries or actual initial state")
            windows.append(window)
            if not window.adopted:
                if progress is not None:
                    progress(observation.model_copy(update={"phase": "stopped"}))
                return tuple(windows), window.plan.reason or "独立计划未通过采用校核"
            if progress is not None:
                progress(observation.model_copy(update={"phase": "executing"}))
            completed = advance(start, end)
            if completed.minute != end:
                raise ValueError("executor did not complete the adopted interval")
            windows[-1] = SingleWindow.model_validate(
                {**window.model_dump(), "actual_end_state": completed}
            )
            state = completed
        except (ValueError, RuntimeError, FloatingPointError) as exc:
            if progress is not None:
                progress(observation.model_copy(update={"phase": "stopped"}))
            return tuple(windows), f"独立滚动执行停止，保留已完成状态：{exc}"
        if progress is not None:
            progress(
                observation.model_copy(
                    update={
                        "phase": "completed",
                        "completed_windows": len(windows),
                    }
                )
            )
    return tuple(windows), ""


__all__ = [
    "run_unified_feedback",
    "build_unified_domain",
    "UnifiedSingleController",
    "certify_unified_plan",
    "certify_unified_terminal",
    "device_model_at",
    "forecast_at",
    "unified_network_box",
    "validate_unified_observation",
    "verify_unified_execution",
    "run_single_feedback",
    "CertifiedSingleController",
    "certify_tube_plan",
    "network_tube",
    "verify_conditional_execution",
]
