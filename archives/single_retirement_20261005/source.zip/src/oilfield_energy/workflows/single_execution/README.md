# 单微电网统一执行

负责人：仿真研究维护负责人；复核：优化调度、设备控制与潮流计算维护负责人。依据 ADR 0046。
公开入口 `api.run_unified_feedback`、`api.UnifiedSingleController`、`api.verify_unified_execution`；证据 `contracts.SingleExecution` / `UnifiedExecution`。

`forecast.py` 从预测和研究假设构造域，不接收未来实绩；`unified.py` 组合 control 和 power_flow 证书，独占采用、备用、时钟与状态提交；
`run_unified.py` 调用注入的经济、反馈、当前观察端口。数值求解在 bootstrap；所有正式输入共用一个执行器，不运行 ADMM。

每个命令连同有限备用及不变终态认证，失败候选保留旧尾部，储能每周期只积分一次。安全、期限后周期末跟踪、计划经济性分别报告。
条件与证明见 [Single_Microgrid_Execution.md](../../../../docs/modeling/Single_Microgrid_Execution.md)。
历史 `run_single_feedback`、`CertifiedSingleController` 等纯函数只用于旧证据回归，正式适配器不调用；完整旧实现见 `archives/single_execution_20261005`。
