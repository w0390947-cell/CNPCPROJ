"""The public service uses the proof supervisor and a real MISOCP proposal source."""

import numpy as np
import pytest

from oilfield_energy.data import (
    Line,
    MicrogridData,
    ModelAssumptions,
    ProjectCase,
    Storage,
)
from oilfield_energy.modules.control.contracts import TubeState
from oilfield_energy.modules.power_flow.contracts import PowerInterval as I
from oilfield_energy.service import SimulationRequest, SimulationResult, run_simulation
from oilfield_energy.workflows.single_execution.api import verify_conditional_execution
from oilfield_energy.workflows.single_execution.contracts import (
    BoundedBusLoad,
    ConditionalGuaranteeRequest,
    FirmGeneration,
)


def study():
    mg = MicrogridData(
        name="SC",
        buses=["pcc", "load"],
        lines=[Line("l", "pcc", "load", 0.01, 0.02, 10)],
        pcc_bus="pcc",
        base_mva=10,
        maximum_load_mw=3,
        p_grid_min_mw=0.1,
        p_grid_max_mw=5,
        voltage_min_pu=0.95,
        voltage_max_pu=1.05,
        load_p_mw={"pcc": np.zeros(2), "load": np.full(2, 3.0)},
        load_q_mvar={"pcc": np.zeros(2), "load": np.full(2, 0.3)},
        wind_available_mw={"load": np.full(2, 1.5)},
        wind_capacity_mw={"load": 2.0},
        wind_capacity_mva={"load": 2.2},
        pv_available_mw={},
        pv_capacity_mw={},
        pv_capacity_mva={},
        storage=Storage("load", 0.5, 2, 0.2, 1, 0.95, 0.95, 1),
        svg_bus="load",
        svg_q_min_mvar=-1,
        svg_q_max_mvar=1,
        wind_q_abs_over_p_max={"load": 0.3},
    )
    case = ProjectCase(
        time_hours=np.array([0.0, 0.25]),
        price_cny_per_mwh=np.full(2, 400.0),
        microgrids=[mg],
        assumptions=ModelAssumptions(),
        cluster_import_limit_mw=5,
    )
    settings = ConditionalGuaranteeRequest(
        source="explicit bounded two-bus algorithm example",
        loads=(
            BoundedBusLoad(bus="pcc", p_mw=I(low=0, high=0), q_mvar=I(low=0, high=0)),
            BoundedBusLoad(
                bus="load",
                p_mw=I(low=2.999, high=3.001),
                q_mvar=I(low=0.299, high=0.301),
            ),
        ),
        generation=(
            FirmGeneration(resource_id="SC:wind:load", minimum_available_mw=1.5),
        ),
        target_p_mw=2.0040595683,
        target_q_mvar=0.2081191366,
        maximum_target_step_mw=0.1,
        maximum_target_step_mvar=0.1,
        minimum_target_dwell_steps=10,
        initial_resource_ids=("SC:wind:load", "SC:storage:load", "SC:svg:load"),
        initial_state=TubeState(p_mw=(0.8, 0, 0), q_mvar=(0, 0, 0), energy_mwh=1),
    )
    return case, settings


def test_public_service_executes_conditional_mode_and_replans_from_actual_energy(
    monkeypatch,
):
    import oilfield_energy.bootstrap.adapters.single_guarantee as adapter

    case, settings = study()
    seen = []
    original = adapter.propose_terminal_command

    def proposal(case, region, domain, state, policy, seconds):
        seen.append(state)
        return original(case, region, domain, state, policy, seconds)

    monkeypatch.setattr(adapter, "propose_terminal_command", proposal)
    result = run_simulation(
        SimulationRequest(steps=2, conditional_guarantee=settings), input_case=case
    )
    execution = result.single_execution
    assert execution is not None
    proof = execution.conditional_guarantee
    assert proof is not None and proof.status == "passed", proof
    assert execution.status == "passed" and execution.completed_minutes == 30
    assert execution.initialization == "declared_actual_state"
    assert execution.minute is None
    assert seen[1] == proof.steps[14].after
    assert all(
        p.ultimate_p_error_mw <= 0.05 and p.ultimate_q_error_mvar <= 0.05
        for p in proof.plans
    )
    assert (
        SimulationResult.model_validate_json(result.model_dump_json()).single_execution
        == execution
    )
    verify_conditional_execution(proof)


def test_real_entry_keeps_the_certified_tail_when_the_next_optimizer_fails(monkeypatch):
    import oilfield_energy.bootstrap.adapters.single_guarantee as adapter

    case, settings = study()
    original = adapter.propose_terminal_command
    calls = 0

    def proposal(*args):
        nonlocal calls
        calls += 1
        if calls == 2:
            raise RuntimeError("solver time limit without a new incumbent")
        return original(*args)

    monkeypatch.setattr(adapter, "propose_terminal_command", proposal)
    result = run_simulation(
        SimulationRequest(steps=2, conditional_guarantee=settings), input_case=case
    )
    proof = result.single_execution.conditional_guarantee
    assert proof.status == "passed", proof.reason
    assert len(proof.plans) == 1 and len(proof.steps) == 30
    assert "time limit" in proof.steps[15].proposal_reason


def test_missing_or_inapplicable_bounds_cannot_be_silently_enabled():
    _, settings = study()
    with pytest.raises(ValueError, match="conditional guarantee"):
        SimulationRequest(
            scenario_type="cluster_coordination", conditional_guarantee=settings
        )
    with pytest.raises(ValueError):
        ConditionalGuaranteeRequest(source="missing bounds")


def test_original_sc_network_has_a_nonempty_conditional_domain():
    from oilfield_energy.bootstrap.adapters.project_dataset import build_synthetic_case
    from oilfield_energy.bootstrap.adapters.single_execution import (
        single_execution_policy,
    )
    from oilfield_energy.bootstrap.adapters.single_guarantee import (
        assemble_closed_loop_domain,
        propose_terminal_command,
        settling_commands,
    )
    from oilfield_energy.workflows.single_execution.api import CertifiedSingleController

    case = build_synthetic_case(96)
    mg = next(m for m in case.microgrids if m.name == "SC")
    settings = ConditionalGuaranteeRequest(
        source="declared SC algorithm example: 0.0001 MW/Mvar per bus, not field limits",
        loads=tuple(
            BoundedBusLoad(
                bus=b,
                p_mw=I(
                    low=max(0, float(mg.load_p_mw[b][0]) - 0.0001),
                    high=float(mg.load_p_mw[b][0]) + 0.0001,
                ),
                q_mvar=I(
                    low=float(mg.load_q_mvar[b][0]) - 0.0001,
                    high=float(mg.load_q_mvar[b][0]) + 0.0001,
                ),
            )
            for b in mg.buses
        ),
        generation=tuple(
            FirmGeneration(
                resource_id=mg.resource_id(kind, b), minimum_available_mw=float(v[0])
            )
            for kind, rows in (
                ("wind", mg.wind_available_mw),
                ("pv", mg.pv_available_mw),
            )
            for b, v in rows.items()
        ),
        target_p_mw=6.5,
        target_q_mvar=2.5,
        maximum_target_step_mw=0.1,
        maximum_target_step_mvar=0.1,
        minimum_target_dwell_steps=10,
    )
    policy = single_execution_policy()
    domain = assemble_closed_loop_domain(
        mg, case, settings, policy, storage_enabled=True
    )
    n = len(domain.devices.resources)
    seed = TubeState(
        p_mw=(0,) * n, q_mvar=(0,) * n, energy_mwh=mg.storage.e_initial_mwh
    )
    terminal = propose_terminal_command(case, "SC", domain, seed, policy, 15)
    powers = list(terminal.p_mw)
    powers[0] -= 0.1
    initial = TubeState(
        p_mw=tuple(powers), q_mvar=terminal.q_mvar, energy_mwh=seed.energy_mwh
    )
    controller = CertifiedSingleController(
        domain, initial, settling_commands(domain, initial, terminal)
    )
    for k in range(15):
        loads = tuple(
            BoundedBusLoad(
                bus=b.bus,
                p_mw=I(
                    low=b.p_mw.low if k % 2 else b.p_mw.high,
                    high=b.p_mw.low if k % 2 else b.p_mw.high,
                ),
                q_mvar=I(
                    low=b.q_mvar.low if k % 2 else b.q_mvar.high,
                    high=b.q_mvar.low if k % 2 else b.q_mvar.high,
                ),
            )
            for b in settings.loads
        )
        controller.advance(
            loads=loads,
            generation=settings.generation,
            context_id=domain.devices.context_id,
        )
    proof = controller.plans[0]
    assert len(domain.network.buses) == 10
    assert 0 < proof.entry_after_steps <= 10
    assert proof.ultimate_p_error_mw <= 0.05 and proof.ultimate_q_error_mvar <= 0.05


@pytest.mark.parametrize("tamper", ["state", "network_bound", "deadline", "command"])
def test_modified_serialized_evidence_cannot_survive_proof_recomputation(tamper):
    from oilfield_energy.workflows.single_execution.contracts import (
        ConditionalExecution,
    )

    case, settings = study()
    result = run_simulation(
        SimulationRequest(steps=2, conditional_guarantee=settings), input_case=case
    )
    raw = result.single_execution.conditional_guarantee.model_dump(mode="json")
    if tamper == "state":
        raw["steps"][-1]["after"]["energy_mwh"] += 0.1
    elif tamper == "network_bound":
        raw["plans"][0]["terminal_network"]["pcc_p_mw"]["high"] -= 0.001
    elif tamper == "deadline":
        raw["steps"][-1]["deadline_step"] += 10
    else:
        raw["steps"][-1]["command"]["p_mw"][0] += 0.01
    with pytest.raises(ValueError):
        verify_conditional_execution(ConditionalExecution.model_validate(raw))
