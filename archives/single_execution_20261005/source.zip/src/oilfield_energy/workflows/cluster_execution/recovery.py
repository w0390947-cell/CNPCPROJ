"""Bounded coordinate/realize/diagnose feedback on one immutable planning window.

Numerical payloads are opaque here. Callbacks must use the same input snapshot
and must not advance the plant, publish commands or mutate the supplied maps.
"""

from collections.abc import Callable, Mapping
from dataclasses import dataclass
from math import isfinite
from types import MappingProxyType
from typing import Generic, TypeVar

from oilfield_energy.modules.dispatch.api import (
    cluster_power_factor_tracking_margin,
    equivalent_coordination_calibration,
    tighten_cluster_power_factor_reference,
)
from oilfield_energy.modules.dispatch.contracts import (
    CoordinationNetworkCalibration,
    CoordinationRecoveryPolicy,
    PCCTrackingLimits,
)
from oilfield_energy.modules.power_flow.contracts import ClusterPowerFactorPolicy

from .contracts import (
    CoordinationRecoveryReport,
    CoordinationRecoveryRound,
    RecoveryStopReason,
    RegionalCalibrationFeedback,
)

T = TypeVar("T")
CalibrationMap = Mapping[str, CoordinationNetworkCalibration]


@dataclass(frozen=True)
class RecoveryTrial(Generic[T]):
    payload: T
    evidence: CoordinationRecoveryRound


@dataclass(frozen=True)
class RecoveryResult(Generic[T]):
    payload: T | None
    report: CoordinationRecoveryReport


def run_reference_recovery(
    *,
    names: tuple[str, ...],
    time_minutes: tuple[float, ...],
    initial_calibration: CalibrationMap | None,
    policy: CoordinationRecoveryPolicy | None,
    attempt: Callable[[CalibrationMap | None, int, tuple[float, ...]], RecoveryTrial[T]],
    diagnose: Callable[[T, int], tuple[RegionalCalibrationFeedback, ...]] | None,
    power_factor_policy: ClusterPowerFactorPolicy | None = None,
    tracking_limits: PCCTrackingLimits | None = None,
) -> RecoveryResult[T]:
    """Retry only reference-related rejection, with complete current AC witnesses.

    A failed diagnostic, repeated calibration, exhausted budget or nonconverged
    coordinator stops without an adoption certificate. This fixed-point update
    is not a globally valid feasibility cut or a convergence guarantee.
    """
    if (
        not names
        or len(set(names)) != len(names)
        or any(not n.strip() for n in names)
        or not time_minutes
        or any(not isfinite(t) or t < 0 for t in time_minutes)
        or any(b <= a for a, b in zip(time_minutes, time_minutes[1:]))
    ):
        raise ValueError("recovery requires unique regions and a planning time axis")
    current = (
        MappingProxyType(dict(initial_calibration)) if initial_calibration is not None else None
    )
    if current is not None and (
        set(current) != set(names)
        or any(len(v.p_loss_mw) != len(time_minutes) for v in current.values())
    ):
        raise ValueError("initial calibration does not cover the recovery window")
    seen: list[CalibrationMap] = [current] if current is not None else []
    margin = (0.0,) * len(time_minutes)
    robust_margin = (
        cluster_power_factor_tracking_margin(
            target=power_factor_policy.target, region_count=len(names), tracking=tracking_limits
        )
        if power_factor_policy is not None and tracking_limits is not None
        else None
    )
    if power_factor_policy is not None and robust_margin is None:
        raise ValueError("PF recovery requires the actual regional tracking limits")
    history: list[CoordinationRecoveryRound] = []
    payload: T | None = None

    def finish(stop: RecoveryStopReason, reason: str = "") -> RecoveryResult[T]:
        return RecoveryResult(
            payload,
            CoordinationRecoveryReport(
                policy=policy,
                power_factor_policy=power_factor_policy,
                accepted=stop == "accepted",
                stop_reason=stop,
                reason=reason,
                rounds=tuple(history),
            ),
        )

    maximum = policy.max_recoordinations if policy is not None else 0
    for number in range(1, maximum + 2):
        try:
            trial = attempt(current, number, margin)
            record = trial.evidence
            if record.round != number or record.feedback:
                raise ValueError("unexpected recovery round or premature feedback")
            if (
                record.outcome in {"passed", "power_factor_rejected"}
                and power_factor_policy is not None
            ):
                pf = record.cluster_power_factor
                if (
                    pf is None
                    or pf.policy != power_factor_policy
                    or tuple(p.time_minutes for p in pf.points) != time_minutes
                    or (record.outcome == "passed" and pf.status != "passed")
                    or (
                        record.outcome == "power_factor_rejected"
                        and (
                            pf.status != "violated"
                            or any(p.p_mw <= 0 or p.status == "unknown" for p in pf.points)
                        )
                    )
                ):
                    raise ValueError("missing or inconsistent joint power factor evidence")
            if record.p_target_mw or record.q_target_mvar:
                if (
                    set(record.p_target_mw) != set(names)
                    or set(record.q_target_mvar) != set(names)
                    or any(
                        len(v) != len(time_minutes)
                        for v in (*record.p_target_mw.values(), *record.q_target_mvar.values())
                    )
                ):
                    raise ValueError("coordination targets do not cover the recovery window")
            payload = trial.payload
            history.append(
                record.model_copy(
                    update={
                        "calibration_used": dict(current) if current is not None else None,
                        "power_factor_margin_mvar": margin
                        if power_factor_policy is not None
                        else (),
                    }
                )
            )
        except (ValueError, RuntimeError, FloatingPointError) as exc:
            history.append(
                CoordinationRecoveryRound(
                    round=number,
                    outcome="error",
                    reason=str(exc),
                    calibration_used=dict(current) if current is not None else None,
                    power_factor_margin_mvar=margin if power_factor_policy is not None else (),
                )
            )
            return finish("error", str(exc))
        if record.outcome == "passed":
            return finish("accepted")
        if record.outcome == "power_factor_rejected":
            if policy is None or power_factor_policy is None or tracking_limits is None:
                return finish("disabled", "未配置集群功率因数参考恢复策略")
            if number > maximum:
                return finish("budget_exhausted", "跨层恢复轮次已耗尽，集群功率因数仍不合格")
            assert record.cluster_power_factor is not None
            points = record.cluster_power_factor.points
            tightened = tighten_cluster_power_factor_reference(
                target=power_factor_policy.target,
                region_count=len(names),
                tracking=tracking_limits,
                current_mvar=margin,
                realized_p_mw=tuple(p.p_mw for p in points),
                realized_q_mvar=tuple(p.q_mvar for p in points),
                violated=tuple(p.status == "violated" for p in points),
            )
            if margin == tightened:
                return finish("stagnated", "已使用完整跟踪误差余量，联合功率因数仍不合格")
            margin = tightened
            # The feasible reference domain changed. A calibration seen under
            # the old PF domain is not a cycle in this new domain.
            seen = [current] if current is not None else []
            continue
        if record.outcome != "regional_rejected":
            return finish(record.outcome, record.reason)
        if policy is None or diagnose is None:
            return finish("disabled", "未配置跨层恢复策略或区域诊断端口")
        if number > maximum:
            return finish("budget_exhausted", "跨层恢复轮次已耗尽，未取得可采用计划")
        try:
            feedback = diagnose(trial.payload, number)
            history[-1] = history[-1].model_copy(update={"feedback": feedback})
            if (
                len(feedback) != len(names)
                or {f.evidence.region for f in feedback} != set(names)
                or any(f.reference_round != number for f in feedback)
            ):
                raise ValueError("feedback region identities or reference round differ")
            if any(f.calibration is None for f in feedback):
                return finish("feedback_unavailable", "区域诊断未取得完整有效的物理校准")
            if any(f.evidence.time_minutes != time_minutes for f in feedback):
                raise ValueError("feedback time axis differs from the current window")
            refreshed = {
                f.evidence.region: f.calibration for f in feedback if f.calibration is not None
            }
            if any(
                all(
                    equivalent_coordination_calibration(old[n], refreshed[n], policy) for n in names
                )
                for old in seen
            ):
                return finish("stagnated", "有效校准未改变或发生循环，停止重复生成参考")
            current = MappingProxyType(refreshed)
            seen.append(current)
        except (ValueError, RuntimeError, FloatingPointError) as exc:
            return finish("error", f"区域反馈无效：{exc}")
    raise AssertionError("bounded recovery loop must terminate explicitly")
