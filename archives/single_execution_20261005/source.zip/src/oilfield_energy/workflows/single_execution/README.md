# 独立单微电网 V2 闭环

ADR 0044 增加 `CertifiedSingleController`、`certify_tube_plan` 和
`verify_conditional_execution`。显式扰动域下组合 control 状态盒及 power_flow
区间证书，保留可行尾部和不变终端。条件模式为唯一执行所有者；失败提案
不能覆盖旧见证，相同目标不重置期限。推导见
[Conditional_Closed_Loop](../../../../docs/modeling/Conditional_Closed_Loop.md)。

负责人：仿真研究维护负责人；复核：优化调度维护负责人、设备控制维护负责人。
公开入口 `api.run_single_feedback`，公开证据 `contracts.SingleExecution`。

工作流只编排已完成状态、规划采用和连续执行，不调用求解器或读取文件。
数值实现由 `bootstrap/adapters/single_execution.py` 注入。复用 control 状态契约、
cluster_execution 的通用执行策略与证据契约；不运行 ADMM，不施加集群受电约束。

每个窗口收到前一窗口已完成实际 Q/储能能量，生成 V2 动态规划行，自主优化，
经设备、AC 和质量校核后采用首段。设备会话不重建，储能能量、P/Q、仲裁及保护
状态连续。失败停止后续采用并保留已完成证据。规划成本和计划曲线仍是计划量。

首次研究状态显式记为 `declared_reference_state`，由已校核参考计划初始化；
不声称启动前过渡已评估。后续状态必须来自执行，历史结果缺失本契约时保持 None。
模型和验证见 [Single_Microgrid_Execution.md](../../../../docs/modeling/Single_Microgrid_Execution.md)
和 ADR 0041。结果模式 1.11.0。
