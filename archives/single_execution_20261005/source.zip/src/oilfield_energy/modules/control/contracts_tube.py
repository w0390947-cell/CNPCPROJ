"""Explicit device model for the conditional V2 supervisory execution mode."""

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

from oilfield_energy.kernel.intervals import Interval


class TubeValue(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid", allow_inf_nan=False)


class TubeResource(TubeValue):
    resource_id: str = Field(min_length=1)
    bus: str = Field(min_length=1)
    kind: Literal["wind", "pv", "storage", "svg"]
    p: Interval
    q: Interval
    s_mva: float = Field(gt=0)
    q_over_p: float | None = Field(default=None, ge=0)
    alpha_p: float = Field(gt=0, le=1)
    ramp_p_mw: float = Field(ge=0)


class TubeDeviceModel(TubeValue):
    version: Literal["ordinary-device-tube-v1"] = "ordinary-device-tube-v1"
    resources: tuple[TubeResource, ...]
    alpha_q: float = Field(gt=0, le=1)
    aggregate_q_ramp_mvar: float = Field(ge=0)
    step_minutes: float = Field(gt=0)
    energy_mwh: Interval
    eta_charge: float = Field(gt=0, le=1)
    eta_discharge: float = Field(gt=0, le=1)
    context_id: str = Field(min_length=1)

    @model_validator(mode="after")
    def identities(self) -> "TubeDeviceModel":
        ids = [r.resource_id for r in self.resources]
        storage = [r for r in self.resources if r.kind == "storage"]
        if (
            not ids
            or len(ids) != len(set(ids))
            or len(storage) != 1
            or storage[0].alpha_p != 1
        ):
            raise ValueError(
                "tube requires unique resources and one zero-order-hold PCS"
            )
        return self


class TubeState(TubeValue):
    p_mw: tuple[float, ...]
    q_mvar: tuple[float, ...]
    energy_mwh: float


class TubeBox(TubeValue):
    p_mw: tuple[Interval, ...]
    q_mvar: tuple[Interval, ...]
    energy_mwh: Interval


class TubeCommand(TubeValue):
    p_mw: tuple[float, ...]
    q_mvar: tuple[float, ...]


class TubeTransition(TubeValue):
    initial: TubeBox
    command: TubeCommand
    endpoint: TubeBox
    path: TubeBox
