"""Numerical assembly for autonomous single-microgrid planning and feedback."""

from collections.abc import Callable, Mapping
from dataclasses import replace
from math import gcd
from typing import cast

import numpy as np
from pydantic import TypeAdapter

from oilfield_energy.data import ProjectCase
from oilfield_energy.device_control import device_tracking_session
from oilfield_energy.hierarchy_types import DeviceTrackingResult
from oilfield_energy.model import OptimizationResult
from oilfield_energy.modules.control.contracts import (
    DeviceCheckpoint,
    DevicePlanUpdate,
    DynamicTrackingPolicy,
    ReactiveDynamicsRecord,
    StopDeviceSession,
)
from oilfield_energy.modules.dispatch.contracts import (
    ComputationQualityPolicy,
    ReactivePlanningPolicy,
)
from oilfield_energy.modules.studies.contracts import ScenarioEvent
from oilfield_energy.workflows.cluster_execution.api import combined_status
from oilfield_energy.workflows.cluster_execution.contracts import (
    ExecutionCheck,
    ExecutionPolicy,
    ExecutionStatus,
    RegionalExecution,
    RollingProgress,
)
from oilfield_energy.workflows.single_execution.api import run_single_feedback
from oilfield_energy.workflows.single_execution.contracts import (
    ConditionalGuaranteeRequest,
    SingleExecution,
    SingleWindow,
)

from .cluster_execution import (
    RegionalPlanRequest,
    assess_device_execution,
    execution_inputs,
    realize_regional_plan,
)
from .cluster_reactive import with_reactive_planning
from .cluster_rolling import (
    execution_time_scale,
    first_command,
    forecast_grid,
    initial_plan,
    window_case,
)
from .single_guarantee import run_conditional_single


def single_execution_policy(
    quality: ComputationQualityPolicy | None = None,
) -> ExecutionPolicy:
    """Record common physical rules without enabling cluster coordination policies."""
    return ExecutionPolicy(
        dynamic_tracking=DynamicTrackingPolicy(),
        reactive_planning=ReactivePlanningPolicy(),
        computation_quality=quality,
        active_tracking_version="active-tracking-allocation-v1",
        device_capability_version="device-capability-v2",
        reactive_tracking_version="reactive-tracking-v1",
        reactive_dynamics_version="reactive-dynamics-v1",
    )


def prepare_single_case(
    case: ProjectCase,
    region: str,
    *,
    storage_enabled: bool,
    policy: ExecutionPolicy,
    checkpoint: DeviceCheckpoint | None = None,
) -> ProjectCase:
    """Select one region and build V2 rows from the declared completed state."""
    if policy.dynamic_tracking is None or policy.reactive_planning is None:
        raise ValueError(
            "independent V2 execution requires explicit planning and dynamics"
        )
    if policy.reactive_planning.version != "reactive-planning-v2":
        raise ValueError(
            "independent V2 execution requires the corrected reachability envelope"
        )
    grids = [mg for mg in case.microgrids if mg.name == region]
    if len(grids) != 1:
        raise ValueError("exactly one selected microgrid is required")
    selected = replace(
        case,
        microgrids=grids,
        reactive_plans={},
        storage_reserves={
            k: v for k, v in case.storage_reserves.items() if k == region
        },
    )
    return with_reactive_planning(
        selected,
        policy=policy.reactive_planning,
        dynamics=policy.dynamic_tracking,
        checkpoints={} if checkpoint is None else {region: checkpoint},
        storage_enabled=storage_enabled,
        execution_step_minutes=policy.device_step_minutes,
    )


class SingleExecutionEngine:
    def __init__(
        self,
        case: ProjectCase,
        reference: OptimizationResult,
        region: str,
        *,
        storage_enabled: bool,
        seconds: float,
        packaged_inputs: bool,
        events: list[ScenarioEvent],
        policy: ExecutionPolicy,
    ) -> None:
        intraday, plants, self.input_basis = execution_inputs(
            case,
            packaged=packaged_inputs,
            events=events,
        )
        selected = replace(
            intraday,
            microgrids=[m for m in intraday.microgrids if m.name == region],
            reactive_plans={},
            storage_reserves={},
        )
        step_minutes = selected.assumptions.dt_hours * 60
        if not float(step_minutes).is_integer():
            raise ValueError(
                "one-minute execution requires integral planning intervals"
            )
        self.step = gcd(int(step_minutes), policy.update_minutes)
        self.policy = policy.model_copy(update={"update_minutes": self.step})
        self.case = forecast_grid(selected, self.step)
        self.region, self.storage_enabled, self.seconds = (
            region,
            storage_enabled,
            seconds,
        )
        self.total = len(self.case.time_hours) * self.step
        self.reference = reference
        self.reference_step = case.assumptions.dt_hours * 60
        self.command: DevicePlanUpdate | None = None
        self.result: DeviceTrackingResult | None = None
        self.session = device_tracking_session(
            self.case,
            self.case.microgrids[0],
            initial_plan(reference, region, len(self.case.time_hours)),
            plant_inputs=plants[region],
            storage_enabled=storage_enabled,
            config=execution_time_scale(self.policy),
            seed=policy.random_seed,
        )
        initial = next(self.session)
        self.initial_state = initial
        self.state = initial

    def prepare(
        self, start: int, end: int, horizon: int, state: DeviceCheckpoint
    ) -> SingleWindow:
        if state != self.state:
            raise ValueError(
                "planning feedback differs from the continuous device state"
            )
        energy = np.asarray(
            self.reference.microgrids[self.region]["storage_energy_mwh"], dtype=float
        )
        terminal = float(
            np.interp(horizon, np.arange(len(energy)) * self.reference_step, energy)
        )
        storage = self.case.microgrids[0].storage
        tolerance = self.policy.numerical_tolerance
        if (
            not storage.e_min_mwh - tolerance
            <= terminal
            <= storage.e_max_mwh + tolerance
        ):
            raise ValueError("reference terminal energy exceeds physical bounds")
        terminal = min(storage.e_max_mwh, max(storage.e_min_mwh, terminal))
        if not self.storage_enabled:
            terminal = state.storage_energy_mwh
        window = window_case(
            self.case,
            start // self.step,
            horizon // self.step,
            {self.region: state.storage_energy_mwh},
            {self.region: terminal},
        )
        window = prepare_single_case(
            window,
            self.region,
            storage_enabled=self.storage_enabled,
            policy=self.policy,
            checkpoint=state,
        )
        plan, solved = realize_regional_plan(
            RegionalPlanRequest(
                window,
                self.region,
                None,
                None,
                self.storage_enabled,
                self.seconds,
                self.policy,
            )
        )
        # Zero controllable Q resources legitimately produce no transition rows.
        if not window.reactive_plans[self.region] and solved is not None:
            plan = plan.model_copy(
                update={
                    "checks": (
                        *plan.checks,
                        ExecutionCheck(
                            code="REACTIVE_PLAN_ENVELOPE",
                            label="无功动态规划约束",
                            status="passed",
                            reason="约束生成已执行；没有获准无功调节资源",
                        ),
                    )
                }
            )
        evidence = SingleWindow(
            start_minute=start,
            end_minute=end,
            horizon_end_minute=horizon,
            initial_state=state,
            terminal_energy_mwh=terminal,
            reactive_constraint_count=len(window.reactive_plans[self.region]),
            plan=plan,
        )
        self.command = (
            first_command(plan, start, end - start) if evidence.adopted else None
        )
        return evidence

    def advance(self, start: int, end: int) -> DeviceCheckpoint:
        if self.command is None or self.state.minute != start:
            raise ValueError("no matching adopted independent command")
        for minute in range(start, end):
            try:
                state = self.session.send(self.command if minute == start else None)
                if state.minute != minute + 1:
                    raise ValueError("device clock differs from the adopted interval")
                self.state = state
            except StopIteration as done:
                if minute + 1 != self.total or not isinstance(
                    done.value, DeviceTrackingResult
                ):
                    raise ValueError(
                        "device session ended before the requested horizon"
                    ) from done
                self.result = done.value
                self.state = self.end_state(done.value)
        return self.state

    def end_state(self, result: DeviceTrackingResult) -> DeviceCheckpoint:
        return DeviceCheckpoint(
            minute=len(result.time_minutes),
            storage_energy_mwh=float(result.storage_energy_mwh[-1]),
            storage_power_mw=float(result.storage_actual_mw[-1]),
            reactive_power_mvar={
                rid: float(values[-1])
                for rid, values in result.reactive_resource_actual_mvar.items()
            },
        )

    def finish(self) -> RegionalExecution | None:
        if self.result is None:
            if self.state.minute == 0:
                self.session.close()
                return None
            try:
                self.session.throw(StopDeviceSession())
            except StopIteration as done:
                if not isinstance(done.value, DeviceTrackingResult):
                    raise ValueError(
                        "missing completed device execution prefix"
                    ) from done
                self.result = done.value
        if self.result is None:
            raise ValueError("device session did not terminate at its boundary")
        return assess_device_execution(
            self.case,
            self.region,
            self.result,
            storage_enabled=self.storage_enabled,
            policy=self.policy,
        )

    def dynamics(self) -> tuple[ReactiveDynamicsRecord, ...]:
        if self.result is None:
            return ()
        records: list[ReactiveDynamicsRecord] = []
        adapter = TypeAdapter(ReactiveDynamicsRecord)
        rows = cast(list[Mapping[str, object]], self.result.network_feedback)  # pyright: ignore[reportUnknownMemberType]
        for row in rows:
            control = row.get("reactive_control")
            if isinstance(control, dict):
                data = cast(dict[str, object], control).get("dynamics")
                if data is not None:
                    records.append(adapter.validate_python(data))
        return tuple(records)


def run_single_execution(
    case: ProjectCase,
    reference: OptimizationResult,
    region: str,
    *,
    storage_enabled: bool,
    time_limit_seconds: float,
    packaged_inputs: bool,
    events: list[ScenarioEvent],
    policy: ExecutionPolicy,
    progress: Callable[[RollingProgress], None] | None = None,
    guarantee: ConditionalGuaranteeRequest | None = None,
) -> SingleExecution:
    """Run autonomous windows with continuous device states and truthful failures."""
    if guarantee is not None:
        return run_conditional_single(
            case, reference, region, storage_enabled=storage_enabled,
            time_limit_seconds=time_limit_seconds, packaged_inputs=packaged_inputs,
            events=events, policy=policy, settings=guarantee, progress=progress,
        )
    engine: SingleExecutionEngine | None = None
    windows: tuple[SingleWindow, ...] = ()
    minute: RegionalExecution | None = None
    reason = ""
    dynamics: tuple[ReactiveDynamicsRecord, ...] = ()
    total = round(len(case.time_hours) * case.assumptions.dt_hours * 60)
    try:
        engine = SingleExecutionEngine(
            case,
            reference,
            region,
            storage_enabled=storage_enabled,
            seconds=time_limit_seconds,
            packaged_inputs=packaged_inputs,
            events=events,
            policy=policy,
        )
        windows, reason = run_single_feedback(
            total_minutes=engine.total,
            initial_state=engine.initial_state,
            policy=engine.policy,
            prepare=engine.prepare,
            advance=engine.advance,
            progress=progress,
        )
        minute = engine.finish()
        dynamics = engine.dynamics()
    except (ValueError, RuntimeError, FloatingPointError) as exc:
        reason = f"独立执行证据不完整：{exc}"
    finally:
        if engine is not None:
            engine.session.close()
    completed = engine.state.minute if engine is not None else 0
    statuses: list[ExecutionStatus] = [w.plan.status for w in windows]
    statuses.append(minute.status if minute is not None else "not_computed")
    if reason or completed != total or len(dynamics) != completed:
        statuses.append("unknown")
    if any(
        not r.ramp_compliant
        or not r.response_matches_prediction
        or not r.actual_capacity_within_limits
        for r in dynamics
    ):
        statuses.append("violated")
    if not reason and len(dynamics) != completed:
        reason = "周期无功响应证据缺失，不能认证完整执行"
    if not reason and minute is not None and minute.status != "passed":
        reason = "执行校核未通过：" + "、".join(
            c.label for c in minute.checks if c.status != "passed"
        )
    return SingleExecution(
        region=region,
        status=combined_status(statuses),
        reason=reason,
        storage_enabled=storage_enabled,
        policy=engine.policy if engine else policy,
        input_basis=engine.input_basis if engine else "执行输入未完成装配",
        initial_state=engine.initial_state if engine else None,
        last_completed_state=engine.state if engine else None,
        total_minutes=total,
        completed_minutes=completed,
        windows=windows,
        minute=minute,
        reactive_dynamics=dynamics,
    )
