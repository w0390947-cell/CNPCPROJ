"""Assemble the conditional V2 supervisor from existing case and optimizer APIs."""

from collections.abc import Callable
from dataclasses import replace
from hashlib import sha256
from math import exp
from typing import Literal, cast

import numpy as np

from oilfield_energy.data import MicrogridData, ProjectCase
from oilfield_energy.model import OptimizationResult
from oilfield_energy.modules.control.api import execute_tube_command
from oilfield_energy.modules.control.contracts import (
    DeviceCheckpoint,
    PlantInputs,
    TubeCommand,
    TubeDeviceModel,
    TubeResource,
    TubeState,
)
from oilfield_energy.modules.power_flow.contracts import (
    EnvelopeBranch,
    PowerInterval,
    RadialEnvelope,
)
from oilfield_energy.modules.studies.contracts import ScenarioEvent
from oilfield_energy.network_model import validate_legacy_network_alignment
from oilfield_energy.resource_control_contracts import ResourceSchedule
from oilfield_energy.workflows.cluster_execution.contracts import (
    ExecutionPolicy,
    RollingProgress,
)
from oilfield_energy.workflows.single_execution.api import CertifiedSingleController
from oilfield_energy.workflows.single_execution.contracts import (
    BoundedBusLoad,
    ClosedLoopDomain,
    ConditionalExecution,
    ConditionalGuaranteeRequest,
    FirmGeneration,
    SingleExecution,
)

from .cluster_execution import (
    RegionalPlanRequest,
    execution_inputs,
    realize_regional_plan,
)
from .cluster_reactive import with_reactive_planning
from .cluster_rolling import forecast_grid, window_case


def assemble_closed_loop_domain(
    mg: MicrogridData,
    case: ProjectCase,
    settings: ConditionalGuaranteeRequest,
    policy: ExecutionPolicy,
    *,
    storage_enabled: bool,
) -> ClosedLoopDomain:
    dynamics = policy.dynamic_tracking
    if dynamics is None or policy.device_step_minutes != 1:
        raise ValueError("conditional execution needs declared one-minute dynamics")
    resolved = validate_legacy_network_alignment(mg)
    if any(b.phase_shift_degrees != 0 for b in resolved.branches):
        raise ValueError("conditional envelope does not support phase shifting")
    buses = tuple(b.bus_id for b in resolved.buses)
    network = RadialEnvelope(
        network_id=f"{mg.name}:{resolved.operating_mode_id}",
        buses=buses,
        branches=tuple(
            EnvelopeBranch(
                parent=buses.index(b.parent),
                child=buses.index(b.child),
                r_pu=b.r_pu,
                x_pu=b.x_pu,
                tap=b.tap_ratio,
                rating_mva=b.s_max_mva,
            )
            for b in resolved.branches
        ),
        slack=buses.index(resolved.pcc_bus_id),
        base_mva=resolved.base_mva,
        slack_voltage_pu=1.0,
        shunt_q_mvar=tuple(resolved.shunt_q_nominal_mvar_by_bus[b] for b in buses),
        voltage_min_pu=mg.voltage_min_pu,
        voltage_max_pu=mg.voltage_max_pu,
        pcc_min_mw=max(0.0, mg.p_grid_min_mw, case.assumptions.no_reverse_margin_mw),
        pcc_max_mw=mg.p_grid_max_mw,
        pf_min=case.assumptions.pf_min,
    )
    resources: list[TubeResource] = []
    firm = {r.resource_id: r.minimum_available_mw for r in settings.generation}
    expected = {mg.resource_id("wind", b) for b in mg.wind_capacity_mw} | {
        mg.resource_id("pv", b) for b in mg.pv_capacity_mw
    }
    if firm.keys() != expected:
        raise ValueError(
            "firm generation declarations must cover the exact resource set"
        )
    aq = 1 - exp(-1 / dynamics.time_constant_minutes)
    ratios = [mg.wind_q_over_p_limit(b) for b in mg.wind_capacity_mw]
    ratio = min((x for x in ratios if x is not None), default=0.30)
    for bus, rated in mg.wind_capacity_mw.items():
        rid = mg.resource_id("wind", bus)
        cap = mg.wind_reactive_capability(bus)
        bound = cap.absolute_limit_mvar
        resources.append(
            TubeResource(
                resource_id=rid,
                bus=bus,
                kind="wind",
                p=PowerInterval(low=0, high=min(rated, firm[rid])),
                q=PowerInterval(low=-bound, high=bound),
                s_mva=cap.s_max_mva,
                q_over_p=ratio,
                alpha_p=aq,
                ramp_p_mw=dynamics.p_ramp_mw_per_minute
                / max(1, len(mg.wind_capacity_mw)),
            )
        )
    for bus, rated in mg.pv_capacity_mw.items():
        rid = mg.resource_id("pv", bus)
        s = mg.pv_capacity_mva[bus]
        q = s if mg.pv_can_control_reactive(bus) else 0.0
        resources.append(
            TubeResource(
                resource_id=rid,
                bus=bus,
                kind="pv",
                p=PowerInterval(low=0, high=min(rated, firm[rid])),
                q=PowerInterval(low=-q, high=q),
                s_mva=s,
                alpha_p=1 - exp(-1 / dynamics.pv_time_constant_minutes),
                ramp_p_mw=dynamics.p_ramp_mw_per_minute,
            )
        )
    st = mg.storage
    sp = st.p_max_mw if storage_enabled else 0.0
    sq = st.s_max_mva if storage_enabled and mg.storage_reactive_enabled else 0.0
    resources.append(
        TubeResource(
            resource_id=mg.resource_id("storage", st.bus),
            bus=st.bus,
            kind="storage",
            p=PowerInterval(low=-sp, high=sp),
            q=PowerInterval(low=-sq, high=sq),
            s_mva=st.s_max_mva,
            alpha_p=1,
            ramp_p_mw=dynamics.p_ramp_mw_per_minute,
        )
    )
    svg = mg.svg_capability()
    svg_limit = min(
        1.8, max(abs(svg.effective_q_min_mvar), abs(svg.effective_q_max_mvar))
    )
    resources.append(
        TubeResource(
            resource_id=mg.resource_id("svg", mg.svg_bus),
            bus=mg.svg_bus,
            kind="svg",
            p=PowerInterval(low=0, high=0),
            q=PowerInterval(
                low=max(-svg_limit, svg.effective_q_min_mvar),
                high=min(svg_limit, svg.effective_q_max_mvar),
            ),
            s_mva=svg.s_max_mva,
            alpha_p=1,
            ramp_p_mw=0,
        )
    )
    devices = TubeDeviceModel(
        resources=tuple(resources),
        alpha_q=aq,
        aggregate_q_ramp_mvar=dynamics.q_ramp_mvar_per_minute,
        step_minutes=1,
        energy_mwh=PowerInterval(low=st.e_min_mwh, high=st.e_max_mwh),
        eta_charge=st.eta_charge,
        eta_discharge=st.eta_discharge,
        context_id="pending",
    )
    identity = sha256(
        (network.model_dump_json() + devices.model_dump_json()).encode()
    ).hexdigest()
    devices = devices.model_copy(update={"context_id": identity})
    return ClosedLoopDomain(
        assumptions=settings,
        network=network,
        devices=devices,
        p_band_mw=policy.p_tracking_tolerance_mw,
        q_band_mvar=policy.q_tracking_tolerance_mvar,
        maximum_settling_steps=dynamics.maximum_response_minutes,
    )


def propose_terminal_command(
    case: ProjectCase,
    region: str,
    domain: ClosedLoopDomain,
    state: TubeState,
    policy: ExecutionPolicy,
    seconds: float,
) -> TubeCommand:
    """Existing MISOCP proposes a steady, energy-neutral continuation.

    It uses domain midpoints/firm minima, not future plant observations. A
    stricter nominal target allocation leaves room for the certified disturbance
    bound; it does not change the user's engineering band.
    """
    mg = next(m for m in case.microgrids if m.name == region)
    loads = {v.bus: v for v in domain.assumptions.loads}
    firm = {
        g.resource_id: g.minimum_available_mw for g in domain.assumptions.generation
    }
    one = replace(
        mg,
        load_p_mw={
            b: np.array([(v.p_mw.low + v.p_mw.high) / 2]) for b, v in loads.items()
        },
        load_q_mvar={
            b: np.array([(v.q_mvar.low + v.q_mvar.high) / 2]) for b, v in loads.items()
        },
        wind_available_mw={
            b: np.array([firm[mg.resource_id("wind", b)]]) for b in mg.wind_capacity_mw
        },
        pv_available_mw={
            b: np.array([firm[mg.resource_id("pv", b)]]) for b in mg.pv_capacity_mw
        },
        storage=replace(
            mg.storage, e_initial_mwh=state.energy_mwh, e_terminal_mwh=state.energy_mwh
        ),
    )
    plan_case = replace(
        case,
        time_hours=np.array([0.0]),
        price_cny_per_mwh=np.array([case.price_cny_per_mwh[0]]),
        microgrids=[one],
        assumptions=replace(case.assumptions, dt_hours=1 / 60),
        storage_reserves={},
        reactive_plans={},
    )
    dynamic = policy.dynamic_tracking
    reactive = policy.reactive_planning
    assert dynamic is not None and reactive is not None
    plan_case = with_reactive_planning(
        plan_case,
        policy=reactive,
        dynamics=dynamic,
        checkpoints={},
        storage_enabled=False,
        execution_step_minutes=1,
    )
    proposal_policy = policy.model_copy(
        update={
            "p_tracking_tolerance_mw": domain.p_band_mw / 4,
            "q_tracking_tolerance_mvar": domain.q_band_mvar / 4,
        }
    )
    evidence, solved = realize_regional_plan(
        RegionalPlanRequest(
            plan_case,
            region,
            np.array([domain.assumptions.target_p_mw]),
            np.array([domain.assumptions.target_q_mvar]),
            False,
            seconds,
            proposal_policy,
        )
    )
    if evidence.status != "passed" or solved is None:
        raise ValueError("terminal proposal unavailable: " + evidence.reason)
    return TubeCommand(
        p_mw=tuple(
            evidence.resource_p_mw[r.resource_id][0] for r in domain.devices.resources
        ),
        q_mvar=tuple(
            evidence.resource_q_mvar[r.resource_id][0] for r in domain.devices.resources
        ),
    )


def settling_commands(
    domain: ClosedLoopDomain, initial: TubeState, target: TubeCommand
) -> tuple[TubeCommand, ...]:
    """Ramp intermediate commands toward a terminal proposal; proof remains separate."""
    state = initial
    commands: list[TubeCommand] = []
    for _ in range(domain.maximum_settling_steps):
        ps = tuple(
            p
            + max(
                -0.95 * r.ramp_p_mw / r.alpha_p,
                min(0.95 * r.ramp_p_mw / r.alpha_p, u - p),
            )
            for r, p, u in zip(
                domain.devices.resources, state.p_mw, target.p_mw, strict=True
            )
        )
        movement = domain.devices.alpha_q * sum(
            abs(u - q) for q, u in zip(state.q_mvar, target.q_mvar, strict=True)
        )
        scale = (
            min(1.0, 0.95 * domain.devices.aggregate_q_ramp_mvar / movement)
            if movement
            else 1.0
        )
        qs = tuple(
            q + scale * (u - q)
            for q, u in zip(state.q_mvar, target.q_mvar, strict=True)
        )
        command = TubeCommand(p_mw=ps, q_mvar=qs)
        # Exact terminal values avoid an accidentally nonzero PCS tail.
        if all(
            abs(a - b) < 1e-13
            for a, b in zip((*ps, *qs), (*target.p_mw, *target.q_mvar), strict=True)
        ):
            commands.append(target)
            return tuple(commands)
        state = execute_tube_command(domain.devices, state, command)
        commands.append(command)
    raise ValueError("terminal proposal cannot be reached within the response budget")


def propose_tracking_prefix(
    case: ProjectCase,
    region: str,
    domain: ClosedLoopDomain,
    state: TubeState,
    terminal: TubeCommand,
    policy: ExecutionPolicy,
    seconds: float,
    step: int,
    *,
    storage_enabled: bool,
) -> tuple[TubeCommand, ...]:
    """V2 rolling optimization proposes its next device action plus a feasible tail.

    The ordinary economic model remains a proposer. Its original terminal-energy
    target is not an axiom of recursive feasibility; the supervisory optimization
    uses a certified terminal continuation and may retain the previous witness.
    """
    mg = next(m for m in case.microgrids if m.name == region)
    firm = {
        g.resource_id: g.minimum_available_mw for g in domain.assumptions.generation
    }
    selected = replace(
        case,
        microgrids=[
            replace(
                mg,
                wind_available_mw={
                    b: np.minimum(v, firm[mg.resource_id("wind", b)])
                    for b, v in mg.wind_available_mw.items()
                },
                pv_available_mw={
                    b: np.minimum(v, firm[mg.resource_id("pv", b)])
                    for b, v in mg.pv_available_mw.items()
                },
            )
        ],
        storage_reserves={},
        reactive_plans={},
    )
    grid = forecast_grid(selected, 1)
    window = window_case(
        grid,
        step,
        min(step + policy.horizon_minutes, len(grid.time_hours)),
        {region: state.energy_mwh},
        {region: state.energy_mwh},
    )
    dynamic, reactive = policy.dynamic_tracking, policy.reactive_planning
    assert dynamic is not None and reactive is not None
    storage = next(
        i for i, r in enumerate(domain.devices.resources) if r.kind == "storage"
    )
    checkpoint = DeviceCheckpoint(
        minute=step,
        storage_energy_mwh=state.energy_mwh,
        storage_power_mw=state.p_mw[storage],
        reactive_power_mvar={
            r.resource_id: q
            for r, q in zip(domain.devices.resources, state.q_mvar, strict=True)
        },
    )
    window = with_reactive_planning(
        window,
        policy=reactive,
        dynamics=dynamic,
        checkpoints={region: checkpoint},
        storage_enabled=storage_enabled,
        execution_step_minutes=1,
    )
    proposal_policy = policy.model_copy(
        update={
            "p_tracking_tolerance_mw": domain.p_band_mw / 4,
            "q_tracking_tolerance_mvar": domain.q_band_mvar / 4,
        }
    )
    evidence, solved = realize_regional_plan(
        RegionalPlanRequest(
            window,
            region,
            np.full(len(window.time_hours), domain.assumptions.target_p_mw),
            np.full(len(window.time_hours), domain.assumptions.target_q_mvar),
            storage_enabled,
            seconds,
            proposal_policy,
        )
    )
    if evidence.status != "passed" or solved is None:
        raise ValueError("rolling proposal unavailable: " + evidence.reason)
    first = TubeCommand(
        p_mw=tuple(
            evidence.resource_p_mw[r.resource_id][0] for r in domain.devices.resources
        ),
        q_mvar=tuple(
            evidence.resource_q_mvar[r.resource_id][0] for r in domain.devices.resources
        ),
    )
    prefix = settling_commands(domain, state, first)
    predicted = state
    for command in prefix:
        predicted = execute_tube_command(domain.devices, predicted, command)
    return (*prefix, *settling_commands(domain, predicted, terminal))


def _observations(
    plant: PlantInputs, mg: MicrogridData, step: int
) -> tuple[tuple[BoundedBusLoad, ...], tuple[FirmGeneration, ...]]:
    p = {b.bus_id: b.values[step] for b in plant.load_p}
    q = {b.bus_id: b.values[step] for b in plant.load_q}
    loads = tuple(
        BoundedBusLoad(
            bus=b,
            p_mw=PowerInterval(low=p[b], high=p[b]),
            q_mvar=PowerInterval(low=q[b], high=q[b]),
        )
        for b in mg.buses
    )
    generation = tuple(
        FirmGeneration(
            resource_id=mg.resource_id("wind", b.bus_id),
            minimum_available_mw=b.values[step],
        )
        for b in plant.wind_available
    ) + tuple(
        FirmGeneration(
            resource_id=mg.resource_id("pv", b.bus_id),
            minimum_available_mw=b.values[step],
        )
        for b in plant.pv_available
    )
    return loads, generation


def run_conditional_single(
    case: ProjectCase,
    reference: OptimizationResult,
    region: str,
    *,
    storage_enabled: bool,
    time_limit_seconds: float,
    packaged_inputs: bool,
    events: list[ScenarioEvent],
    policy: ExecutionPolicy,
    settings: ConditionalGuaranteeRequest,
    progress: Callable[[RollingProgress], None] | None = None,
) -> SingleExecution:
    mg = next(m for m in case.microgrids if m.name == region)
    domain = assemble_closed_loop_domain(
        mg, case, settings, policy, storage_enabled=storage_enabled
    )
    schedules = cast(
        tuple[ResourceSchedule, ...], reference.microgrids[region]["resource_schedules"]
    )
    by_id = {r.resource_id: r for r in schedules}
    initial = TubeState(
        p_mw=tuple(
            float(by_id[r.resource_id].active_power_mw[0])
            for r in domain.devices.resources
        ),
        q_mvar=tuple(
            float(by_id[r.resource_id].reactive_power_mvar[0])
            for r in domain.devices.resources
        ),
        energy_mwh=mg.storage.e_initial_mwh,
    )
    if settings.initial_state is not None:
        ids = tuple(r.resource_id for r in domain.devices.resources)
        if set(ids) != set(settings.initial_resource_ids):
            raise ValueError("declared initial state must cover every device")
        order = tuple(settings.initial_resource_ids.index(rid) for rid in ids)
        initial = TubeState(
            p_mw=tuple(settings.initial_state.p_mw[i] for i in order),
            q_mvar=tuple(settings.initial_state.q_mvar[i] for i in order),
            energy_mwh=settings.initial_state.energy_mwh,
        )
    intraday, plants, basis = execution_inputs(
        case, packaged=packaged_inputs, events=events
    )
    total = round(len(case.time_hours) * case.assumptions.dt_hours * 60)
    controller: CertifiedSingleController | None = None
    reason = ""
    status: Literal["passed", "unproven", "assumption_violated"] = "unproven"
    try:
        target = propose_terminal_command(
            case, region, domain, initial, policy, time_limit_seconds
        )
        controller = CertifiedSingleController(
            domain, initial, settling_commands(domain, initial, target)
        )
        for k in range(total):
            loads, generation = _observations(plants[region], mg, k)
            proposal, failure = None, ""
            if k and k % policy.update_minutes == 0:
                try:
                    target = propose_terminal_command(
                        case,
                        region,
                        domain,
                        controller.state,
                        policy,
                        time_limit_seconds,
                    )
                    proposal = propose_tracking_prefix(
                        intraday,
                        region,
                        domain,
                        controller.state,
                        target,
                        policy,
                        time_limit_seconds,
                        k,
                        storage_enabled=storage_enabled,
                    )
                except (ValueError, RuntimeError, FloatingPointError) as exc:
                    failure = str(exc)
            controller.advance(
                loads=loads,
                generation=generation,
                context_id=domain.devices.context_id,
                proposal=proposal,
                proposal_failure=failure,
            )
            if progress is not None and (k + 1) % policy.update_minutes == 0:
                progress(
                    RollingProgress(
                        current_window=k // policy.update_minutes + 1,
                        completed_windows=k // policy.update_minutes + 1,
                        total_windows=(total + policy.update_minutes - 1)
                        // policy.update_minutes,
                        start_minute=k - k % policy.update_minutes,
                        end_minute=k + 1,
                        total_minutes=total,
                        phase="completed",
                    )
                )
        status = "passed"
    except (ValueError, RuntimeError, FloatingPointError) as exc:
        reason = str(exc)
        status = "assumption_violated" if controller is not None else "unproven"
    evidence = ConditionalExecution(
        domain=domain,
        status=status,
        reason=reason,
        initial=initial,
        steps=tuple(controller.steps) if controller else (),
        plans=tuple(controller.plans) if controller else (),
        requested_steps=total,
    )
    end = controller.state if controller else initial

    def checkpoint(state: TubeState, minute: int) -> DeviceCheckpoint:
        i = next(
            i for i, r in enumerate(domain.devices.resources) if r.kind == "storage"
        )
        return DeviceCheckpoint(
            minute=minute,
            storage_energy_mwh=state.energy_mwh,
            storage_power_mw=state.p_mw[i],
            reactive_power_mvar={
                r.resource_id: q
                for r, q in zip(domain.devices.resources, state.q_mvar, strict=True)
            },
        )

    return SingleExecution(
        region=region,
        status="passed" if status == "passed" else "unknown",
        reason=reason,
        storage_enabled=storage_enabled,
        policy=policy,
        input_basis=basis,
        total_minutes=total,
        completed_minutes=len(evidence.steps),
        initial_state=checkpoint(initial, 0),
        last_completed_state=checkpoint(end, len(evidence.steps)),
        conditional_guarantee=evidence,
        initialization="declared_actual_state"
        if settings.initial_state is not None
        else "declared_reference_state",
    )
